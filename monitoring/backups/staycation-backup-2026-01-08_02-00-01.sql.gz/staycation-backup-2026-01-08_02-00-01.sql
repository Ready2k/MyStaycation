--
-- PostgreSQL database dump
--

\restrict cx43aArzVl3N3jQh86D0hmdb6iHA1edF7Qzph28IqtEY9DO1tjdtcUki2HVWIod

-- Dumped from database version 16.11
-- Dumped by pg_dump version 16.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE IF EXISTS staycation_db;
--
-- Name: staycation_db; Type: DATABASE; Schema: -; Owner: staycation
--

CREATE DATABASE staycation_db WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE staycation_db OWNER TO staycation;

\unrestrict cx43aArzVl3N3jQh86D0hmdb6iHA1edF7Qzph28IqtEY9DO1tjdtcUki2HVWIod
\connect staycation_db
\restrict cx43aArzVl3N3jQh86D0hmdb6iHA1edF7Qzph28IqtEY9DO1tjdtcUki2HVWIod

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: alerts_channel_enum; Type: TYPE; Schema: public; Owner: staycation
--

CREATE TYPE public.alerts_channel_enum AS ENUM (
    'EMAIL',
    'PUSH',
    'SMS'
);


ALTER TYPE public.alerts_channel_enum OWNER TO staycation;

--
-- Name: alerts_status_enum; Type: TYPE; Schema: public; Owner: staycation
--

CREATE TYPE public.alerts_status_enum AS ENUM (
    'PENDING',
    'SENT',
    'FAILED',
    'DISMISSED'
);


ALTER TYPE public.alerts_status_enum OWNER TO staycation;

--
-- Name: deals_discounttype_enum; Type: TYPE; Schema: public; Owner: staycation
--

CREATE TYPE public.deals_discounttype_enum AS ENUM (
    'PERCENT_OFF',
    'FIXED_OFF',
    'SALE_PRICE',
    'PERK'
);


ALTER TYPE public.deals_discounttype_enum OWNER TO staycation;

--
-- Name: deals_source_enum; Type: TYPE; Schema: public; Owner: staycation
--

CREATE TYPE public.deals_source_enum AS ENUM (
    'PROVIDER_OFFERS',
    'HOTUKDEALS',
    'OTHER'
);


ALTER TYPE public.deals_source_enum OWNER TO staycation;

--
-- Name: fetch_runs_providerstatus_enum; Type: TYPE; Schema: public; Owner: staycation
--

CREATE TYPE public.fetch_runs_providerstatus_enum AS ENUM (
    'OK',
    'FETCH_FAILED',
    'PARSE_FAILED',
    'BLOCKED',
    'TIMEOUT'
);


ALTER TYPE public.fetch_runs_providerstatus_enum OWNER TO staycation;

--
-- Name: fetch_runs_runtype_enum; Type: TYPE; Schema: public; Owner: staycation
--

CREATE TYPE public.fetch_runs_runtype_enum AS ENUM (
    'SEARCH',
    'OFFERS_PAGE',
    'DEAL_SOURCE',
    'MANUAL_PREVIEW'
);


ALTER TYPE public.fetch_runs_runtype_enum OWNER TO staycation;

--
-- Name: fetch_runs_status_enum; Type: TYPE; Schema: public; Owner: staycation
--

CREATE TYPE public.fetch_runs_status_enum AS ENUM (
    'OK',
    'ERROR',
    'BLOCKED',
    'PARSE_FAILED'
);


ALTER TYPE public.fetch_runs_status_enum OWNER TO staycation;

--
-- Name: holiday_profiles_accommodationtype_enum; Type: TYPE; Schema: public; Owner: staycation
--

CREATE TYPE public.holiday_profiles_accommodationtype_enum AS ENUM (
    'ANY',
    'LODGE',
    'CARAVAN',
    'APARTMENT',
    'COTTAGE',
    'HOTEL'
);


ALTER TYPE public.holiday_profiles_accommodationtype_enum OWNER TO staycation;

--
-- Name: holiday_profiles_alertsensitivity_enum; Type: TYPE; Schema: public; Owner: staycation
--

CREATE TYPE public.holiday_profiles_alertsensitivity_enum AS ENUM (
    'INSTANT',
    'DIGEST',
    'EXCEPTIONAL_ONLY'
);


ALTER TYPE public.holiday_profiles_alertsensitivity_enum OWNER TO staycation;

--
-- Name: holiday_profiles_flextype_enum; Type: TYPE; Schema: public; Owner: staycation
--

CREATE TYPE public.holiday_profiles_flextype_enum AS ENUM (
    'FIXED',
    'RANGE',
    'FLEXI'
);


ALTER TYPE public.holiday_profiles_flextype_enum OWNER TO staycation;

--
-- Name: holiday_profiles_peaktolerance_enum; Type: TYPE; Schema: public; Owner: staycation
--

CREATE TYPE public.holiday_profiles_peaktolerance_enum AS ENUM (
    'OFFPEAK_ONLY',
    'MIXED',
    'PEAK_OK'
);


ALTER TYPE public.holiday_profiles_peaktolerance_enum OWNER TO staycation;

--
-- Name: holiday_profiles_schoolholidays_enum; Type: TYPE; Schema: public; Owner: staycation
--

CREATE TYPE public.holiday_profiles_schoolholidays_enum AS ENUM (
    'ALLOW',
    'AVOID',
    'ONLY'
);


ALTER TYPE public.holiday_profiles_schoolholidays_enum OWNER TO staycation;

--
-- Name: holiday_profiles_staypattern_enum; Type: TYPE; Schema: public; Owner: staycation
--

CREATE TYPE public.holiday_profiles_staypattern_enum AS ENUM (
    'ANY',
    'MIDWEEK',
    'WEEKEND',
    'FULL_WEEK'
);


ALTER TYPE public.holiday_profiles_staypattern_enum OWNER TO staycation;

--
-- Name: holiday_profiles_tier_enum; Type: TYPE; Schema: public; Owner: staycation
--

CREATE TYPE public.holiday_profiles_tier_enum AS ENUM (
    'STANDARD',
    'PREMIUM',
    'LUXURY'
);


ALTER TYPE public.holiday_profiles_tier_enum OWNER TO staycation;

--
-- Name: insights_type_enum; Type: TYPE; Schema: public; Owner: staycation
--

CREATE TYPE public.insights_type_enum AS ENUM (
    'LOWEST_IN_X_DAYS',
    'PRICE_DROP_PERCENT',
    'NEW_CAMPAIGN_DETECTED',
    'RISK_RISING',
    'VOUCHER_SPOTTED'
);


ALTER TYPE public.insights_type_enum OWNER TO staycation;

--
-- Name: price_observations_availability_enum; Type: TYPE; Schema: public; Owner: staycation
--

CREATE TYPE public.price_observations_availability_enum AS ENUM (
    'AVAILABLE',
    'SOLD_OUT',
    'UNKNOWN'
);


ALTER TYPE public.price_observations_availability_enum OWNER TO staycation;

--
-- Name: system_logs_level_enum; Type: TYPE; Schema: public; Owner: staycation
--

CREATE TYPE public.system_logs_level_enum AS ENUM (
    'INFO',
    'WARN',
    'ERROR'
);


ALTER TYPE public.system_logs_level_enum OWNER TO staycation;

--
-- Name: users_role_enum; Type: TYPE; Schema: public; Owner: staycation
--

CREATE TYPE public.users_role_enum AS ENUM (
    'USER',
    'ADMIN'
);


ALTER TYPE public.users_role_enum OWNER TO staycation;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alerts; Type: TABLE; Schema: public; Owner: staycation
--

CREATE TABLE public.alerts (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    channel public.alerts_channel_enum DEFAULT 'EMAIL'::public.alerts_channel_enum NOT NULL,
    status public.alerts_status_enum DEFAULT 'PENDING'::public.alerts_status_enum NOT NULL,
    "dedupeKey" character varying NOT NULL,
    "errorMessage" text,
    "sentAt" timestamp without time zone,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL,
    user_id uuid,
    insight_id uuid
);


ALTER TABLE public.alerts OWNER TO staycation;

--
-- Name: deals; Type: TABLE; Schema: public; Owner: staycation
--

CREATE TABLE public.deals (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    source public.deals_source_enum NOT NULL,
    "sourceRef" character varying NOT NULL,
    title character varying NOT NULL,
    "discountType" public.deals_discounttype_enum NOT NULL,
    "discountValue" numeric(10,2),
    "voucherCode" character varying,
    "eligibilityTags" text DEFAULT ''::text NOT NULL,
    restrictions jsonb,
    "startsAt" timestamp without time zone,
    "endsAt" timestamp without time zone,
    confidence numeric(3,2) DEFAULT 0.5 NOT NULL,
    "detectedAt" timestamp without time zone DEFAULT now() NOT NULL,
    "lastSeenAt" timestamp without time zone DEFAULT now() NOT NULL,
    provider_id uuid
);


ALTER TABLE public.deals OWNER TO staycation;

--
-- Name: fetch_runs; Type: TABLE; Schema: public; Owner: staycation
--

CREATE TABLE public.fetch_runs (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    "runType" public.fetch_runs_runtype_enum NOT NULL,
    "scheduledFor" timestamp without time zone NOT NULL,
    "startedAt" timestamp without time zone,
    "finishedAt" timestamp without time zone,
    status public.fetch_runs_status_enum NOT NULL,
    "httpStatus" integer,
    "requestFingerprint" character varying,
    "responseSnapshotRef" text,
    "errorMessage" text,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    provider_id uuid,
    fingerprint_id uuid,
    "requestId" character varying,
    "providerStatus" public.fetch_runs_providerstatus_enum
);


ALTER TABLE public.fetch_runs OWNER TO staycation;

--
-- Name: holiday_profiles; Type: TABLE; Schema: public; Owner: staycation
--

CREATE TABLE public.holiday_profiles (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying NOT NULL,
    "partySizeAdults" integer DEFAULT 2 NOT NULL,
    "partySizeChildren" integer DEFAULT 0 NOT NULL,
    "flexType" public.holiday_profiles_flextype_enum DEFAULT 'RANGE'::public.holiday_profiles_flextype_enum NOT NULL,
    "dateStart" date,
    "dateEnd" date,
    "durationNightsMin" integer DEFAULT 3 NOT NULL,
    "durationNightsMax" integer DEFAULT 7 NOT NULL,
    "peakTolerance" public.holiday_profiles_peaktolerance_enum DEFAULT 'MIXED'::public.holiday_profiles_peaktolerance_enum NOT NULL,
    "budgetCeilingGbp" numeric(10,2),
    enabled boolean DEFAULT true NOT NULL,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL,
    user_id uuid,
    pets boolean DEFAULT false NOT NULL,
    "accommodationType" public.holiday_profiles_accommodationtype_enum DEFAULT 'ANY'::public.holiday_profiles_accommodationtype_enum NOT NULL,
    "minBedrooms" integer DEFAULT 0 NOT NULL,
    tier public.holiday_profiles_tier_enum DEFAULT 'STANDARD'::public.holiday_profiles_tier_enum NOT NULL,
    "stayPattern" public.holiday_profiles_staypattern_enum DEFAULT 'ANY'::public.holiday_profiles_staypattern_enum NOT NULL,
    "schoolHolidays" public.holiday_profiles_schoolholidays_enum DEFAULT 'ALLOW'::public.holiday_profiles_schoolholidays_enum NOT NULL,
    "petsNumber" integer DEFAULT 0 NOT NULL,
    "stepFreeAccess" boolean DEFAULT false NOT NULL,
    "accessibleBathroom" boolean DEFAULT false NOT NULL,
    "requiredFacilities" text DEFAULT ''::text NOT NULL,
    "alertSensitivity" public.holiday_profiles_alertsensitivity_enum DEFAULT 'INSTANT'::public.holiday_profiles_alertsensitivity_enum NOT NULL,
    region character varying,
    "maxResults" integer DEFAULT 50 NOT NULL,
    "sortOrder" character varying DEFAULT 'PRICE_ASC'::character varying NOT NULL,
    "enabledProviders" text DEFAULT ''::text NOT NULL,
    "parkIds" text,
    "parkUrls" text,
    provider_id uuid,
    metadata jsonb
);


ALTER TABLE public.holiday_profiles OWNER TO staycation;

--
-- Name: insights; Type: TABLE; Schema: public; Owner: staycation
--

CREATE TABLE public.insights (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    type public.insights_type_enum NOT NULL,
    summary text NOT NULL,
    details jsonb NOT NULL,
    "dedupeKey" character varying NOT NULL,
    "seriesKey" character varying NOT NULL,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    fingerprint_id uuid
);


ALTER TABLE public.insights OWNER TO staycation;

--
-- Name: migrations; Type: TABLE; Schema: public; Owner: staycation
--

CREATE TABLE public.migrations (
    id integer NOT NULL,
    "timestamp" bigint NOT NULL,
    name character varying NOT NULL
);


ALTER TABLE public.migrations OWNER TO staycation;

--
-- Name: migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: staycation
--

CREATE SEQUENCE public.migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.migrations_id_seq OWNER TO staycation;

--
-- Name: migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: staycation
--

ALTER SEQUENCE public.migrations_id_seq OWNED BY public.migrations.id;


--
-- Name: price_observations; Type: TABLE; Schema: public; Owner: staycation
--

CREATE TABLE public.price_observations (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    "stayStartDate" date NOT NULL,
    "stayNights" integer NOT NULL,
    "seriesKey" character varying NOT NULL,
    "partySize" jsonb,
    "priceTotalGbp" numeric(10,2) NOT NULL,
    "pricePerNightGbp" numeric(10,2) NOT NULL,
    availability public.price_observations_availability_enum DEFAULT 'UNKNOWN'::public.price_observations_availability_enum NOT NULL,
    currency character varying DEFAULT 'GBP'::character varying NOT NULL,
    "sourceUrl" text,
    "observedAt" timestamp without time zone DEFAULT now() NOT NULL,
    provider_id uuid,
    fingerprint_id uuid,
    fetch_run_id uuid,
    accom_type_id uuid
);


ALTER TABLE public.price_observations OWNER TO staycation;

--
-- Name: provider_accom_types; Type: TABLE; Schema: public; Owner: staycation
--

CREATE TABLE public.provider_accom_types (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    "providerAccomCode" character varying,
    name character varying NOT NULL,
    "capacityMin" integer,
    "capacityMax" integer,
    provider_id uuid
);


ALTER TABLE public.provider_accom_types OWNER TO staycation;

--
-- Name: provider_parks; Type: TABLE; Schema: public; Owner: staycation
--

CREATE TABLE public.provider_parks (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    "providerParkCode" character varying,
    name character varying NOT NULL,
    region character varying,
    latitude numeric(10,7),
    longitude numeric(10,7),
    provider_id uuid
);


ALTER TABLE public.provider_parks OWNER TO staycation;

--
-- Name: providers; Type: TABLE; Schema: public; Owner: staycation
--

CREATE TABLE public.providers (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    code character varying NOT NULL,
    name character varying NOT NULL,
    "baseUrl" character varying NOT NULL,
    notes text,
    enabled boolean DEFAULT true NOT NULL,
    "checkFrequencyHours" integer DEFAULT 48 NOT NULL,
    "maxConcurrent" integer DEFAULT 2 NOT NULL,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.providers OWNER TO staycation;

--
-- Name: search_fingerprints; Type: TABLE; Schema: public; Owner: staycation
--

CREATE TABLE public.search_fingerprints (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    "canonicalHash" character varying NOT NULL,
    "canonicalJson" jsonb NOT NULL,
    "checkFrequencyHours" integer DEFAULT 48 NOT NULL,
    "lastScheduledAt" timestamp without time zone,
    enabled boolean DEFAULT true NOT NULL,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL,
    profile_id uuid,
    provider_id uuid,
    park_id uuid,
    accom_type_id uuid,
    "snoozedUntil" timestamp without time zone
);


ALTER TABLE public.search_fingerprints OWNER TO staycation;

--
-- Name: system_logs; Type: TABLE; Schema: public; Owner: staycation
--

CREATE TABLE public.system_logs (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    level public.system_logs_level_enum NOT NULL,
    message text NOT NULL,
    source character varying NOT NULL,
    details jsonb,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.system_logs OWNER TO staycation;

--
-- Name: users; Type: TABLE; Schema: public; Owner: staycation
--

CREATE TABLE public.users (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    email character varying NOT NULL,
    "passwordHash" character varying NOT NULL,
    name character varying,
    "emailVerified" boolean DEFAULT false NOT NULL,
    "verificationToken" character varying,
    "verificationTokenExpires" timestamp without time zone,
    "notificationsEnabled" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL,
    "passwordResetToken" character varying,
    "passwordResetExpires" timestamp without time zone,
    "notificationChannels" text[] DEFAULT '{email}'::text[] NOT NULL,
    "digestMode" boolean DEFAULT false NOT NULL,
    mobile character varying,
    language character varying DEFAULT 'en'::character varying NOT NULL,
    "defaultCheckFrequencyHours" integer DEFAULT 48 NOT NULL,
    role public.users_role_enum DEFAULT 'USER'::public.users_role_enum NOT NULL
);


ALTER TABLE public.users OWNER TO staycation;

--
-- Name: migrations id; Type: DEFAULT; Schema: public; Owner: staycation
--

ALTER TABLE ONLY public.migrations ALTER COLUMN id SET DEFAULT nextval('public.migrations_id_seq'::regclass);


--
-- Data for Name: alerts; Type: TABLE DATA; Schema: public; Owner: staycation
--

COPY public.alerts (id, channel, status, "dedupeKey", "errorMessage", "sentAt", "createdAt", "updatedAt", user_id, insight_id) FROM stdin;
57bce3ea-ee00-4c41-ace5-e904a68349ea	EMAIL	DISMISSED	test-alert-2026-01-04 16:33:51.182543+00	\N	\N	2026-01-04 16:33:51.182543	2026-01-04 22:25:18.891864	4012a352-1d4d-4440-bd6d-4a825593cc96	af0d7223-09aa-4672-901d-bd34fc14ebbc
\.


--
-- Data for Name: deals; Type: TABLE DATA; Schema: public; Owner: staycation
--

COPY public.deals (id, source, "sourceRef", title, "discountType", "discountValue", "voucherCode", "eligibilityTags", restrictions, "startsAt", "endsAt", confidence, "detectedAt", "lastSeenAt", provider_id) FROM stdin;
8aa9a14b-7934-4dfa-9727-d2b9ddceb167	PROVIDER_OFFERS	32cb4e4dc77d9f1ecb63ba84055c7c17578594e2025e67985eff49c4589055c4	Price dropped by £29.00 (14.2%)	PERCENT_OFF	14.22	\N	price_drop	{"stayNights": 3, "stayStartDate": "2026-01-30"}	2026-01-05 12:07:26.001	\N	0.70	2026-01-05 12:07:26.001	2026-01-05 12:07:26.001	7cc332a1-df65-4c83-a6a1-08c0b5db60c4
15c2bd8c-5e6f-4098-b57d-c5cf603aea21	PROVIDER_OFFERS	3da07af95811b6eb8e3ef5013ec0fd5d7e231c7ca128eef19c6778ddab45bccf	Price dropped by £76.00 (14.2%)	PERCENT_OFF	14.21	\N	price_drop	{"stayNights": 7, "stayStartDate": "2026-05-18"}	2026-01-05 12:07:26.049	\N	0.70	2026-01-05 12:07:26.049	2026-01-05 12:07:26.049	7cc332a1-df65-4c83-a6a1-08c0b5db60c4
c6b0d92c-ce23-43a9-9ceb-2c96e90816b0	PROVIDER_OFFERS	ab2ae6d87eac2ca12b9f2ca34be036cd7bbc3ae406c863c97b56112192885e21	ALL-INCLUSIVE FOOD & DRINKS THROUGHOUT YOUR BREAK	SALE_PRICE	\N	\N		\N	\N	\N	0.80	2026-01-05 12:07:44.588	2026-01-07 10:07:17.781	ce272ff0-dadc-4fb5-8c58-fc0d80096e57
9b637e47-8485-4052-ba6d-933d46c82e79	PROVIDER_OFFERS	8fb5ecf055508922acd8d9101a1b83098dee1ef5521a3d0263bf1a8a3746dc52	SPREAD THE COST	SALE_PRICE	\N	\N		\N	\N	\N	0.80	2026-01-05 12:07:44.441	2026-01-07 10:07:17.679	ce272ff0-dadc-4fb5-8c58-fc0d80096e57
336d5144-5afd-4274-9bd7-1743b96b1ad8	PROVIDER_OFFERS	594702ce48031d506381536d70e92db192595c807546e4e01cbccb45433fbbab	MAKE YOUR BREAK EVEN MORE SPECIAL	SALE_PRICE	\N	\N		\N	\N	\N	0.80	2026-01-05 12:07:44.595	2026-01-07 10:07:17.789	ce272ff0-dadc-4fb5-8c58-fc0d80096e57
855f2221-a641-407f-8c4c-abff345da452	PROVIDER_OFFERS	a7902c9fd700853d5b6f34f0a474b3698c331e6fe18dc43e6fb3c1e33e3d7cd7	DEALS UNDER £49	FIXED_OFF	49.00	\N		\N	\N	\N	0.80	2026-01-05 12:07:44.602	2026-01-07 10:07:17.796	ce272ff0-dadc-4fb5-8c58-fc0d80096e57
980b335e-10c5-489b-9927-591d9fcde6bf	PROVIDER_OFFERS	1285ebc7588c07c93cafa2277e6d566a8d74de412c6db6444bcfe1dd0f5362d5	DISCOVER OUR RESORTS	SALE_PRICE	\N	\N		\N	\N	\N	0.80	2026-01-05 12:07:44.668	2026-01-07 10:07:17.869	ce272ff0-dadc-4fb5-8c58-fc0d80096e57
0cac4578-3b5d-414f-8f2f-ab74a8c6d79f	PROVIDER_OFFERS	dce0a03175c7137130e93af45ea426af5eb6614dd42da79dc659af78fe746976	HAPPY HOUR	SALE_PRICE	\N	\N		\N	\N	\N	0.80	2026-01-05 12:07:44.609	2026-01-07 10:07:17.804	ce272ff0-dadc-4fb5-8c58-fc0d80096e57
ddd5aa58-33e9-484a-864e-8b13c08f6558	PROVIDER_OFFERS	189a2cb1cdb28118d167292c5e9fb77940dda91272f31241d48834f59b12f795	SAVE ON DRINKS PACKAGES	SALE_PRICE	\N	\N		\N	\N	\N	0.80	2026-01-05 12:07:44.477	2026-01-07 10:07:17.707	ce272ff0-dadc-4fb5-8c58-fc0d80096e57
3314b90e-8505-4a14-8154-7ec7410296d3	PROVIDER_OFFERS	e295a84fb28817473eb2994048f0d6b78bfe76690d9b390659dc801c3b420aa9	Manage Consent Preferences	SALE_PRICE	\N	\N		\N	\N	\N	0.80	2026-01-05 12:07:44.696	2026-01-07 10:07:17.873	ce272ff0-dadc-4fb5-8c58-fc0d80096e57
84ad3cb4-2229-43a6-8e30-71ac10521838	PROVIDER_OFFERS	5202de40a30d342fdd223d6da9a4214e88a111ee5bed127a356087359ab3d90a	Cookie List	SALE_PRICE	\N	\N		\N	\N	\N	0.80	2026-01-05 12:07:44.699	2026-01-07 10:07:17.876	ce272ff0-dadc-4fb5-8c58-fc0d80096e57
fe5fd01c-bffc-4a3b-b0aa-2d291e1eee84	PROVIDER_OFFERS	29c3c2e7a8266bf0249d4878ca38ec00fcdf01d58958d451e5eb86790683d1de	A LITTLE EXTRA?	SALE_PRICE	\N	\N		\N	\N	\N	0.80	2026-01-05 12:07:44.615	2026-01-07 10:07:17.828	ce272ff0-dadc-4fb5-8c58-fc0d80096e57
bf070e6b-c38f-4433-8504-5c3fc1b54002	PROVIDER_OFFERS	7626b143fba340c99ae83afcf083a3fa3f6d8088015a1fb92fc08f86af65d012	SAVE ON DINING PLANS	SALE_PRICE	\N	\N		\N	\N	\N	0.80	2026-01-05 12:07:44.531	2026-01-07 10:07:17.737	ce272ff0-dadc-4fb5-8c58-fc0d80096e57
78dbfaba-1f67-49bf-ba0f-7607dd22e558	PROVIDER_OFFERS	b39ff074268b516d7ee8e02e50dfb00bfee66515b13ca8311bd995458bcd6bfe	GET UP TO 25% OFF FAMILY BREAKS	PERCENT_OFF	25.00	\N		\N	\N	\N	0.80	2026-01-05 12:07:44.409	2026-01-07 10:07:17.638	ce272ff0-dadc-4fb5-8c58-fc0d80096e57
1bddad6b-7de9-4fa4-91aa-5e236a2fa199	PROVIDER_OFFERS	200e3bedd8b4e427e23dbdd7ce0eeec1e8de7a883f6ca0c5a6dac9f4d9c03d6e	FOOD & DRINK	SALE_PRICE	\N	\N		\N	\N	\N	0.80	2026-01-05 12:07:44.643	2026-01-07 10:07:17.849	ce272ff0-dadc-4fb5-8c58-fc0d80096e57
b68e37e3-40b1-420c-875b-c622b1accf55	PROVIDER_OFFERS	eff561b5f6bcf275114e781dc774ef1e392858f3f37a7710099c3dc23e80dffa	PREMIER CLUB EXCLUSIVE	SALE_PRICE	\N	\N		\N	\N	\N	0.80	2026-01-05 12:07:44.564	2026-01-07 10:07:17.77	ce272ff0-dadc-4fb5-8c58-fc0d80096e57
\.


--
-- Data for Name: fetch_runs; Type: TABLE DATA; Schema: public; Owner: staycation
--

COPY public.fetch_runs (id, "runType", "scheduledFor", "startedAt", "finishedAt", status, "httpStatus", "requestFingerprint", "responseSnapshotRef", "errorMessage", "createdAt", provider_id, fingerprint_id, "requestId", "providerStatus") FROM stdin;
c49ebb82-c9ec-45b2-a28c-01127dbb7701	MANUAL_PREVIEW	2026-01-03 19:46:38.557	2026-01-03 19:46:38.557	2026-01-03 19:46:38.557	OK	\N	\N	{"summary":{"totalCandidates":0,"matchStrong":0,"matchWeak":0,"matchUnknown":0,"mismatch":0,"lowestMatchedPriceGbp":null},"parseStats":{"total":0,"matched":0}}	\N	2026-01-03 19:46:38.558245	7cc332a1-df65-4c83-a6a1-08c0b5db60c4	\N	\N	\N
73ac6e04-a0f3-4012-86c3-6e484f3d24aa	MANUAL_PREVIEW	2026-01-03 19:46:40.858	2026-01-03 19:46:40.858	2026-01-03 19:46:40.858	OK	\N	\N	{"summary":{"totalCandidates":0,"matchStrong":0,"matchWeak":0,"matchUnknown":0,"mismatch":0,"lowestMatchedPriceGbp":null},"parseStats":{"total":0,"matched":0}}	\N	2026-01-03 19:46:40.859034	3766d1a8-c727-4acd-b84f-1461922f2c58	\N	\N	\N
371f95f1-a23d-4c57-b7f5-7e4bc39249a2	MANUAL_PREVIEW	2026-01-03 19:51:04.517	2026-01-03 19:51:04.517	2026-01-03 19:51:04.517	OK	\N	\N	{"summary":{"totalCandidates":0,"matchStrong":0,"matchWeak":0,"matchUnknown":0,"mismatch":0,"lowestMatchedPriceGbp":null},"parseStats":{"total":0,"matched":0}}	\N	2026-01-03 19:51:04.519417	7cc332a1-df65-4c83-a6a1-08c0b5db60c4	\N	\N	\N
171d02f9-d633-4ede-b808-d60cd396e0e4	MANUAL_PREVIEW	2026-01-03 19:51:06.825	2026-01-03 19:51:06.825	2026-01-03 19:51:06.825	OK	\N	\N	{"summary":{"totalCandidates":0,"matchStrong":0,"matchWeak":0,"matchUnknown":0,"mismatch":0,"lowestMatchedPriceGbp":null},"parseStats":{"total":0,"matched":0}}	\N	2026-01-03 19:51:06.826135	3766d1a8-c727-4acd-b84f-1461922f2c58	\N	\N	\N
cccf553d-756a-4f50-8aa6-d7e121f957bc	MANUAL_PREVIEW	2026-01-03 19:53:38.295	2026-01-03 19:53:38.295	2026-01-03 19:53:38.295	OK	\N	\N	{"summary":{"totalCandidates":0,"matchStrong":0,"matchWeak":0,"matchUnknown":0,"mismatch":0,"lowestMatchedPriceGbp":null},"parseStats":{"total":0,"matched":0}}	\N	2026-01-03 19:53:38.29753	7cc332a1-df65-4c83-a6a1-08c0b5db60c4	\N	\N	\N
357ea178-a608-47dd-bfa9-b3c5ebbe1f45	MANUAL_PREVIEW	2026-01-03 19:53:50.185	2026-01-03 19:53:50.185	2026-01-03 19:53:50.185	OK	\N	\N	{"summary":{"totalCandidates":0,"matchStrong":0,"matchWeak":0,"matchUnknown":0,"mismatch":0,"lowestMatchedPriceGbp":null},"parseStats":{"total":0,"matched":0}}	\N	2026-01-03 19:53:50.187023	3766d1a8-c727-4acd-b84f-1461922f2c58	\N	\N	\N
e9712089-fab1-464b-be4a-77312455bfe1	MANUAL_PREVIEW	2026-01-03 19:58:15.016	2026-01-03 19:58:15.016	2026-01-03 19:58:15.016	OK	\N	\N	{"summary":{"totalCandidates":0,"matchStrong":0,"matchWeak":0,"matchUnknown":0,"mismatch":0,"lowestMatchedPriceGbp":null},"parseStats":{"total":0,"matched":0}}	\N	2026-01-03 19:58:15.018793	7cc332a1-df65-4c83-a6a1-08c0b5db60c4	\N	\N	\N
6184868f-d2e4-4f7c-80ea-3e4ec452d2d8	MANUAL_PREVIEW	2026-01-03 19:58:26.699	2026-01-03 19:58:26.699	2026-01-03 19:58:26.699	OK	\N	\N	{"summary":{"totalCandidates":0,"matchStrong":0,"matchWeak":0,"matchUnknown":0,"mismatch":0,"lowestMatchedPriceGbp":null},"parseStats":{"total":0,"matched":0}}	\N	2026-01-03 19:58:26.70104	3766d1a8-c727-4acd-b84f-1461922f2c58	\N	\N	\N
ef6c951c-a94d-48b2-85ab-6e7d19860d9c	MANUAL_PREVIEW	2026-01-03 21:11:56.924	2026-01-03 21:11:56.924	2026-01-03 21:11:56.924	OK	\N	\N	{"summary":{"totalCandidates":0,"matchStrong":0,"matchWeak":0,"matchUnknown":0,"mismatch":0,"lowestMatchedPriceGbp":null},"parseStats":{"total":0,"matched":0}}	\N	2026-01-03 21:11:56.926054	7cc332a1-df65-4c83-a6a1-08c0b5db60c4	\N	\N	\N
2b36af89-e6dd-4871-b262-e64b5d2646c0	MANUAL_PREVIEW	2026-01-03 21:14:27.722	2026-01-03 21:14:27.722	2026-01-03 21:14:27.722	OK	\N	\N	{"summary":{"totalCandidates":0,"matchStrong":0,"matchWeak":0,"matchUnknown":0,"mismatch":0,"lowestMatchedPriceGbp":null},"parseStats":{"total":0,"matched":0}}	\N	2026-01-03 21:14:27.723793	7cc332a1-df65-4c83-a6a1-08c0b5db60c4	\N	\N	\N
f271a439-e161-43d3-94dd-28b9914dc092	MANUAL_PREVIEW	2026-01-03 21:18:02.679	2026-01-03 21:18:02.679	2026-01-03 21:18:02.679	OK	\N	\N	{"summary":{"totalCandidates":0,"matchStrong":0,"matchWeak":0,"matchUnknown":0,"mismatch":0,"lowestMatchedPriceGbp":null},"parseStats":{"total":0,"matched":0}}	\N	2026-01-03 21:18:02.681734	7cc332a1-df65-4c83-a6a1-08c0b5db60c4	\N	\N	\N
bcca0a80-58c6-4289-91d3-a6d90e981269	MANUAL_PREVIEW	2026-01-03 21:18:18.853	2026-01-03 21:18:18.853	2026-01-03 21:18:18.853	OK	\N	\N	{"summary":{"totalCandidates":0,"matchStrong":0,"matchWeak":0,"matchUnknown":0,"mismatch":0,"lowestMatchedPriceGbp":null},"parseStats":{"total":0,"matched":0}}	\N	2026-01-03 21:18:18.854011	7cc332a1-df65-4c83-a6a1-08c0b5db60c4	\N	\N	\N
71d13de1-14f4-4651-ac4e-d45f9421d3f4	MANUAL_PREVIEW	2026-01-03 21:24:57.074	2026-01-03 21:24:57.074	2026-01-03 21:24:57.074	OK	\N	\N	{"summary":{"totalCandidates":0,"matchStrong":0,"matchWeak":0,"matchUnknown":0,"mismatch":0,"lowestMatchedPriceGbp":null},"parseStats":{"total":0,"matched":0}}	\N	2026-01-03 21:24:57.076104	7cc332a1-df65-4c83-a6a1-08c0b5db60c4	\N	\N	\N
2e6dc3b5-f4e6-41c9-a6e4-d1b9dbfffeaa	MANUAL_PREVIEW	2026-01-03 21:28:11.43	2026-01-03 21:28:11.43	2026-01-03 21:28:11.43	OK	\N	\N	{"summary":{"totalCandidates":0,"matchStrong":0,"matchWeak":0,"matchUnknown":0,"mismatch":0,"lowestMatchedPriceGbp":null},"parseStats":{"total":0,"matched":0}}	\N	2026-01-03 21:28:11.432408	7cc332a1-df65-4c83-a6a1-08c0b5db60c4	\N	\N	\N
4a835977-f177-4af2-9149-be59bdcbe9c4	MANUAL_PREVIEW	2026-01-03 21:30:53.277	2026-01-03 21:30:53.277	2026-01-03 21:30:53.277	OK	\N	\N	{"summary":{"totalCandidates":0,"matchStrong":0,"matchWeak":0,"matchUnknown":0,"mismatch":0,"lowestMatchedPriceGbp":null},"parseStats":{"total":0,"matched":0}}	\N	2026-01-03 21:30:53.280144	7cc332a1-df65-4c83-a6a1-08c0b5db60c4	\N	\N	\N
22d250f6-c841-485c-a010-6d1fd1a759df	MANUAL_PREVIEW	2026-01-03 21:33:10.509	2026-01-03 21:33:10.509	2026-01-03 21:33:10.509	OK	\N	\N	{"summary":{"totalCandidates":0,"matchStrong":0,"matchWeak":0,"matchUnknown":0,"mismatch":0,"lowestMatchedPriceGbp":null},"parseStats":{"total":0,"matched":0}}	\N	2026-01-03 21:33:10.512139	7cc332a1-df65-4c83-a6a1-08c0b5db60c4	\N	\N	\N
73a547ab-e7ea-4225-a83d-a3c2d579f7cf	MANUAL_PREVIEW	2026-01-03 21:35:43.766	2026-01-03 21:35:43.766	2026-01-03 21:35:43.766	OK	\N	\N	{"summary":{"totalCandidates":0,"matchStrong":0,"matchWeak":0,"matchUnknown":0,"mismatch":0,"lowestMatchedPriceGbp":null},"parseStats":{"total":0,"matched":0}}	\N	2026-01-03 21:35:43.769289	7cc332a1-df65-4c83-a6a1-08c0b5db60c4	\N	\N	\N
6be5dcf4-ee9e-444c-bae2-843d10adc53f	MANUAL_PREVIEW	2026-01-03 21:37:31.336	2026-01-03 21:37:31.336	2026-01-03 21:37:31.336	OK	\N	\N	{"summary":{"totalCandidates":0,"matchStrong":0,"matchWeak":0,"matchUnknown":0,"mismatch":0,"lowestMatchedPriceGbp":null},"parseStats":{"total":0,"matched":0}}	\N	2026-01-03 21:37:31.33956	7cc332a1-df65-4c83-a6a1-08c0b5db60c4	\N	\N	\N
4b2a6f52-e682-466f-9413-420e02f0ded8	MANUAL_PREVIEW	2026-01-03 21:38:36.936	2026-01-03 21:38:36.936	2026-01-03 21:38:36.936	OK	\N	\N	{"summary":{"totalCandidates":0,"matchStrong":0,"matchWeak":0,"matchUnknown":0,"mismatch":0,"lowestMatchedPriceGbp":null},"parseStats":{"total":0,"matched":0}}	\N	2026-01-03 21:38:36.939461	7cc332a1-df65-4c83-a6a1-08c0b5db60c4	\N	\N	\N
18328e85-1467-4a0b-9c75-5fa0f6ea744d	MANUAL_PREVIEW	2026-01-03 21:42:06.199	2026-01-03 21:42:06.199	2026-01-03 21:42:06.199	OK	\N	\N	{"summary":{"totalCandidates":0,"matchStrong":0,"matchWeak":0,"matchUnknown":0,"mismatch":0,"lowestMatchedPriceGbp":null},"parseStats":{"total":0,"matched":0}}	\N	2026-01-03 21:42:06.202102	7cc332a1-df65-4c83-a6a1-08c0b5db60c4	\N	\N	\N
6399236f-b818-4c7a-9859-eebf82898271	MANUAL_PREVIEW	2026-01-03 21:44:08.295	2026-01-03 21:44:08.295	2026-01-03 21:44:08.295	OK	\N	\N	{"summary":{"totalCandidates":0,"matchStrong":0,"matchWeak":0,"matchUnknown":0,"mismatch":0,"lowestMatchedPriceGbp":null},"parseStats":{"total":0,"matched":0}}	\N	2026-01-03 21:44:08.298343	7cc332a1-df65-4c83-a6a1-08c0b5db60c4	\N	\N	\N
310b9e4b-b31e-45a7-a981-d1475502867c	MANUAL_PREVIEW	2026-01-03 21:48:05.016	2026-01-03 21:48:05.016	2026-01-03 21:48:05.016	OK	\N	\N	{"summary":{"totalCandidates":0,"matchStrong":0,"matchWeak":0,"matchUnknown":0,"mismatch":0,"lowestMatchedPriceGbp":null},"parseStats":{"total":0,"matched":0}}	\N	2026-01-03 21:48:05.01955	7cc332a1-df65-4c83-a6a1-08c0b5db60c4	\N	\N	\N
7174427b-7b52-4314-905b-f39dd9946a31	MANUAL_PREVIEW	2026-01-03 21:50:28.171	2026-01-03 21:50:28.171	2026-01-03 21:50:28.171	OK	\N	\N	{"summary":{"totalCandidates":0,"matchStrong":0,"matchWeak":0,"matchUnknown":0,"mismatch":0,"lowestMatchedPriceGbp":null},"parseStats":{"total":0,"matched":0}}	\N	2026-01-03 21:50:28.178643	7cc332a1-df65-4c83-a6a1-08c0b5db60c4	\N	\N	\N
d0a2b78e-9c2a-476d-8195-0a15f2291bfa	MANUAL_PREVIEW	2026-01-03 21:54:25.292	2026-01-03 21:54:25.292	2026-01-03 21:54:25.292	OK	\N	\N	{"summary":{"totalCandidates":0,"matchStrong":0,"matchWeak":0,"matchUnknown":0,"mismatch":0,"lowestMatchedPriceGbp":null},"parseStats":{"total":0,"matched":0}}	\N	2026-01-03 21:54:25.29514	7cc332a1-df65-4c83-a6a1-08c0b5db60c4	\N	\N	\N
30ec9a86-07b4-49f8-99d0-174fce1f348c	MANUAL_PREVIEW	2026-01-03 22:00:42.777	2026-01-03 22:00:42.777	2026-01-03 22:00:42.777	OK	\N	\N	{"summary":{"totalCandidates":0,"matchStrong":0,"matchWeak":0,"matchUnknown":0,"mismatch":0,"lowestMatchedPriceGbp":null},"parseStats":{"total":0,"matched":0}}	\N	2026-01-03 22:00:42.78	7cc332a1-df65-4c83-a6a1-08c0b5db60c4	\N	\N	\N
6d5bb8de-e120-40bb-ac8f-a7d813b38dbd	MANUAL_PREVIEW	2026-01-03 22:02:44.289	2026-01-03 22:02:44.289	2026-01-03 22:02:44.289	OK	\N	\N	{"summary":{"totalCandidates":12,"matchStrong":0,"matchWeak":0,"matchUnknown":0,"mismatch":12,"lowestMatchedPriceGbp":null},"parseStats":{"total":12,"matched":0}}	\N	2026-01-03 22:02:44.292284	7cc332a1-df65-4c83-a6a1-08c0b5db60c4	\N	\N	\N
4d9e0942-a8f7-4857-b3db-486922694e61	MANUAL_PREVIEW	2026-01-03 22:03:02.655	2026-01-03 22:03:02.655	2026-01-03 22:03:02.655	OK	\N	\N	{"summary":{"totalCandidates":12,"matchStrong":0,"matchWeak":0,"matchUnknown":0,"mismatch":12,"lowestMatchedPriceGbp":null},"parseStats":{"total":12,"matched":0}}	\N	2026-01-03 22:03:02.656867	7cc332a1-df65-4c83-a6a1-08c0b5db60c4	\N	\N	\N
b44e839b-7ba4-4389-bcbf-843ac6fd7e30	MANUAL_PREVIEW	2026-01-03 22:04:16.463	2026-01-03 22:04:16.463	2026-01-03 22:04:16.463	OK	\N	\N	{"summary":{"totalCandidates":12,"matchStrong":0,"matchWeak":0,"matchUnknown":0,"mismatch":12,"lowestMatchedPriceGbp":null},"parseStats":{"total":12,"matched":0}}	\N	2026-01-03 22:04:16.466902	7cc332a1-df65-4c83-a6a1-08c0b5db60c4	\N	\N	\N
212b6d4f-c2a9-4604-961c-56b91210e39b	MANUAL_PREVIEW	2026-01-03 22:06:32.566	2026-01-03 22:06:32.566	2026-01-03 22:06:32.566	OK	\N	\N	{"summary":{"totalCandidates":12,"matchStrong":0,"matchWeak":0,"matchUnknown":0,"mismatch":12,"lowestMatchedPriceGbp":null},"parseStats":{"total":12,"matched":0}}	\N	2026-01-03 22:06:32.569192	7cc332a1-df65-4c83-a6a1-08c0b5db60c4	\N	\N	\N
e4b2b439-91ab-46d3-8119-4770b6663872	MANUAL_PREVIEW	2026-01-03 22:07:25.131	2026-01-03 22:07:25.131	2026-01-03 22:07:25.131	OK	\N	\N	{"summary":{"totalCandidates":12,"matchStrong":0,"matchWeak":0,"matchUnknown":0,"mismatch":12,"lowestMatchedPriceGbp":null},"parseStats":{"total":12,"matched":0}}	\N	2026-01-03 22:07:25.133892	7cc332a1-df65-4c83-a6a1-08c0b5db60c4	\N	\N	\N
3a6dd02c-470f-466a-a501-1cf1cae1416b	MANUAL_PREVIEW	2026-01-03 22:09:26.781	2026-01-03 22:09:26.781	2026-01-03 22:09:26.781	OK	\N	\N	{"summary":{"totalCandidates":12,"matchStrong":0,"matchWeak":0,"matchUnknown":12,"mismatch":0,"lowestMatchedPriceGbp":null},"parseStats":{"total":12,"matched":0}}	\N	2026-01-03 22:09:26.782921	7cc332a1-df65-4c83-a6a1-08c0b5db60c4	\N	\N	\N
5e8c0d52-07ad-4ec2-9941-253e1fdb464c	MANUAL_PREVIEW	2026-01-03 22:10:23.823	2026-01-03 22:10:23.823	2026-01-03 22:10:23.823	OK	\N	\N	{"summary":{"totalCandidates":12,"matchStrong":0,"matchWeak":0,"matchUnknown":12,"mismatch":0,"lowestMatchedPriceGbp":null},"parseStats":{"total":12,"matched":0}}	\N	2026-01-03 22:10:23.826667	7cc332a1-df65-4c83-a6a1-08c0b5db60c4	\N	\N	\N
6251a449-8219-4498-99bb-43a4ca7ae9c1	MANUAL_PREVIEW	2026-01-03 22:11:48.627	2026-01-03 22:11:48.627	2026-01-03 22:11:48.627	OK	\N	\N	{"summary":{"totalCandidates":12,"matchStrong":0,"matchWeak":0,"matchUnknown":12,"mismatch":0,"lowestMatchedPriceGbp":null},"parseStats":{"total":12,"matched":0}}	\N	2026-01-03 22:11:48.629843	7cc332a1-df65-4c83-a6a1-08c0b5db60c4	\N	\N	\N
a57941e6-1cd9-4aef-97da-9989c8ba1243	MANUAL_PREVIEW	2026-01-03 22:19:02.089	2026-01-03 22:19:02.089	2026-01-03 22:19:02.089	OK	\N	\N	{"summary":{"totalCandidates":12,"matchStrong":12,"matchWeak":0,"matchUnknown":0,"mismatch":0,"lowestMatchedPriceGbp":134},"parseStats":{"total":12,"matched":12}}	\N	2026-01-03 22:19:02.092844	7cc332a1-df65-4c83-a6a1-08c0b5db60c4	\N	\N	\N
5b018423-36a6-40f5-baa2-f46dc981619a	MANUAL_PREVIEW	2026-01-03 22:25:05.955	2026-01-03 22:25:05.955	2026-01-03 22:25:05.955	OK	\N	\N	{"summary":{"totalCandidates":12,"matchStrong":12,"matchWeak":0,"matchUnknown":0,"mismatch":0,"lowestMatchedPriceGbp":134},"parseStats":{"total":12,"matched":12}}	\N	2026-01-03 22:25:05.956217	7cc332a1-df65-4c83-a6a1-08c0b5db60c4	\N	\N	\N
5ca399e3-6ae2-4c3e-ba66-0dd4aaa5c4c3	MANUAL_PREVIEW	2026-01-03 22:33:32.658	2026-01-03 22:33:32.658	2026-01-03 22:33:32.658	OK	\N	\N	{"summary":{"totalCandidates":12,"matchStrong":0,"matchWeak":0,"matchUnknown":0,"mismatch":12,"lowestMatchedPriceGbp":null},"parseStats":{"total":12,"matched":0}}	\N	2026-01-03 22:33:32.658773	7cc332a1-df65-4c83-a6a1-08c0b5db60c4	\N	\N	\N
5ac77eee-1d79-4e8e-b6d5-838afc6daabf	MANUAL_PREVIEW	2026-01-03 22:33:35.047	2026-01-03 22:33:35.047	2026-01-03 22:33:35.047	OK	\N	\N	{"summary":{"totalCandidates":0,"matchStrong":0,"matchWeak":0,"matchUnknown":0,"mismatch":0,"lowestMatchedPriceGbp":null},"parseStats":{"total":0,"matched":0}}	\N	2026-01-03 22:33:35.048496	3766d1a8-c727-4acd-b84f-1461922f2c58	\N	\N	\N
bd3f1b92-5e18-4952-ba56-6876b3515400	MANUAL_PREVIEW	2026-01-03 22:50:35.129	2026-01-03 22:50:35.129	2026-01-03 22:50:35.129	OK	\N	\N	{"summary":{"totalCandidates":12,"matchStrong":0,"matchWeak":0,"matchUnknown":0,"mismatch":12,"lowestMatchedPriceGbp":null},"parseStats":{"total":12,"matched":0}}	\N	2026-01-03 22:50:35.12955	7cc332a1-df65-4c83-a6a1-08c0b5db60c4	\N	\N	\N
f1791261-f8c1-4f59-8f51-a8477f52179b	MANUAL_PREVIEW	2026-01-03 22:52:21.793	2026-01-03 22:52:21.793	2026-01-03 22:52:21.793	OK	\N	\N	{"summary":{"totalCandidates":12,"matchStrong":0,"matchWeak":0,"matchUnknown":0,"mismatch":12,"lowestMatchedPriceGbp":null},"parseStats":{"total":12,"matched":0}}	\N	2026-01-03 22:52:21.795748	7cc332a1-df65-4c83-a6a1-08c0b5db60c4	\N	\N	\N
9ab2afc5-2e66-4268-a496-7fbe1e4cb625	MANUAL_PREVIEW	2026-01-03 22:54:33.992	2026-01-03 22:54:33.992	2026-01-03 22:54:33.992	OK	\N	\N	{"summary":{"totalCandidates":12,"matchStrong":0,"matchWeak":0,"matchUnknown":0,"mismatch":12,"lowestMatchedPriceGbp":null},"parseStats":{"total":12,"matched":0}}	\N	2026-01-03 22:54:33.995247	7cc332a1-df65-4c83-a6a1-08c0b5db60c4	\N	\N	\N
39b7a937-fdc4-4c8c-97f7-62c0f6fbeae1	MANUAL_PREVIEW	2026-01-03 22:55:26.045	2026-01-03 22:55:26.045	2026-01-03 22:55:26.045	OK	\N	\N	{"summary":{"totalCandidates":12,"matchStrong":0,"matchWeak":0,"matchUnknown":0,"mismatch":12,"lowestMatchedPriceGbp":null},"parseStats":{"total":12,"matched":0}}	\N	2026-01-03 22:55:26.046918	7cc332a1-df65-4c83-a6a1-08c0b5db60c4	\N	\N	\N
40b9b7fb-0a47-47bd-960c-2062558b8a98	MANUAL_PREVIEW	2026-01-03 22:56:26.641	2026-01-03 22:56:26.641	2026-01-03 22:56:26.641	OK	\N	\N	{"summary":{"totalCandidates":12,"matchStrong":0,"matchWeak":0,"matchUnknown":0,"mismatch":12,"lowestMatchedPriceGbp":null},"parseStats":{"total":12,"matched":0}}	\N	2026-01-03 22:56:26.644095	7cc332a1-df65-4c83-a6a1-08c0b5db60c4	\N	\N	\N
a4b6500c-8d4c-4b12-8552-468ecb52d82f	MANUAL_PREVIEW	2026-01-03 22:56:44.449	2026-01-03 22:56:44.449	2026-01-03 22:56:44.449	OK	\N	\N	{"summary":{"totalCandidates":12,"matchStrong":12,"matchWeak":0,"matchUnknown":0,"mismatch":0,"lowestMatchedPriceGbp":134},"parseStats":{"total":12,"matched":12}}	\N	2026-01-03 22:56:44.451293	7cc332a1-df65-4c83-a6a1-08c0b5db60c4	\N	\N	\N
a650b28e-9ba9-480a-9bd2-62cf577005df	MANUAL_PREVIEW	2026-01-03 22:56:47.384	2026-01-03 22:56:47.384	2026-01-03 22:56:47.384	OK	\N	\N	{"summary":{"totalCandidates":12,"matchStrong":0,"matchWeak":0,"matchUnknown":0,"mismatch":12,"lowestMatchedPriceGbp":null},"parseStats":{"total":12,"matched":0}}	\N	2026-01-03 22:56:47.385188	7cc332a1-df65-4c83-a6a1-08c0b5db60c4	\N	\N	\N
4764d776-75b8-452d-9a2c-486f780374ca	MANUAL_PREVIEW	2026-01-03 22:56:49.718	2026-01-03 22:56:49.718	2026-01-03 22:56:49.718	OK	\N	\N	{"summary":{"totalCandidates":0,"matchStrong":0,"matchWeak":0,"matchUnknown":0,"mismatch":0,"lowestMatchedPriceGbp":null},"parseStats":{"total":0,"matched":0}}	\N	2026-01-03 22:56:49.718588	3766d1a8-c727-4acd-b84f-1461922f2c58	\N	\N	\N
cb8ccec0-2adb-40e3-8b0e-96dbd7bf85ca	MANUAL_PREVIEW	2026-01-03 22:57:29.567	2026-01-03 22:57:29.567	2026-01-03 22:57:29.567	OK	\N	\N	{"summary":{"totalCandidates":12,"matchStrong":0,"matchWeak":0,"matchUnknown":0,"mismatch":12,"lowestMatchedPriceGbp":null},"parseStats":{"total":12,"matched":0}}	\N	2026-01-03 22:57:29.56932	7cc332a1-df65-4c83-a6a1-08c0b5db60c4	\N	\N	\N
cdf55c54-12a4-47c7-ac6c-e10f8d8e7732	MANUAL_PREVIEW	2026-01-03 22:59:03.729	2026-01-03 22:59:03.729	2026-01-03 22:59:03.729	OK	\N	\N	{"summary":{"totalCandidates":12,"matchStrong":0,"matchWeak":0,"matchUnknown":0,"mismatch":12,"lowestMatchedPriceGbp":null},"parseStats":{"total":12,"matched":0}}	\N	2026-01-03 22:59:03.732266	7cc332a1-df65-4c83-a6a1-08c0b5db60c4	\N	\N	\N
886222f1-06cd-4882-9ba2-df551e2d5873	MANUAL_PREVIEW	2026-01-03 23:00:17.852	2026-01-03 23:00:17.852	2026-01-03 23:00:17.852	OK	\N	\N	{"summary":{"totalCandidates":12,"matchStrong":0,"matchWeak":0,"matchUnknown":0,"mismatch":12,"lowestMatchedPriceGbp":null},"parseStats":{"total":12,"matched":0}}	\N	2026-01-03 23:00:17.854943	7cc332a1-df65-4c83-a6a1-08c0b5db60c4	\N	\N	\N
f11ae4e7-8f8f-48ef-8d19-b668db056536	MANUAL_PREVIEW	2026-01-03 23:02:08.566	2026-01-03 23:02:08.566	2026-01-03 23:02:08.566	OK	\N	\N	{"summary":{"totalCandidates":12,"matchStrong":12,"matchWeak":0,"matchUnknown":0,"mismatch":0,"lowestMatchedPriceGbp":305},"parseStats":{"total":12,"matched":12}}	\N	2026-01-03 23:02:08.568338	7cc332a1-df65-4c83-a6a1-08c0b5db60c4	\N	\N	\N
12d37b3d-6cd6-4b58-8e32-18acd30b98f1	MANUAL_PREVIEW	2026-01-03 23:04:39.521	2026-01-03 23:04:39.521	2026-01-03 23:04:39.521	OK	\N	\N	{"summary":{"totalCandidates":12,"matchStrong":12,"matchWeak":0,"matchUnknown":0,"mismatch":0,"lowestMatchedPriceGbp":305},"parseStats":{"total":12,"matched":12}}	\N	2026-01-03 23:04:39.524022	7cc332a1-df65-4c83-a6a1-08c0b5db60c4	\N	\N	\N
a501c7e1-6c73-4c6d-8293-550dcf140cb8	MANUAL_PREVIEW	2026-01-03 23:06:53.447	2026-01-03 23:06:53.447	2026-01-03 23:06:53.447	OK	\N	\N	{"summary":{"totalCandidates":12,"matchStrong":12,"matchWeak":0,"matchUnknown":0,"mismatch":0,"lowestMatchedPriceGbp":305},"parseStats":{"total":12,"matched":12}}	\N	2026-01-03 23:06:53.450706	7cc332a1-df65-4c83-a6a1-08c0b5db60c4	\N	\N	\N
f70b33d5-06e0-4677-9e9f-841d5a42efdf	MANUAL_PREVIEW	2026-01-03 23:08:58.217	2026-01-03 23:08:58.217	2026-01-03 23:08:58.217	OK	\N	\N	{"summary":{"totalCandidates":12,"matchStrong":12,"matchWeak":0,"matchUnknown":0,"mismatch":0,"lowestMatchedPriceGbp":305},"parseStats":{"total":12,"matched":12}}	\N	2026-01-03 23:08:58.219618	7cc332a1-df65-4c83-a6a1-08c0b5db60c4	\N	\N	\N
4acbe372-6840-4f7f-8b81-2f3d6a263c19	MANUAL_PREVIEW	2026-01-03 23:11:11.915	2026-01-03 23:11:11.915	2026-01-03 23:11:11.915	OK	\N	\N	{"summary":{"totalCandidates":12,"matchStrong":12,"matchWeak":0,"matchUnknown":0,"mismatch":0,"lowestMatchedPriceGbp":305},"parseStats":{"total":12,"matched":12}}	\N	2026-01-03 23:11:11.917645	7cc332a1-df65-4c83-a6a1-08c0b5db60c4	\N	\N	\N
abca5931-ed3e-49cc-81ff-33697f13b816	MANUAL_PREVIEW	2026-01-03 23:26:02.335	2026-01-03 23:26:02.335	2026-01-03 23:26:02.335	OK	\N	\N	{"summary":{"totalCandidates":12,"matchStrong":12,"matchWeak":0,"matchUnknown":0,"mismatch":0,"lowestMatchedPriceGbp":305},"parseStats":{"total":12,"matched":12}}	\N	2026-01-03 23:26:02.338633	7cc332a1-df65-4c83-a6a1-08c0b5db60c4	\N	\N	\N
e33d0b6b-cfeb-437c-833f-acf5522fe718	MANUAL_PREVIEW	2026-01-03 23:36:55.203	2026-01-03 23:36:55.203	2026-01-03 23:36:55.203	OK	\N	\N	{"summary":{"totalCandidates":12,"matchStrong":12,"matchWeak":0,"matchUnknown":0,"mismatch":0,"lowestMatchedPriceGbp":305},"parseStats":{"total":12,"matched":12}}	\N	2026-01-03 23:36:55.206277	7cc332a1-df65-4c83-a6a1-08c0b5db60c4	\N	\N	\N
5ffa99b9-355e-4edd-ac4d-a07e2a4d25a5	MANUAL_PREVIEW	2026-01-03 23:38:24.719	2026-01-03 23:38:24.719	2026-01-03 23:38:24.719	OK	\N	\N	{"summary":{"totalCandidates":12,"matchStrong":12,"matchWeak":0,"matchUnknown":0,"mismatch":0,"lowestMatchedPriceGbp":305},"parseStats":{"total":12,"matched":12}}	\N	2026-01-03 23:38:24.721051	7cc332a1-df65-4c83-a6a1-08c0b5db60c4	\N	\N	\N
0b370f75-b828-4702-888f-e36cdb5359ac	MANUAL_PREVIEW	2026-01-03 23:38:40.662	2026-01-03 23:38:40.662	2026-01-03 23:38:40.662	OK	\N	\N	{"summary":{"totalCandidates":12,"matchStrong":12,"matchWeak":0,"matchUnknown":0,"mismatch":0,"lowestMatchedPriceGbp":134},"parseStats":{"total":12,"matched":12}}	\N	2026-01-03 23:38:40.66492	7cc332a1-df65-4c83-a6a1-08c0b5db60c4	\N	\N	\N
df204fcc-0938-4dcc-8c57-b9544b21a792	SEARCH	2026-01-05 11:41:09.421	2026-01-05 11:41:09.421	2026-01-05 11:41:57.063	OK	200	\N	\N	\N	2026-01-05 11:41:56.920268	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	\N	\N
f72602d3-4f9e-44c1-87ce-d10c50472228	SEARCH	2026-01-05 10:52:43.529	2026-01-05 10:52:43.529	2026-01-05 10:53:31.108	ERROR	200	\N	\N	Cannot perform update query because update values are not defined. Call "qb.set(...)" method to specify updated values.	2026-01-05 10:53:31.109213	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	\N	\N
32b08a84-36d3-4946-be64-34f6f97d011a	SEARCH	2026-01-05 11:01:34.827	2026-01-05 11:01:34.827	2026-01-05 11:02:22.214	ERROR	200	\N	\N	Cannot perform update query because update values are not defined. Call "qb.set(...)" method to specify updated values.	2026-01-05 11:02:22.215027	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	\N	\N
8d2b19bd-8bfd-4c55-983e-e2d87f4445e0	SEARCH	2026-01-05 12:16:08.973	2026-01-05 12:16:08.973	2026-01-05 12:17:11.64	OK	200	\N	\N	\N	2026-01-05 12:17:11.475286	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	\N	\N
43da5246-6d75-4734-ad4a-cc8cc015b5b6	SEARCH	2026-01-05 12:37:16.798	2026-01-05 12:37:16.798	2026-01-05 12:38:17.774	OK	200	\N	\N	\N	2026-01-05 12:38:17.673349	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	\N	\N
295efc31-ae9b-433f-b126-4e8f21a3b96f	SEARCH	2026-01-05 22:12:41.951	2026-01-05 22:12:41.951	\N	PARSE_FAILED	\N	\N	\N	No results parsed from provider response	2026-01-05 22:13:44.696309	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	\N	PARSE_FAILED
e8c8c114-8f2d-4701-a8e4-e9a3611dc3a8	SEARCH	2026-01-07 10:02:23.692	2026-01-07 10:02:23.692	\N	PARSE_FAILED	\N	\N	\N	No results parsed from provider response	2026-01-07 10:02:31.635483	7d013472-9c19-4fe6-aa1d-85d56b8e3701	26cbfcdb-c857-4633-ae19-531968b0d330	\N	PARSE_FAILED
685d83d0-96d7-4077-9803-e02eb0bdf733	SEARCH	2026-01-07 11:05:02.07	2026-01-07 11:05:02.07	\N	PARSE_FAILED	\N	\N	\N	No results parsed from provider response	2026-01-07 11:06:34.491706	7d013472-9c19-4fe6-aa1d-85d56b8e3701	26cbfcdb-c857-4633-ae19-531968b0d330	\N	PARSE_FAILED
0e112689-3a7c-4d8a-9815-15269c72967f	SEARCH	2026-01-07 12:02:01.164	2026-01-07 12:02:01.164	\N	PARSE_FAILED	\N	\N	\N	No results parsed from provider response	2026-01-07 12:03:32.071896	7d013472-9c19-4fe6-aa1d-85d56b8e3701	26cbfcdb-c857-4633-ae19-531968b0d330	\N	PARSE_FAILED
a02232bf-5c58-4353-ae4a-5dd004c93e88	SEARCH	2026-01-07 12:38:46.837	2026-01-07 12:38:46.837	2026-01-07 12:40:19.559	OK	\N	\N	\N	\N	2026-01-07 12:40:19.559673	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	\N	OK
5a50a75a-98b5-4024-8b12-d2b126f02ed7	SEARCH	2026-01-07 13:01:00.858	2026-01-07 13:01:00.858	2026-01-07 13:02:31.782	OK	\N	\N	\N	\N	2026-01-07 13:02:31.78297	7d013472-9c19-4fe6-aa1d-85d56b8e3701	26cbfcdb-c857-4633-ae19-531968b0d330	\N	OK
6486e12b-60fb-4f2d-9f13-f8d358855377	SEARCH	2026-01-07 13:19:12.919	2026-01-07 13:19:12.919	2026-01-07 13:20:45.567	OK	\N	\N	\N	\N	2026-01-07 13:20:45.56759	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	\N	OK
5aa15296-04de-4c7e-88e8-493f044806e1	SEARCH	2026-01-07 14:06:28.382	2026-01-07 14:06:28.382	2026-01-07 14:06:38.504	OK	\N	\N	\N	\N	2026-01-07 14:06:38.504666	7d013472-9c19-4fe6-aa1d-85d56b8e3701	26cbfcdb-c857-4633-ae19-531968b0d330	\N	OK
0c4d6c28-401c-40fd-a5b6-3e6a4370297b	SEARCH	2026-01-07 14:15:19.457	2026-01-07 14:15:19.457	2026-01-07 14:15:29.601	OK	\N	\N	\N	\N	2026-01-07 14:15:29.602271	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	\N	OK
6acb9757-2b93-419d-9664-61995f98638f	SEARCH	2026-01-07 14:33:24.593	2026-01-07 14:33:24.593	2026-01-07 14:33:35.528	OK	\N	\N	\N	\N	2026-01-07 14:33:24.622287	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	\N	OK
b6fa6290-2ff1-4e7c-8415-2d3e45ddeede	SEARCH	2026-01-07 14:34:32.511	2026-01-07 14:34:32.511	2026-01-07 14:34:41.975	OK	\N	\N	\N	\N	2026-01-07 14:34:32.552079	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	\N	OK
cbe50992-1f66-425d-b212-b04563056ab5	SEARCH	2026-01-07 14:40:02.213	2026-01-07 14:40:02.213	2026-01-07 14:40:11.493	OK	\N	\N	\N	\N	2026-01-07 14:40:02.241744	7d013472-9c19-4fe6-aa1d-85d56b8e3701	26cbfcdb-c857-4633-ae19-531968b0d330	\N	OK
6eb69a68-1178-46a6-b51d-14506ad90aa6	SEARCH	2026-01-07 14:54:29.895	2026-01-07 14:54:29.895	2026-01-07 14:54:39.495	OK	\N	\N	\N	\N	2026-01-07 14:54:29.897933	7d013472-9c19-4fe6-aa1d-85d56b8e3701	26cbfcdb-c857-4633-ae19-531968b0d330	\N	OK
\.


--
-- Data for Name: holiday_profiles; Type: TABLE DATA; Schema: public; Owner: staycation
--

COPY public.holiday_profiles (id, name, "partySizeAdults", "partySizeChildren", "flexType", "dateStart", "dateEnd", "durationNightsMin", "durationNightsMax", "peakTolerance", "budgetCeilingGbp", enabled, "createdAt", "updatedAt", user_id, pets, "accommodationType", "minBedrooms", tier, "stayPattern", "schoolHolidays", "petsNumber", "stepFreeAccess", "accessibleBathroom", "requiredFacilities", "alertSensitivity", region, "maxResults", "sortOrder", "enabledProviders", "parkIds", "parkUrls", provider_id, metadata) FROM stdin;
ee7c526f-bfad-4359-a6e6-732005ded367	Test CenterParcs 	2	0	RANGE	2026-03-16	2026-03-20	4	4	MIXED	2500.00	t	2026-01-07 09:54:56.707244	2026-01-07 09:54:56.707244	4012a352-1d4d-4440-bd6d-4a825593cc96	f	ANY	0	STANDARD	ANY	ALLOW	0	f	f		INSTANT	\N	50	PRICE_ASC		SF	\N	7d013472-9c19-4fe6-aa1d-85d56b8e3701	{"lodges": [{"dogs": 0, "adults": 2, "infants": 0, "bedrooms": 1, "children": 0, "toddlers": 0}], "features": [], "accomTypes": []}
d52beef0-76ad-424a-8ecd-a33c573be2d7	Scarlett & Tom break	2	0	RANGE	2026-06-12	2026-06-15	3	7	MIXED	700.00	t	2026-01-04 22:26:33.85765	2026-01-07 14:23:50.273071	4012a352-1d4d-4440-bd6d-4a825593cc96	f	ANY	0	STANDARD	ANY	ALLOW	0	f	f		DIGEST	Sherwood	50	PRICE_ASC	centerparcs		\N	\N	\N
\.


--
-- Data for Name: insights; Type: TABLE DATA; Schema: public; Owner: staycation
--

COPY public.insights (id, type, summary, details, "dedupeKey", "seriesKey", "createdAt", fingerprint_id) FROM stdin;
af0d7223-09aa-4672-901d-bd34fc14ebbc	PRICE_DROP_PERCENT	Price dropped by £150 (15%) for your CenterParcs trip!	{"stayNights": 7, "percentDrop": 15, "absoluteDrop": 150, "currentPrice": 850, "previousPrice": 1000}	test-dedupe-2026-01-04 16:33:51.182543+00	test-series-key	2026-01-04 16:33:51.182543	\N
\.


--
-- Data for Name: migrations; Type: TABLE DATA; Schema: public; Owner: staycation
--

COPY public.migrations (id, "timestamp", name) FROM stdin;
3	1767619133119	AdminDashboard1767619133119
\.


--
-- Data for Name: price_observations; Type: TABLE DATA; Schema: public; Owner: staycation
--

COPY public.price_observations (id, "stayStartDate", "stayNights", "seriesKey", "partySize", "priceTotalGbp", "pricePerNightGbp", availability, currency, "sourceUrl", "observedAt", provider_id, fingerprint_id, fetch_run_id, accom_type_id) FROM stdin;
c446d948-9920-4126-96ad-312dcb7cef9c	2026-06-12	3	44fec3def3c5dffcd72a0c3e52987cfeb6d143951169739915ef1baef6e80075	{"adults": 2, "children": 0}	579.00	193.00	AVAILABLE	GBP	https://www.centerparcs.co.uk/breaks-we-offer/search.html/2/SF/12-06-2026/3/-/-/1/2/0/0/0/0/N	2026-01-07 14:33:35.437991	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	6acb9757-2b93-419d-9664-61995f98638f	\N
ebf95a32-746b-4cb8-b3ad-82303c6f4b46	2026-06-12	3	2d3c1107e3b146085b2e1eaf716a8fa23b510dda7aac9adf71c85060e9f5e672	{"adults": 2, "children": 0}	599.00	199.67	AVAILABLE	GBP	https://www.centerparcs.co.uk/breaks-we-offer/search.html/2/SF/12-06-2026/3/-/-/1/2/0/0/0/0/N	2026-01-07 14:33:35.474364	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	6acb9757-2b93-419d-9664-61995f98638f	\N
e8dc94ca-0674-44b0-ac49-ba01d6dc87c0	2026-06-12	3	74db2c251d43129ef5a957c5d6792b3839278dd9e939b2ac116db6cf38c95a4b	{"adults": 2, "children": 0}	599.00	199.67	AVAILABLE	GBP	https://www.centerparcs.co.uk/breaks-we-offer/search.html/2/SF/12-06-2026/3/-/-/1/2/0/0/0/0/N	2026-01-07 14:33:35.477159	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	6acb9757-2b93-419d-9664-61995f98638f	\N
9c969f18-e09b-4802-afcc-1ce41d00b13c	2026-06-12	3	335688784763867900e191ade70145f288cbdd4a071a0704689ce36cb50f8351	{"adults": 2, "children": 0}	619.00	206.33	AVAILABLE	GBP	https://www.centerparcs.co.uk/breaks-we-offer/search.html/2/SF/12-06-2026/3/-/-/1/2/0/0/0/0/N	2026-01-07 14:33:35.479262	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	6acb9757-2b93-419d-9664-61995f98638f	\N
07b03761-e861-4005-95a7-489c30a926ef	2026-06-12	3	6247c367548d120e059fa322e286eb51190d2306b6d000af623336323aab5675	{"adults": 2, "children": 0}	839.00	279.67	AVAILABLE	GBP	https://www.centerparcs.co.uk/breaks-we-offer/search.html/2/SF/12-06-2026/3/-/-/1/2/0/0/0/0/N	2026-01-07 14:33:35.485478	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	6acb9757-2b93-419d-9664-61995f98638f	\N
6e69fe11-e4e0-4899-be6c-0433d12bee3e	2026-06-12	3	69250692e039b66bdad159828e2f57451a82712a04a3e15042ff28b252bd2f11	{"adults": 2, "children": 0}	729.00	243.00	AVAILABLE	GBP	https://www.centerparcs.co.uk/breaks-we-offer/search.html/2/SF/12-06-2026/3/-/-/1/2/0/0/0/0/N	2026-01-07 14:33:35.490491	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	6acb9757-2b93-419d-9664-61995f98638f	\N
7f41080f-581d-49c4-b666-ffe93cc4e913	2026-06-12	3	571fb5ebfa753d6f355b0892b6f64143ac1dbe619a83d0d8834958f21da9b615	{"adults": 2, "children": 0}	849.00	283.00	AVAILABLE	GBP	https://www.centerparcs.co.uk/breaks-we-offer/search.html/2/SF/12-06-2026/3/-/-/1/2/0/0/0/0/N	2026-01-07 14:33:35.494071	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	6acb9757-2b93-419d-9664-61995f98638f	\N
af1b8089-b846-4c21-b2b9-7d0b527f590c	2026-06-12	3	ea64c52ed53c8d258f8e18308243d0aa6e1d42280023052de2510d506ca12acd	{"adults": 2, "children": 0}	579.00	193.00	AVAILABLE	GBP	https://www.centerparcs.co.uk	2026-01-05 11:41:56.972203	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	df204fcc-0938-4dcc-8c57-b9544b21a792	\N
b2c4c064-e371-423e-a07f-5afeff764258	2026-06-12	3	ea64c52ed53c8d258f8e18308243d0aa6e1d42280023052de2510d506ca12acd	{"adults": 2, "children": 0}	599.00	199.67	AVAILABLE	GBP	https://www.centerparcs.co.uk	2026-01-05 11:41:56.980011	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	df204fcc-0938-4dcc-8c57-b9544b21a792	\N
300aa5f7-e5d8-4b62-9fc5-c58e218bfa58	2026-06-12	3	ea64c52ed53c8d258f8e18308243d0aa6e1d42280023052de2510d506ca12acd	{"adults": 2, "children": 0}	599.00	199.67	AVAILABLE	GBP	https://www.centerparcs.co.uk	2026-01-05 11:41:56.988593	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	df204fcc-0938-4dcc-8c57-b9544b21a792	\N
edad0557-0248-433c-9ad2-8516ca5de846	2026-06-12	3	ea64c52ed53c8d258f8e18308243d0aa6e1d42280023052de2510d506ca12acd	{"adults": 2, "children": 0}	619.00	206.33	AVAILABLE	GBP	https://www.centerparcs.co.uk	2026-01-05 11:41:56.992242	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	df204fcc-0938-4dcc-8c57-b9544b21a792	\N
5d582036-25b9-4d51-bfa7-e4806ce28ca4	2026-06-12	3	ea64c52ed53c8d258f8e18308243d0aa6e1d42280023052de2510d506ca12acd	{"adults": 2, "children": 0}	839.00	279.67	AVAILABLE	GBP	https://www.centerparcs.co.uk	2026-01-05 11:41:56.996372	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	df204fcc-0938-4dcc-8c57-b9544b21a792	\N
d19d7a11-1755-4171-828b-431edcd1879e	2026-06-12	3	ea64c52ed53c8d258f8e18308243d0aa6e1d42280023052de2510d506ca12acd	{"adults": 2, "children": 0}	669.00	223.00	AVAILABLE	GBP	https://www.centerparcs.co.uk	2026-01-05 11:41:57.000448	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	df204fcc-0938-4dcc-8c57-b9544b21a792	\N
8a04a09f-8dc2-4d6a-b942-3c4adc134a01	2026-06-12	3	ea64c52ed53c8d258f8e18308243d0aa6e1d42280023052de2510d506ca12acd	{"adults": 2, "children": 0}	749.00	249.67	AVAILABLE	GBP	https://www.centerparcs.co.uk	2026-01-05 11:41:57.00381	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	df204fcc-0938-4dcc-8c57-b9544b21a792	\N
8e5152e6-f87b-406b-bd5f-98f4fd40165d	2026-06-12	3	ea64c52ed53c8d258f8e18308243d0aa6e1d42280023052de2510d506ca12acd	{"adults": 2, "children": 0}	749.00	249.67	AVAILABLE	GBP	https://www.centerparcs.co.uk	2026-01-05 11:41:57.006654	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	df204fcc-0938-4dcc-8c57-b9544b21a792	\N
d6014104-e554-454e-9ae4-2c708327a7a7	2026-06-12	3	ea64c52ed53c8d258f8e18308243d0aa6e1d42280023052de2510d506ca12acd	{"adults": 2, "children": 0}	799.00	266.33	AVAILABLE	GBP	https://www.centerparcs.co.uk	2026-01-05 11:41:57.01003	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	df204fcc-0938-4dcc-8c57-b9544b21a792	\N
011c6e9a-fbfc-4f74-a37c-367689a09497	2026-06-12	3	ea64c52ed53c8d258f8e18308243d0aa6e1d42280023052de2510d506ca12acd	{"adults": 2, "children": 0}	829.00	276.33	AVAILABLE	GBP	https://www.centerparcs.co.uk	2026-01-05 11:41:57.013789	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	df204fcc-0938-4dcc-8c57-b9544b21a792	\N
f3828858-6351-4c71-bb0a-65eb5d9a5a87	2026-06-12	3	ea64c52ed53c8d258f8e18308243d0aa6e1d42280023052de2510d506ca12acd	{"adults": 2, "children": 0}	1019.00	339.67	AVAILABLE	GBP	https://www.centerparcs.co.uk	2026-01-05 11:41:57.016037	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	df204fcc-0938-4dcc-8c57-b9544b21a792	\N
8d2f9d3d-c6b1-4f43-b145-e229cb851e0f	2026-06-12	3	ea64c52ed53c8d258f8e18308243d0aa6e1d42280023052de2510d506ca12acd	{"adults": 2, "children": 0}	799.00	266.33	AVAILABLE	GBP	https://www.centerparcs.co.uk	2026-01-05 11:41:57.018737	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	df204fcc-0938-4dcc-8c57-b9544b21a792	\N
0c783b09-171f-4aa5-87ad-e0dbc24ecd4d	2026-06-12	3	ea64c52ed53c8d258f8e18308243d0aa6e1d42280023052de2510d506ca12acd	{"adults": 2, "children": 0}	899.00	299.67	AVAILABLE	GBP	https://www.centerparcs.co.uk	2026-01-05 11:41:57.022037	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	df204fcc-0938-4dcc-8c57-b9544b21a792	\N
6d57a096-a5ce-47fa-a748-a21e66b21c1d	2026-06-12	3	ea64c52ed53c8d258f8e18308243d0aa6e1d42280023052de2510d506ca12acd	{"adults": 2, "children": 0}	1049.00	349.67	AVAILABLE	GBP	https://www.centerparcs.co.uk	2026-01-05 11:41:57.02479	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	df204fcc-0938-4dcc-8c57-b9544b21a792	\N
2030bd1f-fb1e-424c-b0be-ecb05f27c317	2026-06-12	3	ea64c52ed53c8d258f8e18308243d0aa6e1d42280023052de2510d506ca12acd	{"adults": 2, "children": 0}	1099.00	366.33	AVAILABLE	GBP	https://www.centerparcs.co.uk	2026-01-05 11:41:57.028062	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	df204fcc-0938-4dcc-8c57-b9544b21a792	\N
65473641-ff52-4b1f-a2bd-18053d1c0144	2026-06-12	3	ea64c52ed53c8d258f8e18308243d0aa6e1d42280023052de2510d506ca12acd	{"adults": 2, "children": 0}	1189.00	396.33	AVAILABLE	GBP	https://www.centerparcs.co.uk	2026-01-05 11:41:57.031003	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	df204fcc-0938-4dcc-8c57-b9544b21a792	\N
f8b871e3-b5e5-466a-a5cf-da98576e3e94	2026-06-12	3	ea64c52ed53c8d258f8e18308243d0aa6e1d42280023052de2510d506ca12acd	{"adults": 2, "children": 0}	1649.00	549.67	AVAILABLE	GBP	https://www.centerparcs.co.uk	2026-01-05 11:41:57.034246	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	df204fcc-0938-4dcc-8c57-b9544b21a792	\N
d7db7138-aee4-4257-8240-b1620a508446	2026-06-12	3	ea64c52ed53c8d258f8e18308243d0aa6e1d42280023052de2510d506ca12acd	{"adults": 2, "children": 0}	1249.00	416.33	AVAILABLE	GBP	https://www.centerparcs.co.uk	2026-01-05 11:41:57.036726	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	df204fcc-0938-4dcc-8c57-b9544b21a792	\N
1e201676-6916-499d-9465-077dad5de95e	2026-06-12	3	ea64c52ed53c8d258f8e18308243d0aa6e1d42280023052de2510d506ca12acd	{"adults": 2, "children": 0}	1499.00	499.67	AVAILABLE	GBP	https://www.centerparcs.co.uk	2026-01-05 11:41:57.038948	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	df204fcc-0938-4dcc-8c57-b9544b21a792	\N
cc07d684-1255-4046-b93c-371e5d274898	2026-06-12	3	ea64c52ed53c8d258f8e18308243d0aa6e1d42280023052de2510d506ca12acd	{"adults": 2, "children": 0}	1799.00	599.67	AVAILABLE	GBP	https://www.centerparcs.co.uk	2026-01-05 11:41:57.041425	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	df204fcc-0938-4dcc-8c57-b9544b21a792	\N
f7a7fea7-a199-4d2f-805c-cc8550d44b29	2026-06-12	3	ea64c52ed53c8d258f8e18308243d0aa6e1d42280023052de2510d506ca12acd	{"adults": 2, "children": 0}	1899.00	633.00	AVAILABLE	GBP	https://www.centerparcs.co.uk	2026-01-05 11:41:57.043541	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	df204fcc-0938-4dcc-8c57-b9544b21a792	\N
5f1716f2-0b98-4b40-bf9c-eb72696bdb18	2026-06-12	3	ea64c52ed53c8d258f8e18308243d0aa6e1d42280023052de2510d506ca12acd	{"adults": 2, "children": 0}	2599.00	866.33	AVAILABLE	GBP	https://www.centerparcs.co.uk	2026-01-05 11:41:57.047189	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	df204fcc-0938-4dcc-8c57-b9544b21a792	\N
d4445547-c1a0-436b-89dd-1232b0e4ae24	2026-06-12	3	ea64c52ed53c8d258f8e18308243d0aa6e1d42280023052de2510d506ca12acd	{"adults": 2, "children": 0}	2799.00	933.00	AVAILABLE	GBP	https://www.centerparcs.co.uk	2026-01-05 11:41:57.048986	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	df204fcc-0938-4dcc-8c57-b9544b21a792	\N
d93a6e17-ad5b-4b93-92a9-8d488cdef5dd	2026-06-12	3	ea64c52ed53c8d258f8e18308243d0aa6e1d42280023052de2510d506ca12acd	{"adults": 2, "children": 0}	4199.00	1399.67	AVAILABLE	GBP	https://www.centerparcs.co.uk	2026-01-05 11:41:57.050958	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	df204fcc-0938-4dcc-8c57-b9544b21a792	\N
ecb5366c-c2e9-455a-ba2e-975e999cc439	2026-06-12	3	f048a23113173f3ddea67c00691b48ff4acc1afb98bf7ed53775800d32b5dd0b	{"adults": 2, "children": 0}	789.00	263.00	AVAILABLE	GBP	https://www.centerparcs.co.uk/breaks-we-offer/search.html/2/SF/12-06-2026/3/-/-/1/2/0/0/0/0/N	2026-01-07 14:33:35.500602	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	6acb9757-2b93-419d-9664-61995f98638f	\N
f24ba59d-65c5-4bdc-a3fe-eb24c2c05d67	2026-06-12	3	43f5aaefbe071cc908f06ad1e157ea46894f8a88af907b61841a83a6882c028f	{"adults": 2, "children": 0}	789.00	263.00	AVAILABLE	GBP	https://www.centerparcs.co.uk/breaks-we-offer/search.html/2/SF/12-06-2026/3/-/-/1/2/0/0/0/0/N	2026-01-07 14:33:35.503096	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	6acb9757-2b93-419d-9664-61995f98638f	\N
c869a8e3-3101-4f60-8727-48a5f8c3d356	2026-06-12	3	8fa84213f5d1befbaf57623a29a875295fa8952735a52ca3a299bf5ddb2dd61c	{"adults": 2, "children": 0}	829.00	276.33	AVAILABLE	GBP	https://www.centerparcs.co.uk/breaks-we-offer/search.html/2/SF/12-06-2026/3/-/-/1/2/0/0/0/0/N	2026-01-07 14:33:35.504555	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	6acb9757-2b93-419d-9664-61995f98638f	\N
d03a81b3-6621-4bb9-bf65-02c32b11df9c	2026-06-12	3	895842bf3f443f07a38dfa86a13ff49121511f7684a96cb487c3b0d2e814b3ea	{"adults": 2, "children": 0}	859.00	286.33	AVAILABLE	GBP	https://www.centerparcs.co.uk/breaks-we-offer/search.html/2/SF/12-06-2026/3/-/-/1/2/0/0/0/0/N	2026-01-07 14:33:35.506325	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	6acb9757-2b93-419d-9664-61995f98638f	\N
8040ecb0-ed46-4d00-b5d0-75d92feffc0b	2026-06-12	3	1fabfa1c2448cb8b8927d91ee1970360bfcc1c6703e5a207fc5c8d60dc611927	{"adults": 2, "children": 0}	1069.00	356.33	AVAILABLE	GBP	https://www.centerparcs.co.uk/breaks-we-offer/search.html/2/SF/12-06-2026/3/-/-/1/2/0/0/0/0/N	2026-01-07 14:33:35.509244	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	6acb9757-2b93-419d-9664-61995f98638f	\N
ec3ff02d-6dfb-4c43-bb30-0bbc4be69f7c	2026-06-12	3	b4985328ba51f524cb458b7906cf9728f512c5ff3d4d86aef1349e3e05f97450	{"adults": 2, "children": 0}	829.00	276.33	AVAILABLE	GBP	https://www.centerparcs.co.uk/breaks-we-offer/search.html/2/SF/12-06-2026/3/-/-/1/2/0/0/0/0/N	2026-01-07 14:33:35.510749	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	6acb9757-2b93-419d-9664-61995f98638f	\N
a08f1fe9-b6a5-4a08-ae7d-0cb5d3be73af	2026-06-12	3	6c65a87b25af36e9ebc8a4b6cb492078940aa707e18cfb97dddf3ababb20e743	{"adults": 2, "children": 0}	959.00	319.67	AVAILABLE	GBP	https://www.centerparcs.co.uk/breaks-we-offer/search.html/2/SF/12-06-2026/3/-/-/1/2/0/0/0/0/N	2026-01-07 14:33:35.512086	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	6acb9757-2b93-419d-9664-61995f98638f	\N
1e6771d3-4fa4-456e-b24a-747475462396	2026-06-12	3	b018b84907ec02f5a70c4cb6a1fb749fd75a0be69640280b1705af6c5d49ec67	{"adults": 2, "children": 0}	2499.00	833.00	AVAILABLE	GBP	https://www.centerparcs.co.uk/breaks-we-offer/search.html/2/SF/12-06-2026/3/-/-/1/2/0/0/0/0/N	2026-01-07 14:33:35.513235	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	6acb9757-2b93-419d-9664-61995f98638f	\N
2c7ce3f4-913a-4fc7-bc8a-2b7f4adcd78d	2026-06-12	3	2edfc0574b0625cb758d1f0e3ecd4e021ce711f2b438964c03574ee168747adc	{"adults": 2, "children": 0}	1089.00	363.00	AVAILABLE	GBP	https://www.centerparcs.co.uk/breaks-we-offer/search.html/2/SF/12-06-2026/3/-/-/1/2/0/0/0/0/N	2026-01-07 14:33:35.514235	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	6acb9757-2b93-419d-9664-61995f98638f	\N
d0a311d7-e863-4956-933b-72b675d2c245	2026-06-12	3	ae087940b7c59d207912e50056b2d40ce4473d3506f43190154583386e1cff06	{"adults": 2, "children": 0}	1139.00	379.67	AVAILABLE	GBP	https://www.centerparcs.co.uk/breaks-we-offer/search.html/2/SF/12-06-2026/3/-/-/1/2/0/0/0/0/N	2026-01-07 14:33:35.515719	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	6acb9757-2b93-419d-9664-61995f98638f	\N
39e0391c-9a4f-4ed9-9a64-ca39d4439229	2026-06-12	3	f53a9a92392f6d7e59472ee38052eedec243f291e5f0ac444e9eec0838d51c72	{"adults": 2, "children": 0}	1179.00	393.00	AVAILABLE	GBP	https://www.centerparcs.co.uk/breaks-we-offer/search.html/2/SF/12-06-2026/3/-/-/1/2/0/0/0/0/N	2026-01-07 14:33:35.51684	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	6acb9757-2b93-419d-9664-61995f98638f	\N
5aa14053-0174-4ef0-9277-53a81d17a0af	2026-06-12	3	89e8af21ab989ae4fdb5b9ebeb526c6597888521d6a64124919fb8a155cca5ad	{"adults": 2, "children": 0}	1699.00	566.33	AVAILABLE	GBP	https://www.centerparcs.co.uk/breaks-we-offer/search.html/2/SF/12-06-2026/3/-/-/1/2/0/0/0/0/N	2026-01-07 14:33:35.517995	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	6acb9757-2b93-419d-9664-61995f98638f	\N
e67609a8-b8c8-4425-b8b3-f3db663ef8cc	2026-06-12	3	340042a761b3155c5e8a6326fca894d273574ce3292c8f3919cdafca4dd6d901	{"adults": 2, "children": 0}	1379.00	459.67	AVAILABLE	GBP	https://www.centerparcs.co.uk/breaks-we-offer/search.html/2/SF/12-06-2026/3/-/-/1/2/0/0/0/0/N	2026-01-07 14:33:35.519406	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	6acb9757-2b93-419d-9664-61995f98638f	\N
ab1de270-b3bb-43f1-9de1-9c5e33410106	2026-06-12	3	18eeeeaf74b3599bb02700c7538ffb4822339bfafefc8d2fd98e29f8c71a7b03	{"adults": 2, "children": 0}	1499.00	499.67	AVAILABLE	GBP	https://www.centerparcs.co.uk/breaks-we-offer/search.html/2/SF/12-06-2026/3/-/-/1/2/0/0/0/0/N	2026-01-07 14:33:35.520694	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	6acb9757-2b93-419d-9664-61995f98638f	\N
030307ab-0ebf-4bd2-bb32-4254be13dda6	2026-06-12	3	ca12d6001d91378c9cee1a4d687648b73b60a0e345a33dcf96f1a23596c3e047	{"adults": 2, "children": 0}	1889.00	629.67	AVAILABLE	GBP	https://www.centerparcs.co.uk/breaks-we-offer/search.html/2/SF/12-06-2026/3/-/-/1/2/0/0/0/0/N	2026-01-07 14:33:35.521768	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	6acb9757-2b93-419d-9664-61995f98638f	\N
9f034859-74a8-4eec-af1e-f8fdfb77a8c3	2026-06-12	3	ca12d6001d91378c9cee1a4d687648b73b60a0e345a33dcf96f1a23596c3e047	{"adults": 2, "children": 0}	2059.00	686.33	AVAILABLE	GBP	https://www.centerparcs.co.uk/breaks-we-offer/search.html/2/SF/12-06-2026/3/-/-/1/2/0/0/0/0/N	2026-01-07 14:33:35.52365	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	6acb9757-2b93-419d-9664-61995f98638f	\N
ccb345d9-1b0f-4b99-be83-94ad78b0983c	2026-06-12	3	517085ce48929c4ac2663a099f58c543628ddb724f15a73320a236de78f7d291	{"adults": 2, "children": 0}	2059.00	686.33	AVAILABLE	GBP	https://www.centerparcs.co.uk/breaks-we-offer/search.html/2/SF/12-06-2026/3/-/-/1/2/0/0/0/0/N	2026-01-07 14:33:35.524834	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	6acb9757-2b93-419d-9664-61995f98638f	\N
fa966ddc-c20f-4f2d-a02a-538a8ddcdb37	2026-06-12	3	4d740f6268fe2df99ea56f454323d1bcc119aae8d53b12b47fd04e0457e5759e	{"adults": 2, "children": 0}	2799.00	933.00	AVAILABLE	GBP	https://www.centerparcs.co.uk/breaks-we-offer/search.html/2/SF/12-06-2026/3/-/-/1/2/0/0/0/0/N	2026-01-07 14:33:35.525831	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	6acb9757-2b93-419d-9664-61995f98638f	\N
1aef6283-34e6-49fa-af24-cb86229d06dc	2026-06-12	3	322da92c6a35da9761931abbbfdcdd86f675fdd3f8ff10a0f7f817f5590b10c1	{"adults": 2, "children": 0}	2999.00	999.67	AVAILABLE	GBP	https://www.centerparcs.co.uk/breaks-we-offer/search.html/2/SF/12-06-2026/3/-/-/1/2/0/0/0/0/N	2026-01-07 14:33:35.526631	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	6acb9757-2b93-419d-9664-61995f98638f	\N
f312dec4-ae05-49b0-a646-376a06dcf936	2026-06-12	3	af2109e727e872597f1b6aaa52d12f4ea7cfd7c388822e629ff8e815db512dfb	{"adults": 2, "children": 0}	4399.00	1466.33	AVAILABLE	GBP	https://www.centerparcs.co.uk/breaks-we-offer/search.html/2/SF/12-06-2026/3/-/-/1/2/0/0/0/0/N	2026-01-07 14:33:35.527586	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	6acb9757-2b93-419d-9664-61995f98638f	\N
60c4a357-9e23-43f4-be18-45b3c7823b2d	2026-06-12	3	2db8b74a309391d6431d1fd0e3c3f735f17df3f974a61114a192d31570d94e96	{"adults": 2, "children": 0}	3899.00	1299.67	AVAILABLE	GBP	https://www.centerparcs.co.uk/breaks-we-offer/search.html/2/SF/12-06-2026/3/-/-/1/2/0/0/0/0/N	2026-01-07 14:33:35.528369	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	6acb9757-2b93-419d-9664-61995f98638f	\N
6e769b2e-c8b5-45e7-9566-d492c04a974c	2026-06-12	3	f048a23113173f3ddea67c00691b48ff4acc1afb98bf7ed53775800d32b5dd0b	{"adults": 2, "children": 0}	789.00	263.00	AVAILABLE	GBP	https://www.centerparcs.co.uk/breaks-we-offer/search.html/2/SF/12-06-2026/3/-/-/1/2/0/0/0/0/N	2026-01-07 14:34:41.947456	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	b6fa6290-2ff1-4e7c-8415-2d3e45ddeede	\N
d3fcd37a-819e-4163-80c0-a49538a21ee4	2026-06-12	3	43f5aaefbe071cc908f06ad1e157ea46894f8a88af907b61841a83a6882c028f	{"adults": 2, "children": 0}	789.00	263.00	AVAILABLE	GBP	https://www.centerparcs.co.uk/breaks-we-offer/search.html/2/SF/12-06-2026/3/-/-/1/2/0/0/0/0/N	2026-01-07 14:34:41.948801	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	b6fa6290-2ff1-4e7c-8415-2d3e45ddeede	\N
aeaf89e5-774e-46d1-9c1b-eb218e4812f3	2026-06-12	3	8fa84213f5d1befbaf57623a29a875295fa8952735a52ca3a299bf5ddb2dd61c	{"adults": 2, "children": 0}	829.00	276.33	AVAILABLE	GBP	https://www.centerparcs.co.uk/breaks-we-offer/search.html/2/SF/12-06-2026/3/-/-/1/2/0/0/0/0/N	2026-01-07 14:34:41.950102	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	b6fa6290-2ff1-4e7c-8415-2d3e45ddeede	\N
be630d23-202a-44c0-a6ae-13951535bed4	2026-06-12	3	895842bf3f443f07a38dfa86a13ff49121511f7684a96cb487c3b0d2e814b3ea	{"adults": 2, "children": 0}	859.00	286.33	AVAILABLE	GBP	https://www.centerparcs.co.uk/breaks-we-offer/search.html/2/SF/12-06-2026/3/-/-/1/2/0/0/0/0/N	2026-01-07 14:34:41.951298	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	b6fa6290-2ff1-4e7c-8415-2d3e45ddeede	\N
450f93cb-50f4-460f-addc-5164069358fe	2026-06-12	3	1fabfa1c2448cb8b8927d91ee1970360bfcc1c6703e5a207fc5c8d60dc611927	{"adults": 2, "children": 0}	1069.00	356.33	AVAILABLE	GBP	https://www.centerparcs.co.uk/breaks-we-offer/search.html/2/SF/12-06-2026/3/-/-/1/2/0/0/0/0/N	2026-01-07 14:34:41.952385	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	b6fa6290-2ff1-4e7c-8415-2d3e45ddeede	\N
b14b17f4-6c81-4e2c-bcec-7b17574946d5	2026-06-12	3	b4985328ba51f524cb458b7906cf9728f512c5ff3d4d86aef1349e3e05f97450	{"adults": 2, "children": 0}	829.00	276.33	AVAILABLE	GBP	https://www.centerparcs.co.uk/breaks-we-offer/search.html/2/SF/12-06-2026/3/-/-/1/2/0/0/0/0/N	2026-01-07 14:34:41.953423	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	b6fa6290-2ff1-4e7c-8415-2d3e45ddeede	\N
7b7e88cb-50d9-46ea-8573-d3e0e9486d46	2026-06-12	3	6c65a87b25af36e9ebc8a4b6cb492078940aa707e18cfb97dddf3ababb20e743	{"adults": 2, "children": 0}	959.00	319.67	AVAILABLE	GBP	https://www.centerparcs.co.uk/breaks-we-offer/search.html/2/SF/12-06-2026/3/-/-/1/2/0/0/0/0/N	2026-01-07 14:34:41.954584	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	b6fa6290-2ff1-4e7c-8415-2d3e45ddeede	\N
1ea4f817-cdba-4836-b036-ba3d52f325ab	2026-06-12	3	b018b84907ec02f5a70c4cb6a1fb749fd75a0be69640280b1705af6c5d49ec67	{"adults": 2, "children": 0}	2499.00	833.00	AVAILABLE	GBP	https://www.centerparcs.co.uk/breaks-we-offer/search.html/2/SF/12-06-2026/3/-/-/1/2/0/0/0/0/N	2026-01-07 14:34:41.955832	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	b6fa6290-2ff1-4e7c-8415-2d3e45ddeede	\N
267a886b-cf0b-43de-9506-466350c75278	2026-06-12	3	2edfc0574b0625cb758d1f0e3ecd4e021ce711f2b438964c03574ee168747adc	{"adults": 2, "children": 0}	1089.00	363.00	AVAILABLE	GBP	https://www.centerparcs.co.uk/breaks-we-offer/search.html/2/SF/12-06-2026/3/-/-/1/2/0/0/0/0/N	2026-01-07 14:34:41.958775	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	b6fa6290-2ff1-4e7c-8415-2d3e45ddeede	\N
d23c911b-540c-4066-907a-51b975cb1738	2026-06-12	3	ae087940b7c59d207912e50056b2d40ce4473d3506f43190154583386e1cff06	{"adults": 2, "children": 0}	1139.00	379.67	AVAILABLE	GBP	https://www.centerparcs.co.uk/breaks-we-offer/search.html/2/SF/12-06-2026/3/-/-/1/2/0/0/0/0/N	2026-01-07 14:34:41.960789	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	b6fa6290-2ff1-4e7c-8415-2d3e45ddeede	\N
76f9eb2a-3ce9-4fdd-b86b-a6f44a909453	2026-06-12	3	f53a9a92392f6d7e59472ee38052eedec243f291e5f0ac444e9eec0838d51c72	{"adults": 2, "children": 0}	1179.00	393.00	AVAILABLE	GBP	https://www.centerparcs.co.uk/breaks-we-offer/search.html/2/SF/12-06-2026/3/-/-/1/2/0/0/0/0/N	2026-01-07 14:34:41.962159	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	b6fa6290-2ff1-4e7c-8415-2d3e45ddeede	\N
ed0df0bc-fcb6-4a8d-b93a-1538bc674669	2026-06-12	3	89e8af21ab989ae4fdb5b9ebeb526c6597888521d6a64124919fb8a155cca5ad	{"adults": 2, "children": 0}	1699.00	566.33	AVAILABLE	GBP	https://www.centerparcs.co.uk/breaks-we-offer/search.html/2/SF/12-06-2026/3/-/-/1/2/0/0/0/0/N	2026-01-07 14:34:41.963226	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	b6fa6290-2ff1-4e7c-8415-2d3e45ddeede	\N
3683fdb1-c66b-4169-8e07-96a21a6c07a3	2026-06-12	3	340042a761b3155c5e8a6326fca894d273574ce3292c8f3919cdafca4dd6d901	{"adults": 2, "children": 0}	1379.00	459.67	AVAILABLE	GBP	https://www.centerparcs.co.uk/breaks-we-offer/search.html/2/SF/12-06-2026/3/-/-/1/2/0/0/0/0/N	2026-01-07 14:34:41.964149	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	b6fa6290-2ff1-4e7c-8415-2d3e45ddeede	\N
54d75eb7-e591-48ec-b7c3-02c1332d6d68	2026-06-12	3	18eeeeaf74b3599bb02700c7538ffb4822339bfafefc8d2fd98e29f8c71a7b03	{"adults": 2, "children": 0}	1499.00	499.67	AVAILABLE	GBP	https://www.centerparcs.co.uk/breaks-we-offer/search.html/2/SF/12-06-2026/3/-/-/1/2/0/0/0/0/N	2026-01-07 14:34:41.965234	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	b6fa6290-2ff1-4e7c-8415-2d3e45ddeede	\N
6ae670f3-3156-49b0-820b-f1f98c23fbb7	2026-06-12	3	ca12d6001d91378c9cee1a4d687648b73b60a0e345a33dcf96f1a23596c3e047	{"adults": 2, "children": 0}	1889.00	629.67	AVAILABLE	GBP	https://www.centerparcs.co.uk/breaks-we-offer/search.html/2/SF/12-06-2026/3/-/-/1/2/0/0/0/0/N	2026-01-07 14:34:41.966559	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	b6fa6290-2ff1-4e7c-8415-2d3e45ddeede	\N
9e6490bf-4291-4a96-924a-11e5888a601f	2026-06-12	3	ca12d6001d91378c9cee1a4d687648b73b60a0e345a33dcf96f1a23596c3e047	{"adults": 2, "children": 0}	2059.00	686.33	AVAILABLE	GBP	https://www.centerparcs.co.uk/breaks-we-offer/search.html/2/SF/12-06-2026/3/-/-/1/2/0/0/0/0/N	2026-01-07 14:34:41.967513	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	b6fa6290-2ff1-4e7c-8415-2d3e45ddeede	\N
14512404-f5df-410b-8ece-2c8da8b4ad09	2026-06-12	3	517085ce48929c4ac2663a099f58c543628ddb724f15a73320a236de78f7d291	{"adults": 2, "children": 0}	2059.00	686.33	AVAILABLE	GBP	https://www.centerparcs.co.uk/breaks-we-offer/search.html/2/SF/12-06-2026/3/-/-/1/2/0/0/0/0/N	2026-01-07 14:34:41.968696	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	b6fa6290-2ff1-4e7c-8415-2d3e45ddeede	\N
ba6db661-6c4d-44ad-9243-fffef6d3148c	2026-06-12	3	4d740f6268fe2df99ea56f454323d1bcc119aae8d53b12b47fd04e0457e5759e	{"adults": 2, "children": 0}	2799.00	933.00	AVAILABLE	GBP	https://www.centerparcs.co.uk/breaks-we-offer/search.html/2/SF/12-06-2026/3/-/-/1/2/0/0/0/0/N	2026-01-07 14:34:41.970418	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	b6fa6290-2ff1-4e7c-8415-2d3e45ddeede	\N
238d46fd-1e99-4800-ab1f-9f44e331ca17	2026-06-12	3	322da92c6a35da9761931abbbfdcdd86f675fdd3f8ff10a0f7f817f5590b10c1	{"adults": 2, "children": 0}	2999.00	999.67	AVAILABLE	GBP	https://www.centerparcs.co.uk/breaks-we-offer/search.html/2/SF/12-06-2026/3/-/-/1/2/0/0/0/0/N	2026-01-07 14:34:41.971807	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	b6fa6290-2ff1-4e7c-8415-2d3e45ddeede	\N
316b551d-db10-4650-8b2a-d9db9700030c	2026-06-12	3	af2109e727e872597f1b6aaa52d12f4ea7cfd7c388822e629ff8e815db512dfb	{"adults": 2, "children": 0}	4399.00	1466.33	AVAILABLE	GBP	https://www.centerparcs.co.uk/breaks-we-offer/search.html/2/SF/12-06-2026/3/-/-/1/2/0/0/0/0/N	2026-01-07 14:34:41.973563	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	b6fa6290-2ff1-4e7c-8415-2d3e45ddeede	\N
db58ea0a-1539-4c9f-9d45-92ec7faa194e	2026-06-12	3	2db8b74a309391d6431d1fd0e3c3f735f17df3f974a61114a192d31570d94e96	{"adults": 2, "children": 0}	3899.00	1299.67	AVAILABLE	GBP	https://www.centerparcs.co.uk/breaks-we-offer/search.html/2/SF/12-06-2026/3/-/-/1/2/0/0/0/0/N	2026-01-07 14:34:41.974772	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	b6fa6290-2ff1-4e7c-8415-2d3e45ddeede	\N
bae2ebe5-e7bd-4d85-bd7c-3974fc46f1ff	2026-06-12	3	44fec3def3c5dffcd72a0c3e52987cfeb6d143951169739915ef1baef6e80075	{"adults": 2, "children": 0}	579.00	193.00	AVAILABLE	GBP	https://www.centerparcs.co.uk/breaks-we-offer/search.html/2/SF/12-06-2026/3/-/-/1/2/0/0/0/0/N	2026-01-07 14:34:41.921458	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	b6fa6290-2ff1-4e7c-8415-2d3e45ddeede	\N
c3614117-9002-4ead-b0e2-a3abaaa5fba9	2026-06-12	3	2d3c1107e3b146085b2e1eaf716a8fa23b510dda7aac9adf71c85060e9f5e672	{"adults": 2, "children": 0}	599.00	199.67	AVAILABLE	GBP	https://www.centerparcs.co.uk/breaks-we-offer/search.html/2/SF/12-06-2026/3/-/-/1/2/0/0/0/0/N	2026-01-07 14:34:41.933349	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	b6fa6290-2ff1-4e7c-8415-2d3e45ddeede	\N
95dfa40d-e40d-4574-80dd-a274b1452d7e	2026-06-12	3	74db2c251d43129ef5a957c5d6792b3839278dd9e939b2ac116db6cf38c95a4b	{"adults": 2, "children": 0}	599.00	199.67	AVAILABLE	GBP	https://www.centerparcs.co.uk/breaks-we-offer/search.html/2/SF/12-06-2026/3/-/-/1/2/0/0/0/0/N	2026-01-07 14:34:41.936275	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	b6fa6290-2ff1-4e7c-8415-2d3e45ddeede	\N
18009741-98bf-4418-8fc9-94c727852852	2026-06-12	3	335688784763867900e191ade70145f288cbdd4a071a0704689ce36cb50f8351	{"adults": 2, "children": 0}	619.00	206.33	AVAILABLE	GBP	https://www.centerparcs.co.uk/breaks-we-offer/search.html/2/SF/12-06-2026/3/-/-/1/2/0/0/0/0/N	2026-01-07 14:34:41.938637	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	b6fa6290-2ff1-4e7c-8415-2d3e45ddeede	\N
a821a3c8-95c2-4948-90b0-a7ce845d2490	2026-06-12	3	6247c367548d120e059fa322e286eb51190d2306b6d000af623336323aab5675	{"adults": 2, "children": 0}	839.00	279.67	AVAILABLE	GBP	https://www.centerparcs.co.uk/breaks-we-offer/search.html/2/SF/12-06-2026/3/-/-/1/2/0/0/0/0/N	2026-01-07 14:34:41.941472	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	b6fa6290-2ff1-4e7c-8415-2d3e45ddeede	\N
0d715863-fe1e-4f3e-8851-35332fd4cdcc	2026-06-12	3	ea64c52ed53c8d258f8e18308243d0aa6e1d42280023052de2510d506ca12acd	{"adults": 2, "children": 0}	579.00	193.00	AVAILABLE	GBP	https://www.centerparcs.co.uk	2026-01-05 12:17:11.545664	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	8d2b19bd-8bfd-4c55-983e-e2d87f4445e0	\N
35a08e86-ab4f-4b27-96d7-918715383254	2026-06-12	3	ea64c52ed53c8d258f8e18308243d0aa6e1d42280023052de2510d506ca12acd	{"adults": 2, "children": 0}	599.00	199.67	AVAILABLE	GBP	https://www.centerparcs.co.uk	2026-01-05 12:17:11.554979	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	8d2b19bd-8bfd-4c55-983e-e2d87f4445e0	\N
e4e39af5-85d5-4068-93ac-2fc9746fd0bc	2026-06-12	3	ea64c52ed53c8d258f8e18308243d0aa6e1d42280023052de2510d506ca12acd	{"adults": 2, "children": 0}	599.00	199.67	AVAILABLE	GBP	https://www.centerparcs.co.uk	2026-01-05 12:17:11.561109	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	8d2b19bd-8bfd-4c55-983e-e2d87f4445e0	\N
f4f94a77-a202-4a15-9206-cbf5cb97b32a	2026-06-12	3	ea64c52ed53c8d258f8e18308243d0aa6e1d42280023052de2510d506ca12acd	{"adults": 2, "children": 0}	619.00	206.33	AVAILABLE	GBP	https://www.centerparcs.co.uk	2026-01-05 12:17:11.564757	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	8d2b19bd-8bfd-4c55-983e-e2d87f4445e0	\N
76a27e3d-c99a-4c74-87cd-44843edce842	2026-06-12	3	ea64c52ed53c8d258f8e18308243d0aa6e1d42280023052de2510d506ca12acd	{"adults": 2, "children": 0}	839.00	279.67	AVAILABLE	GBP	https://www.centerparcs.co.uk	2026-01-05 12:17:11.56839	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	8d2b19bd-8bfd-4c55-983e-e2d87f4445e0	\N
94610a56-2591-4fa2-a9ee-763032f64835	2026-06-12	3	ea64c52ed53c8d258f8e18308243d0aa6e1d42280023052de2510d506ca12acd	{"adults": 2, "children": 0}	669.00	223.00	AVAILABLE	GBP	https://www.centerparcs.co.uk	2026-01-05 12:17:11.572433	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	8d2b19bd-8bfd-4c55-983e-e2d87f4445e0	\N
1b9f001d-6842-4a20-883f-9d7920281003	2026-06-12	3	ea64c52ed53c8d258f8e18308243d0aa6e1d42280023052de2510d506ca12acd	{"adults": 2, "children": 0}	749.00	249.67	AVAILABLE	GBP	https://www.centerparcs.co.uk	2026-01-05 12:17:11.575803	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	8d2b19bd-8bfd-4c55-983e-e2d87f4445e0	\N
44d31b10-feb3-43ec-adb0-586b88f0243e	2026-06-12	3	ea64c52ed53c8d258f8e18308243d0aa6e1d42280023052de2510d506ca12acd	{"adults": 2, "children": 0}	749.00	249.67	AVAILABLE	GBP	https://www.centerparcs.co.uk	2026-01-05 12:17:11.579417	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	8d2b19bd-8bfd-4c55-983e-e2d87f4445e0	\N
184f2269-b61e-4934-9446-7edbf345f628	2026-06-12	3	ea64c52ed53c8d258f8e18308243d0aa6e1d42280023052de2510d506ca12acd	{"adults": 2, "children": 0}	799.00	266.33	AVAILABLE	GBP	https://www.centerparcs.co.uk	2026-01-05 12:17:11.585319	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	8d2b19bd-8bfd-4c55-983e-e2d87f4445e0	\N
5a329731-2e1a-4983-8d67-296d3cb115ea	2026-06-12	3	ea64c52ed53c8d258f8e18308243d0aa6e1d42280023052de2510d506ca12acd	{"adults": 2, "children": 0}	829.00	276.33	AVAILABLE	GBP	https://www.centerparcs.co.uk	2026-01-05 12:17:11.58916	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	8d2b19bd-8bfd-4c55-983e-e2d87f4445e0	\N
cbce9fb3-9717-4f12-84c8-3eb276ddfca1	2026-06-12	3	ea64c52ed53c8d258f8e18308243d0aa6e1d42280023052de2510d506ca12acd	{"adults": 2, "children": 0}	1019.00	339.67	AVAILABLE	GBP	https://www.centerparcs.co.uk	2026-01-05 12:17:11.592108	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	8d2b19bd-8bfd-4c55-983e-e2d87f4445e0	\N
1d9a403f-1d7f-4668-a2e1-1019a4e49429	2026-06-12	3	ea64c52ed53c8d258f8e18308243d0aa6e1d42280023052de2510d506ca12acd	{"adults": 2, "children": 0}	799.00	266.33	AVAILABLE	GBP	https://www.centerparcs.co.uk	2026-01-05 12:17:11.594988	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	8d2b19bd-8bfd-4c55-983e-e2d87f4445e0	\N
d49aea16-0183-4c65-a5f5-264300aa9a3b	2026-06-12	3	ea64c52ed53c8d258f8e18308243d0aa6e1d42280023052de2510d506ca12acd	{"adults": 2, "children": 0}	899.00	299.67	AVAILABLE	GBP	https://www.centerparcs.co.uk	2026-01-05 12:17:11.598335	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	8d2b19bd-8bfd-4c55-983e-e2d87f4445e0	\N
48ee6713-6424-4014-b84a-8705b04aa14f	2026-06-12	3	ea64c52ed53c8d258f8e18308243d0aa6e1d42280023052de2510d506ca12acd	{"adults": 2, "children": 0}	1049.00	349.67	AVAILABLE	GBP	https://www.centerparcs.co.uk	2026-01-05 12:17:11.601861	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	8d2b19bd-8bfd-4c55-983e-e2d87f4445e0	\N
abfc12dc-a201-4d60-9919-0641a5a3e388	2026-06-12	3	ea64c52ed53c8d258f8e18308243d0aa6e1d42280023052de2510d506ca12acd	{"adults": 2, "children": 0}	1099.00	366.33	AVAILABLE	GBP	https://www.centerparcs.co.uk	2026-01-05 12:17:11.604613	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	8d2b19bd-8bfd-4c55-983e-e2d87f4445e0	\N
5846b8c1-6af7-4b96-9c37-8c10254b8e43	2026-06-12	3	ea64c52ed53c8d258f8e18308243d0aa6e1d42280023052de2510d506ca12acd	{"adults": 2, "children": 0}	1189.00	396.33	AVAILABLE	GBP	https://www.centerparcs.co.uk	2026-01-05 12:17:11.607134	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	8d2b19bd-8bfd-4c55-983e-e2d87f4445e0	\N
4489482c-35f6-4424-9b4e-e0e26d536634	2026-06-12	3	ea64c52ed53c8d258f8e18308243d0aa6e1d42280023052de2510d506ca12acd	{"adults": 2, "children": 0}	1649.00	549.67	AVAILABLE	GBP	https://www.centerparcs.co.uk	2026-01-05 12:17:11.611192	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	8d2b19bd-8bfd-4c55-983e-e2d87f4445e0	\N
869e64f2-33b0-49c9-9ee3-f7ed481d292d	2026-06-12	3	ea64c52ed53c8d258f8e18308243d0aa6e1d42280023052de2510d506ca12acd	{"adults": 2, "children": 0}	1249.00	416.33	AVAILABLE	GBP	https://www.centerparcs.co.uk	2026-01-05 12:17:11.61387	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	8d2b19bd-8bfd-4c55-983e-e2d87f4445e0	\N
b7338816-1d03-4fdb-babf-9ad85b41e038	2026-06-12	3	ea64c52ed53c8d258f8e18308243d0aa6e1d42280023052de2510d506ca12acd	{"adults": 2, "children": 0}	1499.00	499.67	AVAILABLE	GBP	https://www.centerparcs.co.uk	2026-01-05 12:17:11.616407	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	8d2b19bd-8bfd-4c55-983e-e2d87f4445e0	\N
e413238f-33ac-48bc-9a71-9a4d65c7f18c	2026-06-12	3	ea64c52ed53c8d258f8e18308243d0aa6e1d42280023052de2510d506ca12acd	{"adults": 2, "children": 0}	1799.00	599.67	AVAILABLE	GBP	https://www.centerparcs.co.uk	2026-01-05 12:17:11.619189	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	8d2b19bd-8bfd-4c55-983e-e2d87f4445e0	\N
07ed8f7f-2c60-487a-a257-6720b60b9b9b	2026-06-12	3	ea64c52ed53c8d258f8e18308243d0aa6e1d42280023052de2510d506ca12acd	{"adults": 2, "children": 0}	1899.00	633.00	AVAILABLE	GBP	https://www.centerparcs.co.uk	2026-01-05 12:17:11.621531	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	8d2b19bd-8bfd-4c55-983e-e2d87f4445e0	\N
3fc9a36a-5b87-4d3f-b935-070956e85ab7	2026-06-12	3	ea64c52ed53c8d258f8e18308243d0aa6e1d42280023052de2510d506ca12acd	{"adults": 2, "children": 0}	2599.00	866.33	AVAILABLE	GBP	https://www.centerparcs.co.uk	2026-01-05 12:17:11.624189	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	8d2b19bd-8bfd-4c55-983e-e2d87f4445e0	\N
d2b44232-d66c-43ad-9db4-b037ef3ccdd9	2026-06-12	3	ea64c52ed53c8d258f8e18308243d0aa6e1d42280023052de2510d506ca12acd	{"adults": 2, "children": 0}	2799.00	933.00	AVAILABLE	GBP	https://www.centerparcs.co.uk	2026-01-05 12:17:11.626511	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	8d2b19bd-8bfd-4c55-983e-e2d87f4445e0	\N
ee1ecdca-4232-4c41-a7cd-81a04cf26496	2026-06-12	3	ea64c52ed53c8d258f8e18308243d0aa6e1d42280023052de2510d506ca12acd	{"adults": 2, "children": 0}	4199.00	1399.67	AVAILABLE	GBP	https://www.centerparcs.co.uk	2026-01-05 12:17:11.628929	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	8d2b19bd-8bfd-4c55-983e-e2d87f4445e0	\N
0d9cf503-fea3-4dcf-a857-58db39e2a998	2026-06-12	3	ea64c52ed53c8d258f8e18308243d0aa6e1d42280023052de2510d506ca12acd	{"adults": 2, "children": 0}	579.00	193.00	AVAILABLE	GBP	https://www.centerparcs.co.uk	2026-01-05 12:38:17.714196	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	43da5246-6d75-4734-ad4a-cc8cc015b5b6	\N
b90b4622-f9da-4f69-83d5-2c33afc825d4	2026-06-12	3	ea64c52ed53c8d258f8e18308243d0aa6e1d42280023052de2510d506ca12acd	{"adults": 2, "children": 0}	599.00	199.67	AVAILABLE	GBP	https://www.centerparcs.co.uk	2026-01-05 12:38:17.72037	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	43da5246-6d75-4734-ad4a-cc8cc015b5b6	\N
82f78cbe-12c1-41a3-b63c-3fe23174cc6e	2026-06-12	3	ea64c52ed53c8d258f8e18308243d0aa6e1d42280023052de2510d506ca12acd	{"adults": 2, "children": 0}	599.00	199.67	AVAILABLE	GBP	https://www.centerparcs.co.uk	2026-01-05 12:38:17.723434	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	43da5246-6d75-4734-ad4a-cc8cc015b5b6	\N
e10e3d64-98dd-46d7-b777-f18acae1719f	2026-06-12	3	ea64c52ed53c8d258f8e18308243d0aa6e1d42280023052de2510d506ca12acd	{"adults": 2, "children": 0}	619.00	206.33	AVAILABLE	GBP	https://www.centerparcs.co.uk	2026-01-05 12:38:17.725906	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	43da5246-6d75-4734-ad4a-cc8cc015b5b6	\N
3161ce79-a5e5-4b84-a815-f7a713f235ae	2026-06-12	3	ea64c52ed53c8d258f8e18308243d0aa6e1d42280023052de2510d506ca12acd	{"adults": 2, "children": 0}	839.00	279.67	AVAILABLE	GBP	https://www.centerparcs.co.uk	2026-01-05 12:38:17.728505	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	43da5246-6d75-4734-ad4a-cc8cc015b5b6	\N
dc84069d-5ef4-4f93-a266-b00c6b893631	2026-06-12	3	ea64c52ed53c8d258f8e18308243d0aa6e1d42280023052de2510d506ca12acd	{"adults": 2, "children": 0}	669.00	223.00	AVAILABLE	GBP	https://www.centerparcs.co.uk	2026-01-05 12:38:17.730568	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	43da5246-6d75-4734-ad4a-cc8cc015b5b6	\N
88196b86-2600-43e7-9469-3a78cbbbc6b4	2026-06-12	3	ea64c52ed53c8d258f8e18308243d0aa6e1d42280023052de2510d506ca12acd	{"adults": 2, "children": 0}	749.00	249.67	AVAILABLE	GBP	https://www.centerparcs.co.uk	2026-01-05 12:38:17.732756	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	43da5246-6d75-4734-ad4a-cc8cc015b5b6	\N
96841fde-cef9-491d-bead-6b481a86e0e2	2026-06-12	3	ea64c52ed53c8d258f8e18308243d0aa6e1d42280023052de2510d506ca12acd	{"adults": 2, "children": 0}	749.00	249.67	AVAILABLE	GBP	https://www.centerparcs.co.uk	2026-01-05 12:38:17.734905	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	43da5246-6d75-4734-ad4a-cc8cc015b5b6	\N
89bc96e6-7409-4982-8bb1-d1b33433d040	2026-06-12	3	ea64c52ed53c8d258f8e18308243d0aa6e1d42280023052de2510d506ca12acd	{"adults": 2, "children": 0}	799.00	266.33	AVAILABLE	GBP	https://www.centerparcs.co.uk	2026-01-05 12:38:17.736825	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	43da5246-6d75-4734-ad4a-cc8cc015b5b6	\N
63d3b151-f8af-4f3c-abc4-4a0a4e163bbe	2026-06-12	3	ea64c52ed53c8d258f8e18308243d0aa6e1d42280023052de2510d506ca12acd	{"adults": 2, "children": 0}	829.00	276.33	AVAILABLE	GBP	https://www.centerparcs.co.uk	2026-01-05 12:38:17.738861	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	43da5246-6d75-4734-ad4a-cc8cc015b5b6	\N
2f3dfe30-6c14-49c2-9a8e-574450579ffa	2026-06-12	3	ea64c52ed53c8d258f8e18308243d0aa6e1d42280023052de2510d506ca12acd	{"adults": 2, "children": 0}	1019.00	339.67	AVAILABLE	GBP	https://www.centerparcs.co.uk	2026-01-05 12:38:17.741667	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	43da5246-6d75-4734-ad4a-cc8cc015b5b6	\N
c2a8b50c-0df6-4cf7-8ae5-abd90bd898bf	2026-06-12	3	ea64c52ed53c8d258f8e18308243d0aa6e1d42280023052de2510d506ca12acd	{"adults": 2, "children": 0}	799.00	266.33	AVAILABLE	GBP	https://www.centerparcs.co.uk	2026-01-05 12:38:17.743656	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	43da5246-6d75-4734-ad4a-cc8cc015b5b6	\N
876c2970-407b-485d-8684-5774771d3b7b	2026-06-12	3	ea64c52ed53c8d258f8e18308243d0aa6e1d42280023052de2510d506ca12acd	{"adults": 2, "children": 0}	899.00	299.67	AVAILABLE	GBP	https://www.centerparcs.co.uk	2026-01-05 12:38:17.745528	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	43da5246-6d75-4734-ad4a-cc8cc015b5b6	\N
e7e5fd0a-6cff-4f37-9e7f-118f0183c6a1	2026-06-12	3	ea64c52ed53c8d258f8e18308243d0aa6e1d42280023052de2510d506ca12acd	{"adults": 2, "children": 0}	1049.00	349.67	AVAILABLE	GBP	https://www.centerparcs.co.uk	2026-01-05 12:38:17.747447	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	43da5246-6d75-4734-ad4a-cc8cc015b5b6	\N
423bcd2c-a436-44a6-8c9e-2d7eebce7392	2026-06-12	3	ea64c52ed53c8d258f8e18308243d0aa6e1d42280023052de2510d506ca12acd	{"adults": 2, "children": 0}	1099.00	366.33	AVAILABLE	GBP	https://www.centerparcs.co.uk	2026-01-05 12:38:17.749201	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	43da5246-6d75-4734-ad4a-cc8cc015b5b6	\N
e0792421-0095-472d-a63a-2d1cad738add	2026-06-12	3	ea64c52ed53c8d258f8e18308243d0aa6e1d42280023052de2510d506ca12acd	{"adults": 2, "children": 0}	1189.00	396.33	AVAILABLE	GBP	https://www.centerparcs.co.uk	2026-01-05 12:38:17.751172	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	43da5246-6d75-4734-ad4a-cc8cc015b5b6	\N
18fc50ad-6155-48b7-8960-dc9ba056244d	2026-06-12	3	ea64c52ed53c8d258f8e18308243d0aa6e1d42280023052de2510d506ca12acd	{"adults": 2, "children": 0}	1649.00	549.67	AVAILABLE	GBP	https://www.centerparcs.co.uk	2026-01-05 12:38:17.753117	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	43da5246-6d75-4734-ad4a-cc8cc015b5b6	\N
c88d9237-e9b6-4b22-8012-4d8303b7217b	2026-06-12	3	ea64c52ed53c8d258f8e18308243d0aa6e1d42280023052de2510d506ca12acd	{"adults": 2, "children": 0}	1249.00	416.33	AVAILABLE	GBP	https://www.centerparcs.co.uk	2026-01-05 12:38:17.754838	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	43da5246-6d75-4734-ad4a-cc8cc015b5b6	\N
8bfe1e46-2aa3-435d-898d-32453e12a6ee	2026-06-12	3	ea64c52ed53c8d258f8e18308243d0aa6e1d42280023052de2510d506ca12acd	{"adults": 2, "children": 0}	1499.00	499.67	AVAILABLE	GBP	https://www.centerparcs.co.uk	2026-01-05 12:38:17.756719	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	43da5246-6d75-4734-ad4a-cc8cc015b5b6	\N
d53b8dcc-0ef1-4ebe-8575-b8c92478233d	2026-06-12	3	ea64c52ed53c8d258f8e18308243d0aa6e1d42280023052de2510d506ca12acd	{"adults": 2, "children": 0}	1799.00	599.67	AVAILABLE	GBP	https://www.centerparcs.co.uk	2026-01-05 12:38:17.758517	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	43da5246-6d75-4734-ad4a-cc8cc015b5b6	\N
f4115385-8871-4da1-b9d5-721b8127cd0a	2026-06-12	3	ea64c52ed53c8d258f8e18308243d0aa6e1d42280023052de2510d506ca12acd	{"adults": 2, "children": 0}	1899.00	633.00	AVAILABLE	GBP	https://www.centerparcs.co.uk	2026-01-05 12:38:17.76044	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	43da5246-6d75-4734-ad4a-cc8cc015b5b6	\N
e1de28df-af6f-4d82-993e-67ed93d5ca47	2026-06-12	3	ea64c52ed53c8d258f8e18308243d0aa6e1d42280023052de2510d506ca12acd	{"adults": 2, "children": 0}	2599.00	866.33	AVAILABLE	GBP	https://www.centerparcs.co.uk	2026-01-05 12:38:17.762509	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	43da5246-6d75-4734-ad4a-cc8cc015b5b6	\N
22a4b948-0b44-4f26-8f1f-b9abf56be8c4	2026-06-12	3	ea64c52ed53c8d258f8e18308243d0aa6e1d42280023052de2510d506ca12acd	{"adults": 2, "children": 0}	2799.00	933.00	AVAILABLE	GBP	https://www.centerparcs.co.uk	2026-01-05 12:38:17.764348	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	43da5246-6d75-4734-ad4a-cc8cc015b5b6	\N
ddc68da7-6dcd-4a44-b44c-8f9c7a41dbba	2026-06-12	3	ea64c52ed53c8d258f8e18308243d0aa6e1d42280023052de2510d506ca12acd	{"adults": 2, "children": 0}	4199.00	1399.67	AVAILABLE	GBP	https://www.centerparcs.co.uk	2026-01-05 12:38:17.766315	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	43da5246-6d75-4734-ad4a-cc8cc015b5b6	\N
101e0a18-70c1-4a39-b9d3-83f2382cf2d1	2026-06-12	3	69250692e039b66bdad159828e2f57451a82712a04a3e15042ff28b252bd2f11	{"adults": 2, "children": 0}	729.00	243.00	AVAILABLE	GBP	https://www.centerparcs.co.uk/breaks-we-offer/search.html/2/SF/12-06-2026/3/-/-/1/2/0/0/0/0/N	2026-01-07 14:34:41.943292	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	b6fa6290-2ff1-4e7c-8415-2d3e45ddeede	\N
4a87dd56-9702-45cc-af49-92c508903352	2026-06-12	3	571fb5ebfa753d6f355b0892b6f64143ac1dbe619a83d0d8834958f21da9b615	{"adults": 2, "children": 0}	849.00	283.00	AVAILABLE	GBP	https://www.centerparcs.co.uk/breaks-we-offer/search.html/2/SF/12-06-2026/3/-/-/1/2/0/0/0/0/N	2026-01-07 14:34:41.945678	7d013472-9c19-4fe6-aa1d-85d56b8e3701	366af078-71c5-4b7e-98ed-5267ee24dc2a	b6fa6290-2ff1-4e7c-8415-2d3e45ddeede	\N
1e865daf-1a23-487b-9fbf-0982e8632beb	2026-03-16	4	2049147892012b91a3f1472ef8db02e6e03726d74db7ec86aff3e18dcfa863fb	{"adults": 2, "children": 0}	479.00	119.75	AVAILABLE	GBP	https://www.centerparcs.co.uk/breaks-we-offer/search.html/2/SF/16-03-2026/4/-/-/1/2/0/0/0/0/N	2026-01-07 14:54:39.347113	7d013472-9c19-4fe6-aa1d-85d56b8e3701	26cbfcdb-c857-4633-ae19-531968b0d330	6eb69a68-1178-46a6-b51d-14506ad90aa6	f4c6738f-af68-4c27-a288-0b2c41a69bf4
a9f2bd07-2fd1-4588-8ebb-d19eeb018775	2026-03-16	4	3e23a0082fe456842fa309d4a8953def663a1b31538ba840c5f5b3530c208c2d	{"adults": 2, "children": 0}	479.00	119.75	AVAILABLE	GBP	https://www.centerparcs.co.uk/breaks-we-offer/search.html/2/SF/16-03-2026/4/-/-/1/2/0/0/0/0/N	2026-01-07 14:54:39.412517	7d013472-9c19-4fe6-aa1d-85d56b8e3701	26cbfcdb-c857-4633-ae19-531968b0d330	6eb69a68-1178-46a6-b51d-14506ad90aa6	968986bb-5a76-4211-bfe2-1c484a04948c
a96393d9-b1ff-420e-8f46-fff246cef01a	2026-03-16	4	60e3c972045ec317f4fde218fdcc3f08ea45fa272de358d43e29a3f28174a036	{"adults": 2, "children": 0}	529.00	132.25	AVAILABLE	GBP	https://www.centerparcs.co.uk/breaks-we-offer/search.html/2/SF/16-03-2026/4/-/-/1/2/0/0/0/0/N	2026-01-07 14:54:39.423887	7d013472-9c19-4fe6-aa1d-85d56b8e3701	26cbfcdb-c857-4633-ae19-531968b0d330	6eb69a68-1178-46a6-b51d-14506ad90aa6	ab1be757-b07b-4c6c-ab5f-a3361695ff0b
e0404e97-a542-482e-a0b5-149e9cbf879a	2026-03-16	4	ee2ba43b4d38e014a15b4bd17843b27019d5bca7f23914475995ed991fe4621a	{"adults": 2, "children": 0}	489.00	122.25	AVAILABLE	GBP	https://www.centerparcs.co.uk/breaks-we-offer/search.html/2/SF/16-03-2026/4/-/-/1/2/0/0/0/0/N	2026-01-07 14:54:39.435696	7d013472-9c19-4fe6-aa1d-85d56b8e3701	26cbfcdb-c857-4633-ae19-531968b0d330	6eb69a68-1178-46a6-b51d-14506ad90aa6	4736dc12-be8e-4f0a-af03-87c887005879
7bc69c13-f253-41b4-9de4-3b7069876a2d	2026-03-16	4	7f0e625851d33a971964afc85b8a2442c76a6eaf9a361f6930a0f95cdb0fbc16	{"adults": 2, "children": 0}	569.00	142.25	AVAILABLE	GBP	https://www.centerparcs.co.uk/breaks-we-offer/search.html/2/SF/16-03-2026/4/-/-/1/2/0/0/0/0/N	2026-01-07 14:54:39.44442	7d013472-9c19-4fe6-aa1d-85d56b8e3701	26cbfcdb-c857-4633-ae19-531968b0d330	6eb69a68-1178-46a6-b51d-14506ad90aa6	4b3ddca1-b29e-4b6d-a50a-09516df2de65
991f700e-99d6-4c82-a470-f744c286145c	2026-03-16	4	c994450a86521f18049cde3ff385bb7eebcc8fc882a31fbadd9cf89e83fac06b	{"adults": 2, "children": 0}	629.00	157.25	AVAILABLE	GBP	https://www.centerparcs.co.uk/breaks-we-offer/search.html/2/SF/16-03-2026/4/-/-/1/2/0/0/0/0/N	2026-01-07 14:54:39.452583	7d013472-9c19-4fe6-aa1d-85d56b8e3701	26cbfcdb-c857-4633-ae19-531968b0d330	6eb69a68-1178-46a6-b51d-14506ad90aa6	6a8aa8aa-22ee-44a5-a6a4-f86377b1630f
50d1f378-36c9-475c-81f9-0fbf08eedc61	2026-03-16	4	1d58245919037f905050fe39db68613de0a53b38ea293754ec0db56abc931e86	{"adults": 2, "children": 0}	499.00	124.75	AVAILABLE	GBP	https://www.centerparcs.co.uk/breaks-we-offer/search.html/2/SF/16-03-2026/4/-/-/1/2/0/0/0/0/N	2026-01-07 14:54:39.459984	7d013472-9c19-4fe6-aa1d-85d56b8e3701	26cbfcdb-c857-4633-ae19-531968b0d330	6eb69a68-1178-46a6-b51d-14506ad90aa6	bfd6666e-0f46-4791-ae2d-b9092ddf8d60
00d494e0-88cd-4efc-bcf9-84789b172447	2026-03-16	4	8d9eee1aa5a6920081282c071f22990763735e2c71799b7d6e625838c8c2de28	{"adults": 2, "children": 0}	739.00	184.75	AVAILABLE	GBP	https://www.centerparcs.co.uk/breaks-we-offer/search.html/2/SF/16-03-2026/4/-/-/1/2/0/0/0/0/N	2026-01-07 14:54:39.467632	7d013472-9c19-4fe6-aa1d-85d56b8e3701	26cbfcdb-c857-4633-ae19-531968b0d330	6eb69a68-1178-46a6-b51d-14506ad90aa6	e416448d-e5f1-4b97-a9b4-706a36ae8b51
cac1c825-b2dc-4a8e-b1c4-1b6efc3cdac8	2026-03-16	4	e25f93d54bee48ff12ae81f24ce14817c5152b24824303273c5cb7a134fee116	{"adults": 2, "children": 0}	1239.00	309.75	AVAILABLE	GBP	https://www.centerparcs.co.uk/breaks-we-offer/search.html/2/SF/16-03-2026/4/-/-/1/2/0/0/0/0/N	2026-01-07 14:54:39.474962	7d013472-9c19-4fe6-aa1d-85d56b8e3701	26cbfcdb-c857-4633-ae19-531968b0d330	6eb69a68-1178-46a6-b51d-14506ad90aa6	2fb438bb-bc5d-4797-9f93-cc7b73c0364b
0735387f-e5c8-40cb-8cb2-27d4e11bdd3d	2026-03-16	4	97a3ec58ee9ad941d7836fa336850d502ffe8b2f4b66daffe39e1763eeb079d4	{"adults": 2, "children": 0}	699.00	174.75	AVAILABLE	GBP	https://www.centerparcs.co.uk/breaks-we-offer/search.html/2/SF/16-03-2026/4/-/-/1/2/0/0/0/0/N	2026-01-07 14:54:39.480416	7d013472-9c19-4fe6-aa1d-85d56b8e3701	26cbfcdb-c857-4633-ae19-531968b0d330	6eb69a68-1178-46a6-b51d-14506ad90aa6	fc4ac602-b413-42a1-bcae-737d8bb8aaba
57d344cf-1c4f-431d-8b80-8136db0ab4ef	2026-03-16	4	cffa0d79ad713333770a696f259139bdbbb4076f86310924de3e83c0f289dc24	{"adults": 2, "children": 0}	1059.00	264.75	AVAILABLE	GBP	https://www.centerparcs.co.uk/breaks-we-offer/search.html/2/SF/16-03-2026/4/-/-/1/2/0/0/0/0/N	2026-01-07 14:54:39.485374	7d013472-9c19-4fe6-aa1d-85d56b8e3701	26cbfcdb-c857-4633-ae19-531968b0d330	6eb69a68-1178-46a6-b51d-14506ad90aa6	2c1b3bb8-60a2-47d7-bc5c-1b3760a15cbf
5dd3880e-2eb2-4739-8450-fd69a441643c	2026-03-16	4	cffa0d79ad713333770a696f259139bdbbb4076f86310924de3e83c0f289dc24	{"adults": 2, "children": 0}	1249.00	312.25	AVAILABLE	GBP	https://www.centerparcs.co.uk/breaks-we-offer/search.html/2/SF/16-03-2026/4/-/-/1/2/0/0/0/0/N	2026-01-07 14:54:39.489372	7d013472-9c19-4fe6-aa1d-85d56b8e3701	26cbfcdb-c857-4633-ae19-531968b0d330	6eb69a68-1178-46a6-b51d-14506ad90aa6	2c1b3bb8-60a2-47d7-bc5c-1b3760a15cbf
a9c40108-e60a-43c7-9ffb-b1b09a7a922c	2026-03-16	4	8a2dc02ae2e6376d0a4d49c9461a0ddb875187c3fff57c143f51fcba8d5937e7	{"adults": 2, "children": 0}	1599.00	399.75	AVAILABLE	GBP	https://www.centerparcs.co.uk/breaks-we-offer/search.html/2/SF/16-03-2026/4/-/-/1/2/0/0/0/0/N	2026-01-07 14:54:39.494757	7d013472-9c19-4fe6-aa1d-85d56b8e3701	26cbfcdb-c857-4633-ae19-531968b0d330	6eb69a68-1178-46a6-b51d-14506ad90aa6	b8aadfb2-25ed-496b-a9be-1559b056220c
\.


--
-- Data for Name: provider_accom_types; Type: TABLE DATA; Schema: public; Owner: staycation
--

COPY public.provider_accom_types (id, "providerAccomCode", name, "capacityMin", "capacityMax", provider_id) FROM stdin;
f4c6738f-af68-4c27-a288-0b2c41a69bf4	1 bedroom Forest Apartment	1 bedroom Forest Apartment	\N	\N	7d013472-9c19-4fe6-aa1d-85d56b8e3701
968986bb-5a76-4211-bfe2-1c484a04948c	1 bedroom Forest Studio Lodge 	1 bedroom Forest Studio Lodge 	\N	\N	7d013472-9c19-4fe6-aa1d-85d56b8e3701
ab1be757-b07b-4c6c-ab5f-a3361695ff0b	1 bedroom Forest Lodge, two-storey	1 bedroom Forest Lodge, two-storey	\N	\N	7d013472-9c19-4fe6-aa1d-85d56b8e3701
4736dc12-be8e-4f0a-af03-87c887005879	2 bedroom Woodland Lodge	2 bedroom Woodland Lodge	\N	\N	7d013472-9c19-4fe6-aa1d-85d56b8e3701
4b3ddca1-b29e-4b6d-a50a-09516df2de65	2 bedroom Forest Lodge	2 bedroom Forest Lodge	\N	\N	7d013472-9c19-4fe6-aa1d-85d56b8e3701
6a8aa8aa-22ee-44a5-a6a4-f86377b1630f	2 bedroom Forest Lodge, two-storey	2 bedroom Forest Lodge, two-storey	\N	\N	7d013472-9c19-4fe6-aa1d-85d56b8e3701
bfd6666e-0f46-4791-ae2d-b9092ddf8d60	3 bedroom Woodland Lodge	3 bedroom Woodland Lodge	\N	\N	7d013472-9c19-4fe6-aa1d-85d56b8e3701
e416448d-e5f1-4b97-a9b4-706a36ae8b51	3 bedroom Forest Lodge	3 bedroom Forest Lodge	\N	\N	7d013472-9c19-4fe6-aa1d-85d56b8e3701
2fb438bb-bc5d-4797-9f93-cc7b73c0364b	3 bedroom Forest Lodge with hot tub	3 bedroom Forest Lodge with hot tub	\N	\N	7d013472-9c19-4fe6-aa1d-85d56b8e3701
fc4ac602-b413-42a1-bcae-737d8bb8aaba	4 bedroom Woodland Lodge	4 bedroom Woodland Lodge	\N	\N	7d013472-9c19-4fe6-aa1d-85d56b8e3701
2c1b3bb8-60a2-47d7-bc5c-1b3760a15cbf	4 bedroom Forest Lodge	4 bedroom Forest Lodge	\N	\N	7d013472-9c19-4fe6-aa1d-85d56b8e3701
b8aadfb2-25ed-496b-a9be-1559b056220c	4 bedroom Exclusive Lodge	4 bedroom Exclusive Lodge	\N	\N	7d013472-9c19-4fe6-aa1d-85d56b8e3701
\.


--
-- Data for Name: provider_parks; Type: TABLE DATA; Schema: public; Owner: staycation
--

COPY public.provider_parks (id, "providerParkCode", name, region, latitude, longitude, provider_id) FROM stdin;
f82b0f2e-4912-4751-88a7-684fd861e912	devon-cliffs	Devon Cliffs	Devon	\N	\N	3766d1a8-c727-4acd-b84f-1461922f2c58
7abe7e6c-ac5a-48db-89a6-843e9e9c6d94	thorpe-park	Thorpe Park	Lincolnshire	\N	\N	3766d1a8-c727-4acd-b84f-1461922f2c58
77ac5443-a872-4d1a-b413-b0a0cf611735	primrose-valley	Primrose Valley	Yorkshire	\N	\N	3766d1a8-c727-4acd-b84f-1461922f2c58
\.


--
-- Data for Name: providers; Type: TABLE DATA; Schema: public; Owner: staycation
--

COPY public.providers (id, code, name, "baseUrl", notes, enabled, "checkFrequencyHours", "maxConcurrent", "createdAt", "updatedAt") FROM stdin;
7cc332a1-df65-4c83-a6a1-08c0b5db60c4	hoseasons	Hoseasons	https://www.hoseasons.co.uk	UK holiday parks and lodges	t	48	2	2026-01-03 16:59:22.926345	2026-01-03 16:59:22.926345
3766d1a8-c727-4acd-b84f-1461922f2c58	haven	Haven	https://www.haven.com	UK holiday parks	t	48	2	2026-01-03 16:59:22.942928	2026-01-03 16:59:22.942928
7d013472-9c19-4fe6-aa1d-85d56b8e3701	centerparcs	Center Parcs	https://www.centerparcs.co.uk	\N	t	48	2	2026-01-05 10:38:51.711443	2026-01-05 10:38:51.711443
3c4b9c10-09f6-48e9-bf1f-6d927456a561	parkdean	Parkdean Resorts	https://www.parkdeanresorts.co.uk	\N	t	48	2	2026-01-05 10:38:51.711443	2026-01-05 10:38:51.711443
ce272ff0-dadc-4fb5-8c58-fc0d80096e57	butlins	Butlin's	https://www.butlins.com	\N	t	48	2	2026-01-05 10:38:51.711443	2026-01-05 10:38:51.711443
1b4caf59-2dfb-44f0-8e6c-5a7420a41702	awayresorts	Away Resorts	https://www.awayresorts.co.uk	\N	t	48	2	2026-01-05 10:38:51.711443	2026-01-05 10:38:51.711443
\.


--
-- Data for Name: search_fingerprints; Type: TABLE DATA; Schema: public; Owner: staycation
--

COPY public.search_fingerprints (id, "canonicalHash", "canonicalJson", "checkFrequencyHours", "lastScheduledAt", enabled, "createdAt", "updatedAt", profile_id, provider_id, park_id, accom_type_id, "snoozedUntil") FROM stdin;
26cbfcdb-c857-4633-ae19-531968b0d330	d54be7e008d95896f2c5d6e9d6c93814a0664b56f4898ef0526e1dfe9878b397	{"pets": false, "parks": ["SF"], "party": {"adults": 2, "children": 0}, "nights": {"max": 4, "min": 4}, "region": null, "provider": "centerparcs", "dateWindow": {"end": "2026-03-20", "start": "2026-03-16"}, "minBedrooms": 0, "peakTolerance": "MIXED"}	48	2026-01-07 14:54:39.513	t	2026-01-07 09:54:56.775886	2026-01-07 14:54:39.51729	ee7c526f-bfad-4359-a6e6-732005ded367	7d013472-9c19-4fe6-aa1d-85d56b8e3701	\N	\N	\N
366af078-71c5-4b7e-98ed-5267ee24dc2a	0e3b1d740f640e2abae12890e19393e58d6b1726414cdbde37fc1777e9cd74c1	{"pets": false, "party": {"adults": 2, "children": 0}, "nights": {"max": 7, "min": 3}, "region": "Sherwood", "provider": "centerparcs", "dateWindow": {"end": "2026-06-15", "start": "2026-06-12"}, "minBedrooms": 0, "peakTolerance": "MIXED"}	48	2026-01-07 14:34:41.985	t	2026-01-05 10:40:28.533414	2026-01-07 14:34:41.989849	d52beef0-76ad-424a-8ecd-a33c573be2d7	7d013472-9c19-4fe6-aa1d-85d56b8e3701	\N	\N	\N
\.


--
-- Data for Name: system_logs; Type: TABLE DATA; Schema: public; Owner: staycation
--

COPY public.system_logs (id, level, message, source, details, "createdAt") FROM stdin;
6146ff6b-4562-4919-b9f9-b50d71962ada	INFO	API Server Started	System	{"port": 4000}	2026-01-05 13:51:08.392768
610207f9-8eb4-4bb8-92d2-05e02979a072	INFO	API Server Started	System	{"port": 4000}	2026-01-05 14:00:34.005698
d38e0c43-6ba1-4427-8c80-f124a8bfdee9	INFO	API Server Started	System	{"port": 4000}	2026-01-05 14:04:36.983227
06d46913-cd07-4956-a9bd-120bc83e148f	INFO	API Server Started	System	{"port": 4000}	2026-01-05 14:22:51.688917
dd06a0ea-ef24-4b20-9741-829092ad5cc9	INFO	API Server Started	System	{"port": 4000}	2026-01-05 14:26:35.087298
f4f82148-be0a-43c4-aa63-699c338d1523	INFO	API Server Started	System	{"port": 4000}	2026-01-05 14:32:15.252629
fd2d4dc2-03d0-4762-9ba5-31bcbb1a51c4	INFO	API Server Started	System	{"port": 4000}	2026-01-05 14:38:42.901139
3d4355ed-d9f0-4fdf-9537-74fdcd125581	ERROR	API Error: update or delete on table "search_fingerprints" violates foreign key constraint "FK_1819dd7a4b8dc42adcb03deb957" on table "fetch_runs"	API_Global	{"url": "/admin/watchers/8fd9c4e7-303f-43c1-b884-5e2f527f60e4", "code": "23503", "stack": "QueryFailedError: update or delete on table \\"search_fingerprints\\" violates foreign key constraint \\"FK_1819dd7a4b8dc42adcb03deb957\\" on table \\"fetch_runs\\"\\n    at PostgresQueryRunner.query (/app/node_modules/typeorm/driver/src/driver/postgres/PostgresQueryRunner.ts:325:19)\\n    at process.processTicksAndRejections (node:internal/process/task_queues:95:5)\\n    at async DeleteQueryBuilder.execute (/app/node_modules/typeorm/query-builder/src/query-builder/DeleteQueryBuilder.ts:77:33)\\n    at async Object.<anonymous> (/app/src/routes/admin.ts:165:9)", "method": "DELETE"}	2026-01-05 14:45:51.643245
3d5bb8cd-e31e-4e54-a5af-4c37aa1cbfa9	ERROR	API Error: update or delete on table "search_fingerprints" violates foreign key constraint "FK_1819dd7a4b8dc42adcb03deb957" on table "fetch_runs"	API_Global	{"url": "/admin/watchers/d987ade3-fe70-4100-a23d-18b2a4fc5710", "code": "23503", "stack": "QueryFailedError: update or delete on table \\"search_fingerprints\\" violates foreign key constraint \\"FK_1819dd7a4b8dc42adcb03deb957\\" on table \\"fetch_runs\\"\\n    at PostgresQueryRunner.query (/app/node_modules/typeorm/driver/src/driver/postgres/PostgresQueryRunner.ts:325:19)\\n    at process.processTicksAndRejections (node:internal/process/task_queues:95:5)\\n    at async DeleteQueryBuilder.execute (/app/node_modules/typeorm/query-builder/src/query-builder/DeleteQueryBuilder.ts:77:33)\\n    at async Object.<anonymous> (/app/src/routes/admin.ts:165:9)", "method": "DELETE"}	2026-01-05 14:45:59.026715
9389f411-5f8d-4bed-9281-799ba53abaf1	INFO	API Server Started	System	{"port": 4000}	2026-01-05 14:46:45.290141
2d30a9ea-6be0-4100-b9ca-1ebf923e76a7	INFO	API Server Started	System	{"port": 4000}	2026-01-05 15:20:23.04278
cde186fa-852a-4f89-bfa7-4f24f1e7e487	INFO	API Server Started	System	{"port": 4000}	2026-01-05 15:29:28.097976
1553a0c5-176e-40f0-9f6b-8b44a02982b8	INFO	API Server Started	System	{"port": 4000}	2026-01-05 15:35:43.804441
7b6cac77-e9ac-43bc-b4fb-7b44faaa71f9	INFO	Worker Process Started	Worker	{"pid": 29}	2026-01-05 15:35:43.849495
7d6a76ce-2f43-464a-ae7b-ad84dd7a5aa2	INFO	Worker Process Started	Worker	{"pid": 29}	2026-01-05 15:51:02.004479
f3597ff7-8fd5-40e7-84e0-3f06fcbe3db8	INFO	Worker Process Started	Worker	{"pid": 29}	2026-01-05 15:53:14.299777
a7db59c2-5340-48a7-b351-832d76dcbaab	INFO	API Server Started	System	{"port": 4000}	2026-01-05 15:53:14.575858
4e77845d-d717-4352-862e-96b439d60a79	INFO	Worker Process Started	Worker	{"pid": 73}	2026-01-05 17:01:18.231287
bd298922-c4a9-441f-94cc-bfa733290adf	INFO	API Server Started	System	{"port": 4000}	2026-01-05 17:01:22.507473
1b13d685-f720-4632-9df6-b287edd5a1de	INFO	API Server Started	System	{"port": 4000}	2026-01-05 17:04:22.636091
8be100c3-1b09-4031-ba56-353c94a793ee	INFO	Worker Process Started	Worker	{"pid": 29}	2026-01-05 17:48:47.853446
18da1eae-4d93-487b-b948-7124b704a8ce	INFO	API Server Started	System	{"port": 4000}	2026-01-05 17:48:48.274338
2a5608e1-995e-433d-a6b9-e396501519f7	INFO	API Server Started	System	{"port": 4000}	2026-01-05 18:32:48.534966
a4ae02c9-4a9c-44aa-90e8-0217fc7eab84	INFO	API Server Started	System	{"port": 4000}	2026-01-05 18:33:49.523281
17749933-67b7-4f84-8d28-161de83ed2a5	INFO	Worker Process Started	Worker	{"pid": 29}	2026-01-05 18:46:10.47422
d9210e6e-5346-4111-90a5-ab6ddf7f8aa2	INFO	API Server Started	System	{"port": 4000}	2026-01-05 18:46:10.650329
b0c6f9ba-86ba-4115-b5fe-4cbc4214f984	INFO	API Server Started	System	{"port": 4000}	2026-01-05 18:48:51.10871
a92322d2-465a-4fe6-a732-4343f3a27329	INFO	Worker Process Started	Worker	{"pid": 29}	2026-01-05 18:50:53.96179
34fdd3e8-4ddd-42b5-8821-e1a9018d8a68	INFO	API Server Started	System	{"port": 4000}	2026-01-05 18:50:54.18824
adf221a6-8b5d-43b3-8667-7de64300ae0b	INFO	Worker Process Started	Worker	{"pid": 29}	2026-01-05 18:54:05.377482
8179f211-9c91-4636-a1f6-f16620a32d7a	INFO	API Server Started	System	{"port": 4000}	2026-01-05 18:54:05.64084
dbdcb43c-41a2-4579-8723-0022b1ec6a17	INFO	Worker Process Started	Worker	{"pid": 29}	2026-01-05 19:05:59.974598
2486c3e1-b5dd-4e66-b224-de09322038ac	INFO	API Server Started	System	{"port": 4000}	2026-01-05 19:06:00.219831
33b3895e-d308-4d3d-a785-511a3ee357cd	INFO	API Server Started	System	{"port": 4000}	2026-01-05 19:11:33.993474
4e7fe793-290b-4d38-8e70-0ef06cad21b8	INFO	Worker Process Started	Worker	{"pid": 29}	2026-01-05 19:39:28.073937
eeed7689-5b11-45e5-b535-459520abd8fe	INFO	API Server Started	System	{"port": 4000}	2026-01-05 19:39:28.351928
6663ab26-77f9-4ced-9b80-c5374a95b57f	INFO	API Server Started	System	{"port": 4000}	2026-01-05 19:42:43.132027
e88d8e62-0c57-46b7-bf0b-3842b2483217	INFO	API Server Started	System	{"port": 4000}	2026-01-05 19:49:31.282488
104abc30-e066-4c0f-9334-f7ff781d2a4d	INFO	API Server Started	System	{"port": 4000}	2026-01-05 19:52:14.01708
af9dd7eb-86fa-4793-a643-81cd29b5cc4d	INFO	API Server Started	System	{"port": 4000}	2026-01-05 19:52:49.080035
cfef0061-2478-4949-8d10-e03d9997ed74	INFO	Worker Process Started	Worker	{"pid": 29}	2026-01-05 19:56:42.669634
fa3fc52a-2322-4eb3-9c7c-85a3916d4d7a	INFO	API Server Started	System	{"port": 4000}	2026-01-05 19:56:42.85947
f4358280-09db-4aee-bb30-6ef0bd12217e	WARN	No results parsed from centerparcs	Worker_Monitor	{"params": {"pets": false, "party": {"adults": 2, "children": 0}, "nights": {"max": 7, "min": 3}, "region": "Sherwood", "provider": "centerparcs", "dateWindow": {"end": "2026-06-15", "start": "2026-06-12"}, "minBedrooms": 0, "peakTolerance": "MIXED"}, "providerId": "7d013472-9c19-4fe6-aa1d-85d56b8e3701", "fingerprintId": "366af078-71c5-4b7e-98ed-5267ee24dc2a"}	2026-01-05 22:13:44.666004
8c36fb2e-362e-4174-8fd2-d2ccae92e103	INFO	API Server Started	System	{"port": 4000}	2026-01-06 22:19:17.904468
dfb4a106-ed8e-4ade-9817-3626280eaef5	INFO	API Server Started	System	{"port": 4000}	2026-01-06 22:21:32.708607
1633c945-aa1e-4ea8-8953-6e743b489ae3	INFO	API Server Started	System	{"port": 4000}	2026-01-06 22:22:44.572744
dd2a6498-de7d-42bf-855f-aeead74720a7	INFO	API Server Started	System	{"port": 4000}	2026-01-06 22:33:10.685368
23f088b6-2060-4ff7-bdce-3d32b2a1dfa8	INFO	API Server Started	System	{"port": 4000}	2026-01-06 22:37:58.438963
6da45825-ec12-41ff-8585-77a74273dc31	INFO	API Server Started	System	{"port": 4000}	2026-01-06 22:38:28.425613
da54ba4f-48ac-4740-b51e-909d1212fb05	INFO	Worker Process Started	Worker	{"pid": 29}	2026-01-07 09:06:59.087951
b7d08b13-20fc-4cbc-8eab-4abcb0d57e82	INFO	API Server Started	System	{"port": 4000}	2026-01-07 09:06:59.296443
812e0b3e-d6c3-4b40-978b-44dff1de6c39	INFO	API Server Started	System	{"port": 4000}	2026-01-07 09:23:39.674305
1ea797f2-a274-4f17-8e57-84bb0c85f271	INFO	API Server Started	System	{"port": 4000}	2026-01-07 09:33:54.948173
a10bb634-1d1f-448d-a959-384d7267b9af	INFO	API Server Started	System	{"port": 4000}	2026-01-07 09:35:02.478301
cf01a9ac-1a22-4489-9969-400205fed6e1	INFO	API Server Started	System	{"port": 4000}	2026-01-07 09:38:19.959621
a6706bd3-326f-49a3-b894-a215a927fbd8	INFO	API Server Started	System	{"port": 4000}	2026-01-07 09:42:49.630764
1ac93912-1906-4795-b116-e38614328d9f	INFO	API Server Started	System	{"port": 4000}	2026-01-07 09:50:02.932756
a048c96a-ed13-447b-ba48-2239bf7aaf9f	INFO	API Server Started	System	{"port": 4000}	2026-01-07 09:53:11.67557
06c36941-98c6-4745-9872-bb2fd32fe2f1	INFO	API Server Started	System	{"port": 4000}	2026-01-07 09:59:10.803409
7f6c6d3a-6ba6-41cc-b522-c47f15ca9ee9	WARN	No results parsed from centerparcs	Worker_Monitor	{"params": {"pets": false, "parks": ["SF"], "party": {"adults": 2, "children": 0}, "nights": {"max": 4, "min": 4}, "region": null, "provider": "centerparcs", "dateWindow": {"end": "2026-03-20", "start": "2026-03-16"}, "minBedrooms": 0, "peakTolerance": "MIXED"}, "providerId": "7d013472-9c19-4fe6-aa1d-85d56b8e3701", "fingerprintId": "26cbfcdb-c857-4633-ae19-531968b0d330"}	2026-01-07 10:02:31.61466
47fede18-f2f0-4a74-bd09-e84499c7cf59	INFO	API Server Started	System	{"port": 4000}	2026-01-07 10:04:13.915296
95f44f72-57b2-4a52-bd1d-8818c481b583	INFO	API Server Started	System	{"port": 4000}	2026-01-07 10:08:59.479974
490fb866-b836-4f67-9e00-df9b546d2308	INFO	API Server Started	System	{"port": 4000}	2026-01-07 10:12:43.812236
f579c52e-35b3-4d02-8bc1-3a48691176ca	INFO	API Server Started	System	{"port": 4000}	2026-01-07 10:16:57.776656
f7085afd-dc12-4084-a4a3-592b535c5f7d	INFO	API Server Started	System	{"port": 4000}	2026-01-07 10:23:08.240076
e78a1b9c-d102-40db-b815-db04a4dba9ff	INFO	API Server Started	System	{"port": 4000}	2026-01-07 10:42:51.763764
9c18d054-ce35-4591-a281-95a911a134d2	INFO	Worker Process Started	Worker	{"pid": 29}	2026-01-07 10:42:51.797047
8293b620-2fb0-41ad-95ee-6a9ca4ffaae2	INFO	API Server Started	System	{"port": 4000}	2026-01-07 10:49:07.485521
3fe2eeaa-a012-4b9c-a944-45e4d63e6a76	INFO	API Server Started	System	{"port": 4000}	2026-01-07 10:51:11.799326
67e34999-30f3-42ca-80aa-82c94fc7180f	INFO	API Server Started	System	{"port": 4000}	2026-01-07 10:57:30.019405
fe5d5061-933d-49ff-ab85-4563266ce0ea	INFO	API Server Started	System	{"port": 4000}	2026-01-07 11:01:15.864679
a529fd7c-44e4-4ea9-8123-fe9833994ede	WARN	No results parsed from centerparcs	Worker_Monitor	{"params": {"pets": false, "parks": ["SF"], "party": {"adults": 2, "children": 0}, "nights": {"max": 4, "min": 4}, "region": null, "provider": "centerparcs", "dateWindow": {"end": "2026-03-20", "start": "2026-03-16"}, "minBedrooms": 0, "peakTolerance": "MIXED"}, "providerId": "7d013472-9c19-4fe6-aa1d-85d56b8e3701", "fingerprintId": "26cbfcdb-c857-4633-ae19-531968b0d330"}	2026-01-07 11:06:34.460121
bdb62a9b-5290-4cb8-8e18-97c090542236	INFO	API Server Started	System	{"port": 4000}	2026-01-07 11:07:11.212534
a60c3485-7d9b-4844-ac66-6bb25f8673f7	INFO	API Server Started	System	{"port": 4000}	2026-01-07 11:50:55.266951
6091a1e7-9b14-4c44-ae5c-0819550f4ab3	INFO	API Server Started	System	{"port": 4000}	2026-01-07 12:00:02.338438
dc986406-2354-4720-b1a8-f54d181acef8	WARN	No results parsed from centerparcs	Worker_Monitor	{"params": {"pets": false, "parks": ["SF"], "party": {"adults": 2, "children": 0}, "nights": {"max": 4, "min": 4}, "region": null, "provider": "centerparcs", "dateWindow": {"end": "2026-03-20", "start": "2026-03-16"}, "minBedrooms": 0, "peakTolerance": "MIXED"}, "providerId": "7d013472-9c19-4fe6-aa1d-85d56b8e3701", "fingerprintId": "26cbfcdb-c857-4633-ae19-531968b0d330"}	2026-01-07 12:03:32.043351
2f12af07-f808-4c61-9261-135175225b89	INFO	Worker Process Started	Worker	{"pid": 29}	2026-01-07 12:06:56.931111
c0623ff8-f46f-447d-a52f-a5f655f860df	INFO	API Server Started	System	{"port": 4000}	2026-01-07 12:06:57.297433
5900d094-828c-4258-97ac-760718704869	INFO	API Server Started	System	{"port": 4000}	2026-01-07 12:23:45.097977
9591c8e4-001d-483f-a20f-64f10b30079c	INFO	API Server Started	System	{"port": 4000}	2026-01-07 12:26:54.036704
4c913a20-3cca-4695-acbe-860154078dd9	INFO	Worker Process Started	Worker	{"pid": 29}	2026-01-07 12:38:46.779032
681fc3aa-c7b3-4d65-9f3c-ae3749e94cd9	INFO	API Server Started	System	{"port": 4000}	2026-01-07 12:38:47.831519
b75ffebe-4366-4813-a9fd-5d174cde204e	INFO	API Server Started	System	{"port": 4000}	2026-01-07 12:46:01.082682
0fe4f13d-2a88-45b0-a47d-b58dc85816db	INFO	API Server Started	System	{"port": 4000}	2026-01-07 12:51:22.112468
e9961f75-58f7-442d-977d-d02f63793ae2	INFO	API Server Started	System	{"port": 4000}	2026-01-07 13:01:55.831092
8ed0855e-6b6d-4869-84da-eba75f9f4b05	INFO	API Server Started	System	{"port": 4000}	2026-01-07 13:02:13.157042
65f8759b-a4fa-43e2-a063-34176126d3e8	INFO	API Server Started	System	{"port": 4000}	2026-01-07 13:08:49.85599
2ccebeb5-e786-415f-bc88-9bb019764d4c	INFO	API Server Started	System	{"port": 4000}	2026-01-07 13:15:20.201003
35a572fe-16c2-4525-b54f-fffb81ebf1e0	INFO	Worker Process Started	Worker	{"pid": 29}	2026-01-07 13:19:12.861997
09ee01a2-c65e-403d-9fb0-f2a199d953d6	INFO	Worker Process Started	Worker	{"pid": 29}	2026-01-07 14:05:22.659964
dd79ac96-a6de-4544-b94b-a26b9823ac44	INFO	API Server Started	System	{"port": 4000}	2026-01-07 14:05:57.701487
2b3f81ae-063b-4947-b6c4-fecc2da8b7f2	INFO	Worker Process Started	Worker	{"pid": 29}	2026-01-07 14:05:58.46629
52ea7733-473a-46f7-95c1-17c0b98ed14f	INFO	Worker Process Started	Worker	{"pid": 29}	2026-01-07 14:12:45.992317
9be83526-14ca-4018-901f-364d865eb900	INFO	Worker Process Started	Worker	{"pid": 29}	2026-01-07 14:15:19.414473
71b3e692-8376-40b5-83c9-9b487a2f346f	INFO	Worker Process Started	Worker	{"pid": 29}	2026-01-07 14:16:38.83292
7f50eed4-7faf-42d4-acc1-9b80dcf6b71c	INFO	Worker Process Started	Worker	{"pid": 29}	2026-01-07 14:20:16.552721
3b1206c8-1ec6-4f4e-a219-6b2645cb2f22	INFO	Worker Process Started	Worker	{"pid": 29}	2026-01-07 14:31:42.432135
72ef58a8-022b-4100-8dfe-eb135fae9888	INFO	Worker Process Started	Worker	{"pid": 29}	2026-01-07 14:32:00.278077
111632cd-cef6-4273-955e-6350d437b4b7	INFO	API Server Started	System	{"port": 4000}	2026-01-07 14:46:38.472222
9a05dd05-7111-44eb-b8c2-88c431572e0e	INFO	API Server Started	System	{"port": 4000}	2026-01-07 14:49:48.90185
4324b72f-54ab-4ffa-bc40-b80c3be3c72d	INFO	Worker Process Started	Worker	{"pid": 296}	2026-01-07 14:54:22.66597
63e9d14d-2e89-4d68-a971-b6dfc999aa9f	INFO	Worker Process Started	Worker	{"pid": 29}	2026-01-07 14:54:27.817268
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: staycation
--

COPY public.users (id, email, "passwordHash", name, "emailVerified", "verificationToken", "verificationTokenExpires", "notificationsEnabled", "createdAt", "updatedAt", "passwordResetToken", "passwordResetExpires", "notificationChannels", "digestMode", mobile, language, "defaultCheckFrequencyHours", role) FROM stdin;
6b2e1f6a-7fa9-4d77-93f5-8f0218fe49fa	test_user_no_email@example.com	$2b$12$RWTR4o4sekHE8v6QJ9k58.1hMacPZleGDRPP3LoHALRAx3w2yUywO	\N	f	f771d1f2b3bc7cd854d45f49da9f512c03845a44734ca94e234d04f740b91e1a	\N	t	2026-01-03 17:40:39.505079	2026-01-03 17:40:39.505079	\N	\N	{email}	f	\N	en	48	USER
4012a352-1d4d-4440-bd6d-4a825593cc96	jamescregeen@gmail.com	$2b$12$5XBW8OKQ/908pu8ab3iTrOUCK6WjiH1rfi6ICGoQAcz434hWUY5Vm	James Cregeen	t	9c35b4936d2c40fd7097c8bf7c73a702bb5ad038c0f3bdaace54636b56aff1a3	\N	t	2026-01-03 17:37:20.119441	2026-01-05 09:59:23.195797	\N	\N	{email}	f	+447949701342	en	12	ADMIN
24b003ce-33d4-48cd-ae65-b8002f8fe910	test@gmail.com	$2b$12$WPgY1.bCRlQdEylaYv8ua.bRNgAeOq3DgOMABuqnxPHr6HS5iT/ly	\N	t	fdb280bb13f168b278203c3e0a589f05fa1c93600d9d933d444945446b5afc04	\N	t	2026-01-04 20:29:35.536657	2026-01-05 14:32:39.379108	\N	\N	{email}	f	\N	en	48	USER
dc8b5d0a-3ce2-43bc-b8dc-28aa570c4523	screenshot_user@test.com	$2b$12$nLnjJSIAcEPOYNzXCvVbiu6VA4IW0hrVLS3QcGvWl6W1TPdVT7iFe	\N	f	032fd4413b692b79074d0e9d5bc7ecfe2989d4670489f7c3695350d373734b96	\N	t	2026-01-07 17:47:00.964669	2026-01-07 17:47:00.964669	\N	\N	{email}	f	\N	en	48	USER
\.


--
-- Name: migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: staycation
--

SELECT pg_catalog.setval('public.migrations_id_seq', 3, true);


--
-- Name: provider_accom_types PK_24011ac6a622e3b8c06f622fe2d; Type: CONSTRAINT; Schema: public; Owner: staycation
--

ALTER TABLE ONLY public.provider_accom_types
    ADD CONSTRAINT "PK_24011ac6a622e3b8c06f622fe2d" PRIMARY KEY (id);


--
-- Name: search_fingerprints PK_45c32fedb4785ed31ec7954f758; Type: CONSTRAINT; Schema: public; Owner: staycation
--

ALTER TABLE ONLY public.search_fingerprints
    ADD CONSTRAINT "PK_45c32fedb4785ed31ec7954f758" PRIMARY KEY (id);


--
-- Name: system_logs PK_56861c4b9d16aa90259f4ce0a2c; Type: CONSTRAINT; Schema: public; Owner: staycation
--

ALTER TABLE ONLY public.system_logs
    ADD CONSTRAINT "PK_56861c4b9d16aa90259f4ce0a2c" PRIMARY KEY (id);


--
-- Name: alerts PK_60f895662df096bfcdfab7f4b96; Type: CONSTRAINT; Schema: public; Owner: staycation
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT "PK_60f895662df096bfcdfab7f4b96" PRIMARY KEY (id);


--
-- Name: holiday_profiles PK_7c9fc0e94836706da366c899588; Type: CONSTRAINT; Schema: public; Owner: staycation
--

ALTER TABLE ONLY public.holiday_profiles
    ADD CONSTRAINT "PK_7c9fc0e94836706da366c899588" PRIMARY KEY (id);


--
-- Name: insights PK_8616ab29fa49b7942541b8c964a; Type: CONSTRAINT; Schema: public; Owner: staycation
--

ALTER TABLE ONLY public.insights
    ADD CONSTRAINT "PK_8616ab29fa49b7942541b8c964a" PRIMARY KEY (id);


--
-- Name: deals PK_8c66f03b250f613ff8615940b4b; Type: CONSTRAINT; Schema: public; Owner: staycation
--

ALTER TABLE ONLY public.deals
    ADD CONSTRAINT "PK_8c66f03b250f613ff8615940b4b" PRIMARY KEY (id);


--
-- Name: migrations PK_8c82d7f526340ab734260ea46be; Type: CONSTRAINT; Schema: public; Owner: staycation
--

ALTER TABLE ONLY public.migrations
    ADD CONSTRAINT "PK_8c82d7f526340ab734260ea46be" PRIMARY KEY (id);


--
-- Name: users PK_a3ffb1c0c8416b9fc6f907b7433; Type: CONSTRAINT; Schema: public; Owner: staycation
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "PK_a3ffb1c0c8416b9fc6f907b7433" PRIMARY KEY (id);


--
-- Name: providers PK_af13fc2ebf382fe0dad2e4793aa; Type: CONSTRAINT; Schema: public; Owner: staycation
--

ALTER TABLE ONLY public.providers
    ADD CONSTRAINT "PK_af13fc2ebf382fe0dad2e4793aa" PRIMARY KEY (id);


--
-- Name: fetch_runs PK_cb88a8bcf4c7a009242613a07d5; Type: CONSTRAINT; Schema: public; Owner: staycation
--

ALTER TABLE ONLY public.fetch_runs
    ADD CONSTRAINT "PK_cb88a8bcf4c7a009242613a07d5" PRIMARY KEY (id);


--
-- Name: provider_parks PK_d4cf3ff1ca30e2b0f78d0b4ad66; Type: CONSTRAINT; Schema: public; Owner: staycation
--

ALTER TABLE ONLY public.provider_parks
    ADD CONSTRAINT "PK_d4cf3ff1ca30e2b0f78d0b4ad66" PRIMARY KEY (id);


--
-- Name: price_observations PK_e6c673b1a567075d17a300a7f71; Type: CONSTRAINT; Schema: public; Owner: staycation
--

ALTER TABLE ONLY public.price_observations
    ADD CONSTRAINT "PK_e6c673b1a567075d17a300a7f71" PRIMARY KEY (id);


--
-- Name: insights UQ_842d6055f9dd51ebad2e73f36ae; Type: CONSTRAINT; Schema: public; Owner: staycation
--

ALTER TABLE ONLY public.insights
    ADD CONSTRAINT "UQ_842d6055f9dd51ebad2e73f36ae" UNIQUE ("dedupeKey");


--
-- Name: users UQ_97672ac88f789774dd47f7c8be3; Type: CONSTRAINT; Schema: public; Owner: staycation
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "UQ_97672ac88f789774dd47f7c8be3" UNIQUE (email);


--
-- Name: providers UQ_cdc1db37b0ed3c1c6bc8c1f0458; Type: CONSTRAINT; Schema: public; Owner: staycation
--

ALTER TABLE ONLY public.providers
    ADD CONSTRAINT "UQ_cdc1db37b0ed3c1c6bc8c1f0458" UNIQUE (code);


--
-- Name: alerts UQ_d462ef6348dab8d4a1ad69a144a; Type: CONSTRAINT; Schema: public; Owner: staycation
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT "UQ_d462ef6348dab8d4a1ad69a144a" UNIQUE ("dedupeKey");


--
-- Name: search_fingerprints UQ_e292dbe9a397869976bd2c3719c; Type: CONSTRAINT; Schema: public; Owner: staycation
--

ALTER TABLE ONLY public.search_fingerprints
    ADD CONSTRAINT "UQ_e292dbe9a397869976bd2c3719c" UNIQUE ("canonicalHash");


--
-- Name: IDX_25284b251d23437cf1dfd32b88; Type: INDEX; Schema: public; Owner: staycation
--

CREATE INDEX "IDX_25284b251d23437cf1dfd32b88" ON public.fetch_runs USING btree (provider_id, "startedAt");


--
-- Name: IDX_8255879e189354927b5cd3186b; Type: INDEX; Schema: public; Owner: staycation
--

CREATE INDEX "IDX_8255879e189354927b5cd3186b" ON public.system_logs USING btree ("createdAt");


--
-- Name: IDX_842d6055f9dd51ebad2e73f36a; Type: INDEX; Schema: public; Owner: staycation
--

CREATE UNIQUE INDEX "IDX_842d6055f9dd51ebad2e73f36a" ON public.insights USING btree ("dedupeKey");


--
-- Name: IDX_85e5d40ecd7d907f8161a14ecd; Type: INDEX; Schema: public; Owner: staycation
--

CREATE INDEX "IDX_85e5d40ecd7d907f8161a14ecd" ON public.price_observations USING btree (fingerprint_id, "stayStartDate", "stayNights", "observedAt");


--
-- Name: IDX_97672ac88f789774dd47f7c8be; Type: INDEX; Schema: public; Owner: staycation
--

CREATE UNIQUE INDEX "IDX_97672ac88f789774dd47f7c8be" ON public.users USING btree (email);


--
-- Name: IDX_a4d57d243d15a45c981aaab0e2; Type: INDEX; Schema: public; Owner: staycation
--

CREATE INDEX "IDX_a4d57d243d15a45c981aaab0e2" ON public.system_logs USING btree (level);


--
-- Name: IDX_ac47a069c7039b4cc2668eff86; Type: INDEX; Schema: public; Owner: staycation
--

CREATE UNIQUE INDEX "IDX_ac47a069c7039b4cc2668eff86" ON public.provider_accom_types USING btree (provider_id, "providerAccomCode");


--
-- Name: IDX_c22bd7ff5f62d6358495ac177a; Type: INDEX; Schema: public; Owner: staycation
--

CREATE UNIQUE INDEX "IDX_c22bd7ff5f62d6358495ac177a" ON public.provider_parks USING btree (provider_id, "providerParkCode");


--
-- Name: IDX_ceaad712533817944c64b42e07; Type: INDEX; Schema: public; Owner: staycation
--

CREATE UNIQUE INDEX "IDX_ceaad712533817944c64b42e07" ON public.deals USING btree (source, "sourceRef");


--
-- Name: IDX_d462ef6348dab8d4a1ad69a144; Type: INDEX; Schema: public; Owner: staycation
--

CREATE UNIQUE INDEX "IDX_d462ef6348dab8d4a1ad69a144" ON public.alerts USING btree ("dedupeKey");


--
-- Name: IDX_dee782e49b1873a1aa7b430f11; Type: INDEX; Schema: public; Owner: staycation
--

CREATE INDEX "IDX_dee782e49b1873a1aa7b430f11" ON public.price_observations USING btree (fingerprint_id, "seriesKey", "observedAt");


--
-- Name: IDX_e292dbe9a397869976bd2c3719; Type: INDEX; Schema: public; Owner: staycation
--

CREATE UNIQUE INDEX "IDX_e292dbe9a397869976bd2c3719" ON public.search_fingerprints USING btree ("canonicalHash");


--
-- Name: search_fingerprints FK_168362d2addf80b24fc5c89c5c2; Type: FK CONSTRAINT; Schema: public; Owner: staycation
--

ALTER TABLE ONLY public.search_fingerprints
    ADD CONSTRAINT "FK_168362d2addf80b24fc5c89c5c2" FOREIGN KEY (profile_id) REFERENCES public.holiday_profiles(id) ON DELETE CASCADE;


--
-- Name: fetch_runs FK_1819dd7a4b8dc42adcb03deb957; Type: FK CONSTRAINT; Schema: public; Owner: staycation
--

ALTER TABLE ONLY public.fetch_runs
    ADD CONSTRAINT "FK_1819dd7a4b8dc42adcb03deb957" FOREIGN KEY (fingerprint_id) REFERENCES public.search_fingerprints(id) ON DELETE CASCADE;


--
-- Name: alerts FK_1f5e832a67ebfc89b03f916ac77; Type: FK CONSTRAINT; Schema: public; Owner: staycation
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT "FK_1f5e832a67ebfc89b03f916ac77" FOREIGN KEY (insight_id) REFERENCES public.insights(id) ON DELETE CASCADE;


--
-- Name: holiday_profiles FK_3a8fb0df42ed6d549ee0bcc8178; Type: FK CONSTRAINT; Schema: public; Owner: staycation
--

ALTER TABLE ONLY public.holiday_profiles
    ADD CONSTRAINT "FK_3a8fb0df42ed6d549ee0bcc8178" FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: deals FK_3bf289204e35822329f5a27d8a5; Type: FK CONSTRAINT; Schema: public; Owner: staycation
--

ALTER TABLE ONLY public.deals
    ADD CONSTRAINT "FK_3bf289204e35822329f5a27d8a5" FOREIGN KEY (provider_id) REFERENCES public.providers(id);


--
-- Name: search_fingerprints FK_3db7a57f0966346090de895fc16; Type: FK CONSTRAINT; Schema: public; Owner: staycation
--

ALTER TABLE ONLY public.search_fingerprints
    ADD CONSTRAINT "FK_3db7a57f0966346090de895fc16" FOREIGN KEY (accom_type_id) REFERENCES public.provider_accom_types(id);


--
-- Name: search_fingerprints FK_49d347458d3d92fcf7fbbd99d0f; Type: FK CONSTRAINT; Schema: public; Owner: staycation
--

ALTER TABLE ONLY public.search_fingerprints
    ADD CONSTRAINT "FK_49d347458d3d92fcf7fbbd99d0f" FOREIGN KEY (provider_id) REFERENCES public.providers(id);


--
-- Name: price_observations FK_5d12500d310bb289b1e2ee96131; Type: FK CONSTRAINT; Schema: public; Owner: staycation
--

ALTER TABLE ONLY public.price_observations
    ADD CONSTRAINT "FK_5d12500d310bb289b1e2ee96131" FOREIGN KEY (fingerprint_id) REFERENCES public.search_fingerprints(id) ON DELETE CASCADE;


--
-- Name: provider_parks FK_713f639aa12fe0c470a8a75cbde; Type: FK CONSTRAINT; Schema: public; Owner: staycation
--

ALTER TABLE ONLY public.provider_parks
    ADD CONSTRAINT "FK_713f639aa12fe0c470a8a75cbde" FOREIGN KEY (provider_id) REFERENCES public.providers(id) ON DELETE CASCADE;


--
-- Name: price_observations FK_a30f3c476eba19743a7e7f46505; Type: FK CONSTRAINT; Schema: public; Owner: staycation
--

ALTER TABLE ONLY public.price_observations
    ADD CONSTRAINT "FK_a30f3c476eba19743a7e7f46505" FOREIGN KEY (fetch_run_id) REFERENCES public.fetch_runs(id);


--
-- Name: price_observations FK_ab5451edcb71c5f0252fc3b06e8; Type: FK CONSTRAINT; Schema: public; Owner: staycation
--

ALTER TABLE ONLY public.price_observations
    ADD CONSTRAINT "FK_ab5451edcb71c5f0252fc3b06e8" FOREIGN KEY (provider_id) REFERENCES public.providers(id);


--
-- Name: provider_accom_types FK_bae7db1e31a2e3aca6caeb83ff0; Type: FK CONSTRAINT; Schema: public; Owner: staycation
--

ALTER TABLE ONLY public.provider_accom_types
    ADD CONSTRAINT "FK_bae7db1e31a2e3aca6caeb83ff0" FOREIGN KEY (provider_id) REFERENCES public.providers(id) ON DELETE CASCADE;


--
-- Name: fetch_runs FK_bc514ce00862dc3027c4a1c9358; Type: FK CONSTRAINT; Schema: public; Owner: staycation
--

ALTER TABLE ONLY public.fetch_runs
    ADD CONSTRAINT "FK_bc514ce00862dc3027c4a1c9358" FOREIGN KEY (provider_id) REFERENCES public.providers(id);


--
-- Name: price_observations FK_cabc222ae5680f2cd316faba9ce; Type: FK CONSTRAINT; Schema: public; Owner: staycation
--

ALTER TABLE ONLY public.price_observations
    ADD CONSTRAINT "FK_cabc222ae5680f2cd316faba9ce" FOREIGN KEY (accom_type_id) REFERENCES public.provider_accom_types(id);


--
-- Name: search_fingerprints FK_db3e45c06e60b7d3dab91bdaebd; Type: FK CONSTRAINT; Schema: public; Owner: staycation
--

ALTER TABLE ONLY public.search_fingerprints
    ADD CONSTRAINT "FK_db3e45c06e60b7d3dab91bdaebd" FOREIGN KEY (park_id) REFERENCES public.provider_parks(id);


--
-- Name: insights FK_ee49db9d3d24aa022461322eb00; Type: FK CONSTRAINT; Schema: public; Owner: staycation
--

ALTER TABLE ONLY public.insights
    ADD CONSTRAINT "FK_ee49db9d3d24aa022461322eb00" FOREIGN KEY (fingerprint_id) REFERENCES public.search_fingerprints(id) ON DELETE CASCADE;


--
-- Name: alerts FK_f1eba840c1761991f142affee66; Type: FK CONSTRAINT; Schema: public; Owner: staycation
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT "FK_f1eba840c1761991f142affee66" FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: holiday_profiles fk_holiday_profiles_provider; Type: FK CONSTRAINT; Schema: public; Owner: staycation
--

ALTER TABLE ONLY public.holiday_profiles
    ADD CONSTRAINT fk_holiday_profiles_provider FOREIGN KEY (provider_id) REFERENCES public.providers(id) ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

\unrestrict cx43aArzVl3N3jQh86D0hmdb6iHA1edF7Qzph28IqtEY9DO1tjdtcUki2HVWIod

