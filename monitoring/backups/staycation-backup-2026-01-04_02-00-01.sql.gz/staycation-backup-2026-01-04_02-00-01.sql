--
-- PostgreSQL database dump
--

\restrict RvzwTccstJLNV8im4391K7Fcxtcuu6Xg1dJyZOY8gbtobbGiTOkWkaCzhC5qefh

-- Dumped from database version 16.11
-- Dumped by pg_dump version 16.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE IF EXISTS staycation_db;
--
-- Name: staycation_db; Type: DATABASE; Schema: -; Owner: staycation
--

CREATE DATABASE staycation_db WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE staycation_db OWNER TO staycation;

\unrestrict RvzwTccstJLNV8im4391K7Fcxtcuu6Xg1dJyZOY8gbtobbGiTOkWkaCzhC5qefh
\connect staycation_db
\restrict RvzwTccstJLNV8im4391K7Fcxtcuu6Xg1dJyZOY8gbtobbGiTOkWkaCzhC5qefh

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: alerts_channel_enum; Type: TYPE; Schema: public; Owner: staycation
--

CREATE TYPE public.alerts_channel_enum AS ENUM (
    'EMAIL',
    'PUSH',
    'SMS'
);


ALTER TYPE public.alerts_channel_enum OWNER TO staycation;

--
-- Name: alerts_status_enum; Type: TYPE; Schema: public; Owner: staycation
--

CREATE TYPE public.alerts_status_enum AS ENUM (
    'PENDING',
    'SENT',
    'FAILED',
    'DISMISSED'
);


ALTER TYPE public.alerts_status_enum OWNER TO staycation;

--
-- Name: deals_discounttype_enum; Type: TYPE; Schema: public; Owner: staycation
--

CREATE TYPE public.deals_discounttype_enum AS ENUM (
    'PERCENT_OFF',
    'FIXED_OFF',
    'SALE_PRICE',
    'PERK'
);


ALTER TYPE public.deals_discounttype_enum OWNER TO staycation;

--
-- Name: deals_source_enum; Type: TYPE; Schema: public; Owner: staycation
--

CREATE TYPE public.deals_source_enum AS ENUM (
    'PROVIDER_OFFERS',
    'HOTUKDEALS',
    'OTHER'
);


ALTER TYPE public.deals_source_enum OWNER TO staycation;

--
-- Name: fetch_runs_runtype_enum; Type: TYPE; Schema: public; Owner: staycation
--

CREATE TYPE public.fetch_runs_runtype_enum AS ENUM (
    'SEARCH',
    'OFFERS_PAGE',
    'DEAL_SOURCE',
    'MANUAL_PREVIEW'
);


ALTER TYPE public.fetch_runs_runtype_enum OWNER TO staycation;

--
-- Name: fetch_runs_status_enum; Type: TYPE; Schema: public; Owner: staycation
--

CREATE TYPE public.fetch_runs_status_enum AS ENUM (
    'OK',
    'ERROR',
    'BLOCKED',
    'PARSE_FAILED'
);


ALTER TYPE public.fetch_runs_status_enum OWNER TO staycation;

--
-- Name: holiday_profiles_accommodationtype_enum; Type: TYPE; Schema: public; Owner: staycation
--

CREATE TYPE public.holiday_profiles_accommodationtype_enum AS ENUM (
    'ANY',
    'LODGE',
    'CARAVAN',
    'APARTMENT',
    'COTTAGE',
    'HOTEL'
);


ALTER TYPE public.holiday_profiles_accommodationtype_enum OWNER TO staycation;

--
-- Name: holiday_profiles_alertsensitivity_enum; Type: TYPE; Schema: public; Owner: staycation
--

CREATE TYPE public.holiday_profiles_alertsensitivity_enum AS ENUM (
    'INSTANT',
    'DIGEST',
    'EXCEPTIONAL_ONLY'
);


ALTER TYPE public.holiday_profiles_alertsensitivity_enum OWNER TO staycation;

--
-- Name: holiday_profiles_flextype_enum; Type: TYPE; Schema: public; Owner: staycation
--

CREATE TYPE public.holiday_profiles_flextype_enum AS ENUM (
    'FIXED',
    'RANGE',
    'FLEXI'
);


ALTER TYPE public.holiday_profiles_flextype_enum OWNER TO staycation;

--
-- Name: holiday_profiles_peaktolerance_enum; Type: TYPE; Schema: public; Owner: staycation
--

CREATE TYPE public.holiday_profiles_peaktolerance_enum AS ENUM (
    'OFFPEAK_ONLY',
    'MIXED',
    'PEAK_OK'
);


ALTER TYPE public.holiday_profiles_peaktolerance_enum OWNER TO staycation;

--
-- Name: holiday_profiles_schoolholidays_enum; Type: TYPE; Schema: public; Owner: staycation
--

CREATE TYPE public.holiday_profiles_schoolholidays_enum AS ENUM (
    'ALLOW',
    'AVOID',
    'ONLY'
);


ALTER TYPE public.holiday_profiles_schoolholidays_enum OWNER TO staycation;

--
-- Name: holiday_profiles_staypattern_enum; Type: TYPE; Schema: public; Owner: staycation
--

CREATE TYPE public.holiday_profiles_staypattern_enum AS ENUM (
    'ANY',
    'MIDWEEK',
    'WEEKEND',
    'FULL_WEEK'
);


ALTER TYPE public.holiday_profiles_staypattern_enum OWNER TO staycation;

--
-- Name: holiday_profiles_tier_enum; Type: TYPE; Schema: public; Owner: staycation
--

CREATE TYPE public.holiday_profiles_tier_enum AS ENUM (
    'STANDARD',
    'PREMIUM',
    'LUXURY'
);


ALTER TYPE public.holiday_profiles_tier_enum OWNER TO staycation;

--
-- Name: insights_type_enum; Type: TYPE; Schema: public; Owner: staycation
--

CREATE TYPE public.insights_type_enum AS ENUM (
    'LOWEST_IN_X_DAYS',
    'PRICE_DROP_PERCENT',
    'NEW_CAMPAIGN_DETECTED',
    'RISK_RISING',
    'VOUCHER_SPOTTED'
);


ALTER TYPE public.insights_type_enum OWNER TO staycation;

--
-- Name: price_observations_availability_enum; Type: TYPE; Schema: public; Owner: staycation
--

CREATE TYPE public.price_observations_availability_enum AS ENUM (
    'AVAILABLE',
    'SOLD_OUT',
    'UNKNOWN'
);


ALTER TYPE public.price_observations_availability_enum OWNER TO staycation;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alerts; Type: TABLE; Schema: public; Owner: staycation
--

CREATE TABLE public.alerts (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    channel public.alerts_channel_enum DEFAULT 'EMAIL'::public.alerts_channel_enum NOT NULL,
    status public.alerts_status_enum DEFAULT 'PENDING'::public.alerts_status_enum NOT NULL,
    "dedupeKey" character varying NOT NULL,
    "errorMessage" text,
    "sentAt" timestamp without time zone,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL,
    user_id uuid,
    insight_id uuid
);


ALTER TABLE public.alerts OWNER TO staycation;

--
-- Name: deals; Type: TABLE; Schema: public; Owner: staycation
--

CREATE TABLE public.deals (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    source public.deals_source_enum NOT NULL,
    "sourceRef" character varying NOT NULL,
    title character varying NOT NULL,
    "discountType" public.deals_discounttype_enum NOT NULL,
    "discountValue" numeric(10,2),
    "voucherCode" character varying,
    "eligibilityTags" text DEFAULT ''::text NOT NULL,
    restrictions jsonb,
    "startsAt" timestamp without time zone,
    "endsAt" timestamp without time zone,
    confidence numeric(3,2) DEFAULT 0.5 NOT NULL,
    "detectedAt" timestamp without time zone DEFAULT now() NOT NULL,
    "lastSeenAt" timestamp without time zone DEFAULT now() NOT NULL,
    provider_id uuid
);


ALTER TABLE public.deals OWNER TO staycation;

--
-- Name: fetch_runs; Type: TABLE; Schema: public; Owner: staycation
--

CREATE TABLE public.fetch_runs (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    "runType" public.fetch_runs_runtype_enum NOT NULL,
    "scheduledFor" timestamp without time zone NOT NULL,
    "startedAt" timestamp without time zone,
    "finishedAt" timestamp without time zone,
    status public.fetch_runs_status_enum NOT NULL,
    "httpStatus" integer,
    "requestFingerprint" character varying,
    "responseSnapshotRef" text,
    "errorMessage" text,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    provider_id uuid,
    fingerprint_id uuid
);


ALTER TABLE public.fetch_runs OWNER TO staycation;

--
-- Name: holiday_profiles; Type: TABLE; Schema: public; Owner: staycation
--

CREATE TABLE public.holiday_profiles (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying NOT NULL,
    "partySizeAdults" integer DEFAULT 2 NOT NULL,
    "partySizeChildren" integer DEFAULT 0 NOT NULL,
    "flexType" public.holiday_profiles_flextype_enum DEFAULT 'RANGE'::public.holiday_profiles_flextype_enum NOT NULL,
    "dateStart" date,
    "dateEnd" date,
    "durationNightsMin" integer DEFAULT 3 NOT NULL,
    "durationNightsMax" integer DEFAULT 7 NOT NULL,
    "peakTolerance" public.holiday_profiles_peaktolerance_enum DEFAULT 'MIXED'::public.holiday_profiles_peaktolerance_enum NOT NULL,
    "budgetCeilingGbp" numeric(10,2),
    enabled boolean DEFAULT true NOT NULL,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL,
    user_id uuid,
    pets boolean DEFAULT false NOT NULL,
    "accommodationType" public.holiday_profiles_accommodationtype_enum DEFAULT 'ANY'::public.holiday_profiles_accommodationtype_enum NOT NULL,
    "minBedrooms" integer DEFAULT 0 NOT NULL,
    tier public.holiday_profiles_tier_enum DEFAULT 'STANDARD'::public.holiday_profiles_tier_enum NOT NULL,
    "stayPattern" public.holiday_profiles_staypattern_enum DEFAULT 'ANY'::public.holiday_profiles_staypattern_enum NOT NULL,
    "schoolHolidays" public.holiday_profiles_schoolholidays_enum DEFAULT 'ALLOW'::public.holiday_profiles_schoolholidays_enum NOT NULL,
    "petsNumber" integer DEFAULT 0 NOT NULL,
    "stepFreeAccess" boolean DEFAULT false NOT NULL,
    "accessibleBathroom" boolean DEFAULT false NOT NULL,
    "requiredFacilities" text DEFAULT ''::text NOT NULL,
    "alertSensitivity" public.holiday_profiles_alertsensitivity_enum DEFAULT 'INSTANT'::public.holiday_profiles_alertsensitivity_enum NOT NULL,
    region character varying,
    "maxResults" integer DEFAULT 50 NOT NULL,
    "sortOrder" character varying DEFAULT 'PRICE_ASC'::character varying NOT NULL,
    "enabledProviders" text DEFAULT ''::text NOT NULL,
    "parkIds" text,
    "parkUrls" text
);


ALTER TABLE public.holiday_profiles OWNER TO staycation;

--
-- Name: insights; Type: TABLE; Schema: public; Owner: staycation
--

CREATE TABLE public.insights (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    type public.insights_type_enum NOT NULL,
    summary text NOT NULL,
    details jsonb NOT NULL,
    "dedupeKey" character varying NOT NULL,
    "seriesKey" character varying NOT NULL,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    fingerprint_id uuid
);


ALTER TABLE public.insights OWNER TO staycation;

--
-- Name: migrations; Type: TABLE; Schema: public; Owner: staycation
--

CREATE TABLE public.migrations (
    id integer NOT NULL,
    "timestamp" bigint NOT NULL,
    name character varying NOT NULL
);


ALTER TABLE public.migrations OWNER TO staycation;

--
-- Name: migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: staycation
--

CREATE SEQUENCE public.migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.migrations_id_seq OWNER TO staycation;

--
-- Name: migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: staycation
--

ALTER SEQUENCE public.migrations_id_seq OWNED BY public.migrations.id;


--
-- Name: price_observations; Type: TABLE; Schema: public; Owner: staycation
--

CREATE TABLE public.price_observations (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    "stayStartDate" date NOT NULL,
    "stayNights" integer NOT NULL,
    "seriesKey" character varying NOT NULL,
    "partySize" jsonb,
    "priceTotalGbp" numeric(10,2) NOT NULL,
    "pricePerNightGbp" numeric(10,2) NOT NULL,
    availability public.price_observations_availability_enum DEFAULT 'UNKNOWN'::public.price_observations_availability_enum NOT NULL,
    currency character varying DEFAULT 'GBP'::character varying NOT NULL,
    "sourceUrl" text,
    "observedAt" timestamp without time zone DEFAULT now() NOT NULL,
    provider_id uuid,
    fingerprint_id uuid,
    fetch_run_id uuid,
    accom_type_id uuid
);


ALTER TABLE public.price_observations OWNER TO staycation;

--
-- Name: provider_accom_types; Type: TABLE; Schema: public; Owner: staycation
--

CREATE TABLE public.provider_accom_types (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    "providerAccomCode" character varying,
    name character varying NOT NULL,
    "capacityMin" integer,
    "capacityMax" integer,
    provider_id uuid
);


ALTER TABLE public.provider_accom_types OWNER TO staycation;

--
-- Name: provider_parks; Type: TABLE; Schema: public; Owner: staycation
--

CREATE TABLE public.provider_parks (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    "providerParkCode" character varying,
    name character varying NOT NULL,
    region character varying,
    latitude numeric(10,7),
    longitude numeric(10,7),
    provider_id uuid
);


ALTER TABLE public.provider_parks OWNER TO staycation;

--
-- Name: providers; Type: TABLE; Schema: public; Owner: staycation
--

CREATE TABLE public.providers (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    code character varying NOT NULL,
    name character varying NOT NULL,
    "baseUrl" character varying NOT NULL,
    notes text,
    enabled boolean DEFAULT true NOT NULL,
    "checkFrequencyHours" integer DEFAULT 48 NOT NULL,
    "maxConcurrent" integer DEFAULT 2 NOT NULL,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.providers OWNER TO staycation;

--
-- Name: search_fingerprints; Type: TABLE; Schema: public; Owner: staycation
--

CREATE TABLE public.search_fingerprints (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    "canonicalHash" character varying NOT NULL,
    "canonicalJson" jsonb NOT NULL,
    "checkFrequencyHours" integer DEFAULT 48 NOT NULL,
    "lastScheduledAt" timestamp without time zone,
    enabled boolean DEFAULT true NOT NULL,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL,
    profile_id uuid,
    provider_id uuid,
    park_id uuid,
    accom_type_id uuid
);


ALTER TABLE public.search_fingerprints OWNER TO staycation;

--
-- Name: users; Type: TABLE; Schema: public; Owner: staycation
--

CREATE TABLE public.users (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    email character varying NOT NULL,
    "passwordHash" character varying NOT NULL,
    name character varying,
    "emailVerified" boolean DEFAULT false NOT NULL,
    "verificationToken" character varying,
    "verificationTokenExpires" timestamp without time zone,
    "notificationsEnabled" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL,
    "passwordResetToken" character varying,
    "passwordResetExpires" timestamp without time zone,
    "notificationChannels" text[] DEFAULT '{email}'::text[] NOT NULL,
    "digestMode" boolean DEFAULT false NOT NULL
);


ALTER TABLE public.users OWNER TO staycation;

--
-- Name: migrations id; Type: DEFAULT; Schema: public; Owner: staycation
--

ALTER TABLE ONLY public.migrations ALTER COLUMN id SET DEFAULT nextval('public.migrations_id_seq'::regclass);


--
-- Data for Name: alerts; Type: TABLE DATA; Schema: public; Owner: staycation
--

COPY public.alerts (id, channel, status, "dedupeKey", "errorMessage", "sentAt", "createdAt", "updatedAt", user_id, insight_id) FROM stdin;
\.


--
-- Data for Name: deals; Type: TABLE DATA; Schema: public; Owner: staycation
--

COPY public.deals (id, source, "sourceRef", title, "discountType", "discountValue", "voucherCode", "eligibilityTags", restrictions, "startsAt", "endsAt", confidence, "detectedAt", "lastSeenAt", provider_id) FROM stdin;
\.


--
-- Data for Name: fetch_runs; Type: TABLE DATA; Schema: public; Owner: staycation
--

COPY public.fetch_runs (id, "runType", "scheduledFor", "startedAt", "finishedAt", status, "httpStatus", "requestFingerprint", "responseSnapshotRef", "errorMessage", "createdAt", provider_id, fingerprint_id) FROM stdin;
c49ebb82-c9ec-45b2-a28c-01127dbb7701	MANUAL_PREVIEW	2026-01-03 19:46:38.557	2026-01-03 19:46:38.557	2026-01-03 19:46:38.557	OK	\N	\N	{"summary":{"totalCandidates":0,"matchStrong":0,"matchWeak":0,"matchUnknown":0,"mismatch":0,"lowestMatchedPriceGbp":null},"parseStats":{"total":0,"matched":0}}	\N	2026-01-03 19:46:38.558245	7cc332a1-df65-4c83-a6a1-08c0b5db60c4	\N
73ac6e04-a0f3-4012-86c3-6e484f3d24aa	MANUAL_PREVIEW	2026-01-03 19:46:40.858	2026-01-03 19:46:40.858	2026-01-03 19:46:40.858	OK	\N	\N	{"summary":{"totalCandidates":0,"matchStrong":0,"matchWeak":0,"matchUnknown":0,"mismatch":0,"lowestMatchedPriceGbp":null},"parseStats":{"total":0,"matched":0}}	\N	2026-01-03 19:46:40.859034	3766d1a8-c727-4acd-b84f-1461922f2c58	\N
371f95f1-a23d-4c57-b7f5-7e4bc39249a2	MANUAL_PREVIEW	2026-01-03 19:51:04.517	2026-01-03 19:51:04.517	2026-01-03 19:51:04.517	OK	\N	\N	{"summary":{"totalCandidates":0,"matchStrong":0,"matchWeak":0,"matchUnknown":0,"mismatch":0,"lowestMatchedPriceGbp":null},"parseStats":{"total":0,"matched":0}}	\N	2026-01-03 19:51:04.519417	7cc332a1-df65-4c83-a6a1-08c0b5db60c4	\N
171d02f9-d633-4ede-b808-d60cd396e0e4	MANUAL_PREVIEW	2026-01-03 19:51:06.825	2026-01-03 19:51:06.825	2026-01-03 19:51:06.825	OK	\N	\N	{"summary":{"totalCandidates":0,"matchStrong":0,"matchWeak":0,"matchUnknown":0,"mismatch":0,"lowestMatchedPriceGbp":null},"parseStats":{"total":0,"matched":0}}	\N	2026-01-03 19:51:06.826135	3766d1a8-c727-4acd-b84f-1461922f2c58	\N
cccf553d-756a-4f50-8aa6-d7e121f957bc	MANUAL_PREVIEW	2026-01-03 19:53:38.295	2026-01-03 19:53:38.295	2026-01-03 19:53:38.295	OK	\N	\N	{"summary":{"totalCandidates":0,"matchStrong":0,"matchWeak":0,"matchUnknown":0,"mismatch":0,"lowestMatchedPriceGbp":null},"parseStats":{"total":0,"matched":0}}	\N	2026-01-03 19:53:38.29753	7cc332a1-df65-4c83-a6a1-08c0b5db60c4	\N
357ea178-a608-47dd-bfa9-b3c5ebbe1f45	MANUAL_PREVIEW	2026-01-03 19:53:50.185	2026-01-03 19:53:50.185	2026-01-03 19:53:50.185	OK	\N	\N	{"summary":{"totalCandidates":0,"matchStrong":0,"matchWeak":0,"matchUnknown":0,"mismatch":0,"lowestMatchedPriceGbp":null},"parseStats":{"total":0,"matched":0}}	\N	2026-01-03 19:53:50.187023	3766d1a8-c727-4acd-b84f-1461922f2c58	\N
e9712089-fab1-464b-be4a-77312455bfe1	MANUAL_PREVIEW	2026-01-03 19:58:15.016	2026-01-03 19:58:15.016	2026-01-03 19:58:15.016	OK	\N	\N	{"summary":{"totalCandidates":0,"matchStrong":0,"matchWeak":0,"matchUnknown":0,"mismatch":0,"lowestMatchedPriceGbp":null},"parseStats":{"total":0,"matched":0}}	\N	2026-01-03 19:58:15.018793	7cc332a1-df65-4c83-a6a1-08c0b5db60c4	\N
6184868f-d2e4-4f7c-80ea-3e4ec452d2d8	MANUAL_PREVIEW	2026-01-03 19:58:26.699	2026-01-03 19:58:26.699	2026-01-03 19:58:26.699	OK	\N	\N	{"summary":{"totalCandidates":0,"matchStrong":0,"matchWeak":0,"matchUnknown":0,"mismatch":0,"lowestMatchedPriceGbp":null},"parseStats":{"total":0,"matched":0}}	\N	2026-01-03 19:58:26.70104	3766d1a8-c727-4acd-b84f-1461922f2c58	\N
ef6c951c-a94d-48b2-85ab-6e7d19860d9c	MANUAL_PREVIEW	2026-01-03 21:11:56.924	2026-01-03 21:11:56.924	2026-01-03 21:11:56.924	OK	\N	\N	{"summary":{"totalCandidates":0,"matchStrong":0,"matchWeak":0,"matchUnknown":0,"mismatch":0,"lowestMatchedPriceGbp":null},"parseStats":{"total":0,"matched":0}}	\N	2026-01-03 21:11:56.926054	7cc332a1-df65-4c83-a6a1-08c0b5db60c4	\N
2b36af89-e6dd-4871-b262-e64b5d2646c0	MANUAL_PREVIEW	2026-01-03 21:14:27.722	2026-01-03 21:14:27.722	2026-01-03 21:14:27.722	OK	\N	\N	{"summary":{"totalCandidates":0,"matchStrong":0,"matchWeak":0,"matchUnknown":0,"mismatch":0,"lowestMatchedPriceGbp":null},"parseStats":{"total":0,"matched":0}}	\N	2026-01-03 21:14:27.723793	7cc332a1-df65-4c83-a6a1-08c0b5db60c4	\N
f271a439-e161-43d3-94dd-28b9914dc092	MANUAL_PREVIEW	2026-01-03 21:18:02.679	2026-01-03 21:18:02.679	2026-01-03 21:18:02.679	OK	\N	\N	{"summary":{"totalCandidates":0,"matchStrong":0,"matchWeak":0,"matchUnknown":0,"mismatch":0,"lowestMatchedPriceGbp":null},"parseStats":{"total":0,"matched":0}}	\N	2026-01-03 21:18:02.681734	7cc332a1-df65-4c83-a6a1-08c0b5db60c4	\N
bcca0a80-58c6-4289-91d3-a6d90e981269	MANUAL_PREVIEW	2026-01-03 21:18:18.853	2026-01-03 21:18:18.853	2026-01-03 21:18:18.853	OK	\N	\N	{"summary":{"totalCandidates":0,"matchStrong":0,"matchWeak":0,"matchUnknown":0,"mismatch":0,"lowestMatchedPriceGbp":null},"parseStats":{"total":0,"matched":0}}	\N	2026-01-03 21:18:18.854011	7cc332a1-df65-4c83-a6a1-08c0b5db60c4	\N
71d13de1-14f4-4651-ac4e-d45f9421d3f4	MANUAL_PREVIEW	2026-01-03 21:24:57.074	2026-01-03 21:24:57.074	2026-01-03 21:24:57.074	OK	\N	\N	{"summary":{"totalCandidates":0,"matchStrong":0,"matchWeak":0,"matchUnknown":0,"mismatch":0,"lowestMatchedPriceGbp":null},"parseStats":{"total":0,"matched":0}}	\N	2026-01-03 21:24:57.076104	7cc332a1-df65-4c83-a6a1-08c0b5db60c4	\N
2e6dc3b5-f4e6-41c9-a6e4-d1b9dbfffeaa	MANUAL_PREVIEW	2026-01-03 21:28:11.43	2026-01-03 21:28:11.43	2026-01-03 21:28:11.43	OK	\N	\N	{"summary":{"totalCandidates":0,"matchStrong":0,"matchWeak":0,"matchUnknown":0,"mismatch":0,"lowestMatchedPriceGbp":null},"parseStats":{"total":0,"matched":0}}	\N	2026-01-03 21:28:11.432408	7cc332a1-df65-4c83-a6a1-08c0b5db60c4	\N
4a835977-f177-4af2-9149-be59bdcbe9c4	MANUAL_PREVIEW	2026-01-03 21:30:53.277	2026-01-03 21:30:53.277	2026-01-03 21:30:53.277	OK	\N	\N	{"summary":{"totalCandidates":0,"matchStrong":0,"matchWeak":0,"matchUnknown":0,"mismatch":0,"lowestMatchedPriceGbp":null},"parseStats":{"total":0,"matched":0}}	\N	2026-01-03 21:30:53.280144	7cc332a1-df65-4c83-a6a1-08c0b5db60c4	\N
22d250f6-c841-485c-a010-6d1fd1a759df	MANUAL_PREVIEW	2026-01-03 21:33:10.509	2026-01-03 21:33:10.509	2026-01-03 21:33:10.509	OK	\N	\N	{"summary":{"totalCandidates":0,"matchStrong":0,"matchWeak":0,"matchUnknown":0,"mismatch":0,"lowestMatchedPriceGbp":null},"parseStats":{"total":0,"matched":0}}	\N	2026-01-03 21:33:10.512139	7cc332a1-df65-4c83-a6a1-08c0b5db60c4	\N
73a547ab-e7ea-4225-a83d-a3c2d579f7cf	MANUAL_PREVIEW	2026-01-03 21:35:43.766	2026-01-03 21:35:43.766	2026-01-03 21:35:43.766	OK	\N	\N	{"summary":{"totalCandidates":0,"matchStrong":0,"matchWeak":0,"matchUnknown":0,"mismatch":0,"lowestMatchedPriceGbp":null},"parseStats":{"total":0,"matched":0}}	\N	2026-01-03 21:35:43.769289	7cc332a1-df65-4c83-a6a1-08c0b5db60c4	\N
6be5dcf4-ee9e-444c-bae2-843d10adc53f	MANUAL_PREVIEW	2026-01-03 21:37:31.336	2026-01-03 21:37:31.336	2026-01-03 21:37:31.336	OK	\N	\N	{"summary":{"totalCandidates":0,"matchStrong":0,"matchWeak":0,"matchUnknown":0,"mismatch":0,"lowestMatchedPriceGbp":null},"parseStats":{"total":0,"matched":0}}	\N	2026-01-03 21:37:31.33956	7cc332a1-df65-4c83-a6a1-08c0b5db60c4	\N
4b2a6f52-e682-466f-9413-420e02f0ded8	MANUAL_PREVIEW	2026-01-03 21:38:36.936	2026-01-03 21:38:36.936	2026-01-03 21:38:36.936	OK	\N	\N	{"summary":{"totalCandidates":0,"matchStrong":0,"matchWeak":0,"matchUnknown":0,"mismatch":0,"lowestMatchedPriceGbp":null},"parseStats":{"total":0,"matched":0}}	\N	2026-01-03 21:38:36.939461	7cc332a1-df65-4c83-a6a1-08c0b5db60c4	\N
18328e85-1467-4a0b-9c75-5fa0f6ea744d	MANUAL_PREVIEW	2026-01-03 21:42:06.199	2026-01-03 21:42:06.199	2026-01-03 21:42:06.199	OK	\N	\N	{"summary":{"totalCandidates":0,"matchStrong":0,"matchWeak":0,"matchUnknown":0,"mismatch":0,"lowestMatchedPriceGbp":null},"parseStats":{"total":0,"matched":0}}	\N	2026-01-03 21:42:06.202102	7cc332a1-df65-4c83-a6a1-08c0b5db60c4	\N
6399236f-b818-4c7a-9859-eebf82898271	MANUAL_PREVIEW	2026-01-03 21:44:08.295	2026-01-03 21:44:08.295	2026-01-03 21:44:08.295	OK	\N	\N	{"summary":{"totalCandidates":0,"matchStrong":0,"matchWeak":0,"matchUnknown":0,"mismatch":0,"lowestMatchedPriceGbp":null},"parseStats":{"total":0,"matched":0}}	\N	2026-01-03 21:44:08.298343	7cc332a1-df65-4c83-a6a1-08c0b5db60c4	\N
310b9e4b-b31e-45a7-a981-d1475502867c	MANUAL_PREVIEW	2026-01-03 21:48:05.016	2026-01-03 21:48:05.016	2026-01-03 21:48:05.016	OK	\N	\N	{"summary":{"totalCandidates":0,"matchStrong":0,"matchWeak":0,"matchUnknown":0,"mismatch":0,"lowestMatchedPriceGbp":null},"parseStats":{"total":0,"matched":0}}	\N	2026-01-03 21:48:05.01955	7cc332a1-df65-4c83-a6a1-08c0b5db60c4	\N
7174427b-7b52-4314-905b-f39dd9946a31	MANUAL_PREVIEW	2026-01-03 21:50:28.171	2026-01-03 21:50:28.171	2026-01-03 21:50:28.171	OK	\N	\N	{"summary":{"totalCandidates":0,"matchStrong":0,"matchWeak":0,"matchUnknown":0,"mismatch":0,"lowestMatchedPriceGbp":null},"parseStats":{"total":0,"matched":0}}	\N	2026-01-03 21:50:28.178643	7cc332a1-df65-4c83-a6a1-08c0b5db60c4	\N
d0a2b78e-9c2a-476d-8195-0a15f2291bfa	MANUAL_PREVIEW	2026-01-03 21:54:25.292	2026-01-03 21:54:25.292	2026-01-03 21:54:25.292	OK	\N	\N	{"summary":{"totalCandidates":0,"matchStrong":0,"matchWeak":0,"matchUnknown":0,"mismatch":0,"lowestMatchedPriceGbp":null},"parseStats":{"total":0,"matched":0}}	\N	2026-01-03 21:54:25.29514	7cc332a1-df65-4c83-a6a1-08c0b5db60c4	\N
30ec9a86-07b4-49f8-99d0-174fce1f348c	MANUAL_PREVIEW	2026-01-03 22:00:42.777	2026-01-03 22:00:42.777	2026-01-03 22:00:42.777	OK	\N	\N	{"summary":{"totalCandidates":0,"matchStrong":0,"matchWeak":0,"matchUnknown":0,"mismatch":0,"lowestMatchedPriceGbp":null},"parseStats":{"total":0,"matched":0}}	\N	2026-01-03 22:00:42.78	7cc332a1-df65-4c83-a6a1-08c0b5db60c4	\N
6d5bb8de-e120-40bb-ac8f-a7d813b38dbd	MANUAL_PREVIEW	2026-01-03 22:02:44.289	2026-01-03 22:02:44.289	2026-01-03 22:02:44.289	OK	\N	\N	{"summary":{"totalCandidates":12,"matchStrong":0,"matchWeak":0,"matchUnknown":0,"mismatch":12,"lowestMatchedPriceGbp":null},"parseStats":{"total":12,"matched":0}}	\N	2026-01-03 22:02:44.292284	7cc332a1-df65-4c83-a6a1-08c0b5db60c4	\N
4d9e0942-a8f7-4857-b3db-486922694e61	MANUAL_PREVIEW	2026-01-03 22:03:02.655	2026-01-03 22:03:02.655	2026-01-03 22:03:02.655	OK	\N	\N	{"summary":{"totalCandidates":12,"matchStrong":0,"matchWeak":0,"matchUnknown":0,"mismatch":12,"lowestMatchedPriceGbp":null},"parseStats":{"total":12,"matched":0}}	\N	2026-01-03 22:03:02.656867	7cc332a1-df65-4c83-a6a1-08c0b5db60c4	\N
b44e839b-7ba4-4389-bcbf-843ac6fd7e30	MANUAL_PREVIEW	2026-01-03 22:04:16.463	2026-01-03 22:04:16.463	2026-01-03 22:04:16.463	OK	\N	\N	{"summary":{"totalCandidates":12,"matchStrong":0,"matchWeak":0,"matchUnknown":0,"mismatch":12,"lowestMatchedPriceGbp":null},"parseStats":{"total":12,"matched":0}}	\N	2026-01-03 22:04:16.466902	7cc332a1-df65-4c83-a6a1-08c0b5db60c4	\N
212b6d4f-c2a9-4604-961c-56b91210e39b	MANUAL_PREVIEW	2026-01-03 22:06:32.566	2026-01-03 22:06:32.566	2026-01-03 22:06:32.566	OK	\N	\N	{"summary":{"totalCandidates":12,"matchStrong":0,"matchWeak":0,"matchUnknown":0,"mismatch":12,"lowestMatchedPriceGbp":null},"parseStats":{"total":12,"matched":0}}	\N	2026-01-03 22:06:32.569192	7cc332a1-df65-4c83-a6a1-08c0b5db60c4	\N
e4b2b439-91ab-46d3-8119-4770b6663872	MANUAL_PREVIEW	2026-01-03 22:07:25.131	2026-01-03 22:07:25.131	2026-01-03 22:07:25.131	OK	\N	\N	{"summary":{"totalCandidates":12,"matchStrong":0,"matchWeak":0,"matchUnknown":0,"mismatch":12,"lowestMatchedPriceGbp":null},"parseStats":{"total":12,"matched":0}}	\N	2026-01-03 22:07:25.133892	7cc332a1-df65-4c83-a6a1-08c0b5db60c4	\N
3a6dd02c-470f-466a-a501-1cf1cae1416b	MANUAL_PREVIEW	2026-01-03 22:09:26.781	2026-01-03 22:09:26.781	2026-01-03 22:09:26.781	OK	\N	\N	{"summary":{"totalCandidates":12,"matchStrong":0,"matchWeak":0,"matchUnknown":12,"mismatch":0,"lowestMatchedPriceGbp":null},"parseStats":{"total":12,"matched":0}}	\N	2026-01-03 22:09:26.782921	7cc332a1-df65-4c83-a6a1-08c0b5db60c4	\N
5e8c0d52-07ad-4ec2-9941-253e1fdb464c	MANUAL_PREVIEW	2026-01-03 22:10:23.823	2026-01-03 22:10:23.823	2026-01-03 22:10:23.823	OK	\N	\N	{"summary":{"totalCandidates":12,"matchStrong":0,"matchWeak":0,"matchUnknown":12,"mismatch":0,"lowestMatchedPriceGbp":null},"parseStats":{"total":12,"matched":0}}	\N	2026-01-03 22:10:23.826667	7cc332a1-df65-4c83-a6a1-08c0b5db60c4	\N
6251a449-8219-4498-99bb-43a4ca7ae9c1	MANUAL_PREVIEW	2026-01-03 22:11:48.627	2026-01-03 22:11:48.627	2026-01-03 22:11:48.627	OK	\N	\N	{"summary":{"totalCandidates":12,"matchStrong":0,"matchWeak":0,"matchUnknown":12,"mismatch":0,"lowestMatchedPriceGbp":null},"parseStats":{"total":12,"matched":0}}	\N	2026-01-03 22:11:48.629843	7cc332a1-df65-4c83-a6a1-08c0b5db60c4	\N
a57941e6-1cd9-4aef-97da-9989c8ba1243	MANUAL_PREVIEW	2026-01-03 22:19:02.089	2026-01-03 22:19:02.089	2026-01-03 22:19:02.089	OK	\N	\N	{"summary":{"totalCandidates":12,"matchStrong":12,"matchWeak":0,"matchUnknown":0,"mismatch":0,"lowestMatchedPriceGbp":134},"parseStats":{"total":12,"matched":12}}	\N	2026-01-03 22:19:02.092844	7cc332a1-df65-4c83-a6a1-08c0b5db60c4	\N
5b018423-36a6-40f5-baa2-f46dc981619a	MANUAL_PREVIEW	2026-01-03 22:25:05.955	2026-01-03 22:25:05.955	2026-01-03 22:25:05.955	OK	\N	\N	{"summary":{"totalCandidates":12,"matchStrong":12,"matchWeak":0,"matchUnknown":0,"mismatch":0,"lowestMatchedPriceGbp":134},"parseStats":{"total":12,"matched":12}}	\N	2026-01-03 22:25:05.956217	7cc332a1-df65-4c83-a6a1-08c0b5db60c4	\N
5ca399e3-6ae2-4c3e-ba66-0dd4aaa5c4c3	MANUAL_PREVIEW	2026-01-03 22:33:32.658	2026-01-03 22:33:32.658	2026-01-03 22:33:32.658	OK	\N	\N	{"summary":{"totalCandidates":12,"matchStrong":0,"matchWeak":0,"matchUnknown":0,"mismatch":12,"lowestMatchedPriceGbp":null},"parseStats":{"total":12,"matched":0}}	\N	2026-01-03 22:33:32.658773	7cc332a1-df65-4c83-a6a1-08c0b5db60c4	\N
5ac77eee-1d79-4e8e-b6d5-838afc6daabf	MANUAL_PREVIEW	2026-01-03 22:33:35.047	2026-01-03 22:33:35.047	2026-01-03 22:33:35.047	OK	\N	\N	{"summary":{"totalCandidates":0,"matchStrong":0,"matchWeak":0,"matchUnknown":0,"mismatch":0,"lowestMatchedPriceGbp":null},"parseStats":{"total":0,"matched":0}}	\N	2026-01-03 22:33:35.048496	3766d1a8-c727-4acd-b84f-1461922f2c58	\N
bd3f1b92-5e18-4952-ba56-6876b3515400	MANUAL_PREVIEW	2026-01-03 22:50:35.129	2026-01-03 22:50:35.129	2026-01-03 22:50:35.129	OK	\N	\N	{"summary":{"totalCandidates":12,"matchStrong":0,"matchWeak":0,"matchUnknown":0,"mismatch":12,"lowestMatchedPriceGbp":null},"parseStats":{"total":12,"matched":0}}	\N	2026-01-03 22:50:35.12955	7cc332a1-df65-4c83-a6a1-08c0b5db60c4	\N
f1791261-f8c1-4f59-8f51-a8477f52179b	MANUAL_PREVIEW	2026-01-03 22:52:21.793	2026-01-03 22:52:21.793	2026-01-03 22:52:21.793	OK	\N	\N	{"summary":{"totalCandidates":12,"matchStrong":0,"matchWeak":0,"matchUnknown":0,"mismatch":12,"lowestMatchedPriceGbp":null},"parseStats":{"total":12,"matched":0}}	\N	2026-01-03 22:52:21.795748	7cc332a1-df65-4c83-a6a1-08c0b5db60c4	\N
9ab2afc5-2e66-4268-a496-7fbe1e4cb625	MANUAL_PREVIEW	2026-01-03 22:54:33.992	2026-01-03 22:54:33.992	2026-01-03 22:54:33.992	OK	\N	\N	{"summary":{"totalCandidates":12,"matchStrong":0,"matchWeak":0,"matchUnknown":0,"mismatch":12,"lowestMatchedPriceGbp":null},"parseStats":{"total":12,"matched":0}}	\N	2026-01-03 22:54:33.995247	7cc332a1-df65-4c83-a6a1-08c0b5db60c4	\N
39b7a937-fdc4-4c8c-97f7-62c0f6fbeae1	MANUAL_PREVIEW	2026-01-03 22:55:26.045	2026-01-03 22:55:26.045	2026-01-03 22:55:26.045	OK	\N	\N	{"summary":{"totalCandidates":12,"matchStrong":0,"matchWeak":0,"matchUnknown":0,"mismatch":12,"lowestMatchedPriceGbp":null},"parseStats":{"total":12,"matched":0}}	\N	2026-01-03 22:55:26.046918	7cc332a1-df65-4c83-a6a1-08c0b5db60c4	\N
40b9b7fb-0a47-47bd-960c-2062558b8a98	MANUAL_PREVIEW	2026-01-03 22:56:26.641	2026-01-03 22:56:26.641	2026-01-03 22:56:26.641	OK	\N	\N	{"summary":{"totalCandidates":12,"matchStrong":0,"matchWeak":0,"matchUnknown":0,"mismatch":12,"lowestMatchedPriceGbp":null},"parseStats":{"total":12,"matched":0}}	\N	2026-01-03 22:56:26.644095	7cc332a1-df65-4c83-a6a1-08c0b5db60c4	\N
a4b6500c-8d4c-4b12-8552-468ecb52d82f	MANUAL_PREVIEW	2026-01-03 22:56:44.449	2026-01-03 22:56:44.449	2026-01-03 22:56:44.449	OK	\N	\N	{"summary":{"totalCandidates":12,"matchStrong":12,"matchWeak":0,"matchUnknown":0,"mismatch":0,"lowestMatchedPriceGbp":134},"parseStats":{"total":12,"matched":12}}	\N	2026-01-03 22:56:44.451293	7cc332a1-df65-4c83-a6a1-08c0b5db60c4	\N
a650b28e-9ba9-480a-9bd2-62cf577005df	MANUAL_PREVIEW	2026-01-03 22:56:47.384	2026-01-03 22:56:47.384	2026-01-03 22:56:47.384	OK	\N	\N	{"summary":{"totalCandidates":12,"matchStrong":0,"matchWeak":0,"matchUnknown":0,"mismatch":12,"lowestMatchedPriceGbp":null},"parseStats":{"total":12,"matched":0}}	\N	2026-01-03 22:56:47.385188	7cc332a1-df65-4c83-a6a1-08c0b5db60c4	\N
4764d776-75b8-452d-9a2c-486f780374ca	MANUAL_PREVIEW	2026-01-03 22:56:49.718	2026-01-03 22:56:49.718	2026-01-03 22:56:49.718	OK	\N	\N	{"summary":{"totalCandidates":0,"matchStrong":0,"matchWeak":0,"matchUnknown":0,"mismatch":0,"lowestMatchedPriceGbp":null},"parseStats":{"total":0,"matched":0}}	\N	2026-01-03 22:56:49.718588	3766d1a8-c727-4acd-b84f-1461922f2c58	\N
cb8ccec0-2adb-40e3-8b0e-96dbd7bf85ca	MANUAL_PREVIEW	2026-01-03 22:57:29.567	2026-01-03 22:57:29.567	2026-01-03 22:57:29.567	OK	\N	\N	{"summary":{"totalCandidates":12,"matchStrong":0,"matchWeak":0,"matchUnknown":0,"mismatch":12,"lowestMatchedPriceGbp":null},"parseStats":{"total":12,"matched":0}}	\N	2026-01-03 22:57:29.56932	7cc332a1-df65-4c83-a6a1-08c0b5db60c4	\N
cdf55c54-12a4-47c7-ac6c-e10f8d8e7732	MANUAL_PREVIEW	2026-01-03 22:59:03.729	2026-01-03 22:59:03.729	2026-01-03 22:59:03.729	OK	\N	\N	{"summary":{"totalCandidates":12,"matchStrong":0,"matchWeak":0,"matchUnknown":0,"mismatch":12,"lowestMatchedPriceGbp":null},"parseStats":{"total":12,"matched":0}}	\N	2026-01-03 22:59:03.732266	7cc332a1-df65-4c83-a6a1-08c0b5db60c4	\N
886222f1-06cd-4882-9ba2-df551e2d5873	MANUAL_PREVIEW	2026-01-03 23:00:17.852	2026-01-03 23:00:17.852	2026-01-03 23:00:17.852	OK	\N	\N	{"summary":{"totalCandidates":12,"matchStrong":0,"matchWeak":0,"matchUnknown":0,"mismatch":12,"lowestMatchedPriceGbp":null},"parseStats":{"total":12,"matched":0}}	\N	2026-01-03 23:00:17.854943	7cc332a1-df65-4c83-a6a1-08c0b5db60c4	\N
f11ae4e7-8f8f-48ef-8d19-b668db056536	MANUAL_PREVIEW	2026-01-03 23:02:08.566	2026-01-03 23:02:08.566	2026-01-03 23:02:08.566	OK	\N	\N	{"summary":{"totalCandidates":12,"matchStrong":12,"matchWeak":0,"matchUnknown":0,"mismatch":0,"lowestMatchedPriceGbp":305},"parseStats":{"total":12,"matched":12}}	\N	2026-01-03 23:02:08.568338	7cc332a1-df65-4c83-a6a1-08c0b5db60c4	\N
12d37b3d-6cd6-4b58-8e32-18acd30b98f1	MANUAL_PREVIEW	2026-01-03 23:04:39.521	2026-01-03 23:04:39.521	2026-01-03 23:04:39.521	OK	\N	\N	{"summary":{"totalCandidates":12,"matchStrong":12,"matchWeak":0,"matchUnknown":0,"mismatch":0,"lowestMatchedPriceGbp":305},"parseStats":{"total":12,"matched":12}}	\N	2026-01-03 23:04:39.524022	7cc332a1-df65-4c83-a6a1-08c0b5db60c4	\N
a501c7e1-6c73-4c6d-8293-550dcf140cb8	MANUAL_PREVIEW	2026-01-03 23:06:53.447	2026-01-03 23:06:53.447	2026-01-03 23:06:53.447	OK	\N	\N	{"summary":{"totalCandidates":12,"matchStrong":12,"matchWeak":0,"matchUnknown":0,"mismatch":0,"lowestMatchedPriceGbp":305},"parseStats":{"total":12,"matched":12}}	\N	2026-01-03 23:06:53.450706	7cc332a1-df65-4c83-a6a1-08c0b5db60c4	\N
f70b33d5-06e0-4677-9e9f-841d5a42efdf	MANUAL_PREVIEW	2026-01-03 23:08:58.217	2026-01-03 23:08:58.217	2026-01-03 23:08:58.217	OK	\N	\N	{"summary":{"totalCandidates":12,"matchStrong":12,"matchWeak":0,"matchUnknown":0,"mismatch":0,"lowestMatchedPriceGbp":305},"parseStats":{"total":12,"matched":12}}	\N	2026-01-03 23:08:58.219618	7cc332a1-df65-4c83-a6a1-08c0b5db60c4	\N
4acbe372-6840-4f7f-8b81-2f3d6a263c19	MANUAL_PREVIEW	2026-01-03 23:11:11.915	2026-01-03 23:11:11.915	2026-01-03 23:11:11.915	OK	\N	\N	{"summary":{"totalCandidates":12,"matchStrong":12,"matchWeak":0,"matchUnknown":0,"mismatch":0,"lowestMatchedPriceGbp":305},"parseStats":{"total":12,"matched":12}}	\N	2026-01-03 23:11:11.917645	7cc332a1-df65-4c83-a6a1-08c0b5db60c4	\N
abca5931-ed3e-49cc-81ff-33697f13b816	MANUAL_PREVIEW	2026-01-03 23:26:02.335	2026-01-03 23:26:02.335	2026-01-03 23:26:02.335	OK	\N	\N	{"summary":{"totalCandidates":12,"matchStrong":12,"matchWeak":0,"matchUnknown":0,"mismatch":0,"lowestMatchedPriceGbp":305},"parseStats":{"total":12,"matched":12}}	\N	2026-01-03 23:26:02.338633	7cc332a1-df65-4c83-a6a1-08c0b5db60c4	\N
e33d0b6b-cfeb-437c-833f-acf5522fe718	MANUAL_PREVIEW	2026-01-03 23:36:55.203	2026-01-03 23:36:55.203	2026-01-03 23:36:55.203	OK	\N	\N	{"summary":{"totalCandidates":12,"matchStrong":12,"matchWeak":0,"matchUnknown":0,"mismatch":0,"lowestMatchedPriceGbp":305},"parseStats":{"total":12,"matched":12}}	\N	2026-01-03 23:36:55.206277	7cc332a1-df65-4c83-a6a1-08c0b5db60c4	\N
5ffa99b9-355e-4edd-ac4d-a07e2a4d25a5	MANUAL_PREVIEW	2026-01-03 23:38:24.719	2026-01-03 23:38:24.719	2026-01-03 23:38:24.719	OK	\N	\N	{"summary":{"totalCandidates":12,"matchStrong":12,"matchWeak":0,"matchUnknown":0,"mismatch":0,"lowestMatchedPriceGbp":305},"parseStats":{"total":12,"matched":12}}	\N	2026-01-03 23:38:24.721051	7cc332a1-df65-4c83-a6a1-08c0b5db60c4	\N
0b370f75-b828-4702-888f-e36cdb5359ac	MANUAL_PREVIEW	2026-01-03 23:38:40.662	2026-01-03 23:38:40.662	2026-01-03 23:38:40.662	OK	\N	\N	{"summary":{"totalCandidates":12,"matchStrong":12,"matchWeak":0,"matchUnknown":0,"mismatch":0,"lowestMatchedPriceGbp":134},"parseStats":{"total":12,"matched":12}}	\N	2026-01-03 23:38:40.66492	7cc332a1-df65-4c83-a6a1-08c0b5db60c4	\N
\.


--
-- Data for Name: holiday_profiles; Type: TABLE DATA; Schema: public; Owner: staycation
--

COPY public.holiday_profiles (id, name, "partySizeAdults", "partySizeChildren", "flexType", "dateStart", "dateEnd", "durationNightsMin", "durationNightsMax", "peakTolerance", "budgetCeilingGbp", enabled, "createdAt", "updatedAt", user_id, pets, "accommodationType", "minBedrooms", tier, "stayPattern", "schoolHolidays", "petsNumber", "stepFreeAccess", "accessibleBathroom", "requiredFacilities", "alertSensitivity", region, "maxResults", "sortOrder", "enabledProviders", "parkIds", "parkUrls") FROM stdin;
d987ade3-fe70-4100-a23d-18b2a4fc5710	Lakes Jan	2	0	RANGE	2026-01-30	2026-02-02	3	7	MIXED	3890.00	t	2026-01-03 19:46:35.404142	2026-01-03 22:25:03.350879	\N	t	ANY	1	STANDARD	ANY	ALLOW	2	f	f		INSTANT	Lake District	10	PRICE_DESC	hoseasons	\N	\N
0512eb65-a29e-4ba2-9eca-050a356ff968	Single URL Devon retest	4	0	RANGE	2026-05-18	2026-05-25	7	7	MIXED	\N	t	2026-01-03 23:02:04.657402	2026-01-03 23:02:04.657402	\N	t	ANY	0	STANDARD	ANY	ALLOW	2	f	f		INSTANT	Devon	50	PRICE_ASC	hoseasons	39248	\N
b1ce30fc-07b4-44be-b53b-0a7613412883	CenterParcs	2	0	RANGE	2026-10-12	2026-10-16	4	7	MIXED	110030.00	t	2026-01-03 23:39:21.861657	2026-01-03 23:42:05.223068	\N	f	ANY	0	STANDARD	ANY	ALLOW	0	f	f		INSTANT	Sherwood	50	PRICE_ASC	centerparcs		\N
\.


--
-- Data for Name: insights; Type: TABLE DATA; Schema: public; Owner: staycation
--

COPY public.insights (id, type, summary, details, "dedupeKey", "seriesKey", "createdAt", fingerprint_id) FROM stdin;
\.


--
-- Data for Name: migrations; Type: TABLE DATA; Schema: public; Owner: staycation
--

COPY public.migrations (id, "timestamp", name) FROM stdin;
\.


--
-- Data for Name: price_observations; Type: TABLE DATA; Schema: public; Owner: staycation
--

COPY public.price_observations (id, "stayStartDate", "stayNights", "seriesKey", "partySize", "priceTotalGbp", "pricePerNightGbp", availability, currency, "sourceUrl", "observedAt", provider_id, fingerprint_id, fetch_run_id, accom_type_id) FROM stdin;
\.


--
-- Data for Name: provider_accom_types; Type: TABLE DATA; Schema: public; Owner: staycation
--

COPY public.provider_accom_types (id, "providerAccomCode", name, "capacityMin", "capacityMax", provider_id) FROM stdin;
\.


--
-- Data for Name: provider_parks; Type: TABLE DATA; Schema: public; Owner: staycation
--

COPY public.provider_parks (id, "providerParkCode", name, region, latitude, longitude, provider_id) FROM stdin;
f82b0f2e-4912-4751-88a7-684fd861e912	devon-cliffs	Devon Cliffs	Devon	\N	\N	3766d1a8-c727-4acd-b84f-1461922f2c58
7abe7e6c-ac5a-48db-89a6-843e9e9c6d94	thorpe-park	Thorpe Park	Lincolnshire	\N	\N	3766d1a8-c727-4acd-b84f-1461922f2c58
77ac5443-a872-4d1a-b413-b0a0cf611735	primrose-valley	Primrose Valley	Yorkshire	\N	\N	3766d1a8-c727-4acd-b84f-1461922f2c58
\.


--
-- Data for Name: providers; Type: TABLE DATA; Schema: public; Owner: staycation
--

COPY public.providers (id, code, name, "baseUrl", notes, enabled, "checkFrequencyHours", "maxConcurrent", "createdAt", "updatedAt") FROM stdin;
7cc332a1-df65-4c83-a6a1-08c0b5db60c4	hoseasons	Hoseasons	https://www.hoseasons.co.uk	UK holiday parks and lodges	t	48	2	2026-01-03 16:59:22.926345	2026-01-03 16:59:22.926345
3766d1a8-c727-4acd-b84f-1461922f2c58	haven	Haven	https://www.haven.com	UK holiday parks	t	48	2	2026-01-03 16:59:22.942928	2026-01-03 16:59:22.942928
\.


--
-- Data for Name: search_fingerprints; Type: TABLE DATA; Schema: public; Owner: staycation
--

COPY public.search_fingerprints (id, "canonicalHash", "canonicalJson", "checkFrequencyHours", "lastScheduledAt", enabled, "createdAt", "updatedAt", profile_id, provider_id, park_id, accom_type_id) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: staycation
--

COPY public.users (id, email, "passwordHash", name, "emailVerified", "verificationToken", "verificationTokenExpires", "notificationsEnabled", "createdAt", "updatedAt", "passwordResetToken", "passwordResetExpires", "notificationChannels", "digestMode") FROM stdin;
2937e6db-8e30-4b86-881d-0d6e98f78691	test_user_chrome_final@example.com	$2b$12$SHltgfuNkXUJ0cl/3Y2HN.2QFimoDlG23Vv.dtJBMNBshY.kfvBYi	\N	t	7367625f8889072bbb21410a345f65a5402c159d56be235fa45c633f1a589484	\N	t	2026-01-03 17:31:48.031781	2026-01-03 17:31:48.031781	\N	\N	{email}	f
4012a352-1d4d-4440-bd6d-4a825593cc96	jamescregeen@gmail.com	$2b$12$5XBW8OKQ/908pu8ab3iTrOUCK6WjiH1rfi6ICGoQAcz434hWUY5Vm	\N	t	9c35b4936d2c40fd7097c8bf7c73a702bb5ad038c0f3bdaace54636b56aff1a3	\N	t	2026-01-03 17:37:20.119441	2026-01-03 17:37:20.119441	\N	\N	{email}	f
6b2e1f6a-7fa9-4d77-93f5-8f0218fe49fa	test_user_no_email@example.com	$2b$12$RWTR4o4sekHE8v6QJ9k58.1hMacPZleGDRPP3LoHALRAx3w2yUywO	\N	f	f771d1f2b3bc7cd854d45f49da9f512c03845a44734ca94e234d04f740b91e1a	\N	t	2026-01-03 17:40:39.505079	2026-01-03 17:40:39.505079	\N	\N	{email}	f
\.


--
-- Name: migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: staycation
--

SELECT pg_catalog.setval('public.migrations_id_seq', 2, true);


--
-- Name: provider_accom_types PK_24011ac6a622e3b8c06f622fe2d; Type: CONSTRAINT; Schema: public; Owner: staycation
--

ALTER TABLE ONLY public.provider_accom_types
    ADD CONSTRAINT "PK_24011ac6a622e3b8c06f622fe2d" PRIMARY KEY (id);


--
-- Name: search_fingerprints PK_45c32fedb4785ed31ec7954f758; Type: CONSTRAINT; Schema: public; Owner: staycation
--

ALTER TABLE ONLY public.search_fingerprints
    ADD CONSTRAINT "PK_45c32fedb4785ed31ec7954f758" PRIMARY KEY (id);


--
-- Name: alerts PK_60f895662df096bfcdfab7f4b96; Type: CONSTRAINT; Schema: public; Owner: staycation
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT "PK_60f895662df096bfcdfab7f4b96" PRIMARY KEY (id);


--
-- Name: holiday_profiles PK_7c9fc0e94836706da366c899588; Type: CONSTRAINT; Schema: public; Owner: staycation
--

ALTER TABLE ONLY public.holiday_profiles
    ADD CONSTRAINT "PK_7c9fc0e94836706da366c899588" PRIMARY KEY (id);


--
-- Name: insights PK_8616ab29fa49b7942541b8c964a; Type: CONSTRAINT; Schema: public; Owner: staycation
--

ALTER TABLE ONLY public.insights
    ADD CONSTRAINT "PK_8616ab29fa49b7942541b8c964a" PRIMARY KEY (id);


--
-- Name: deals PK_8c66f03b250f613ff8615940b4b; Type: CONSTRAINT; Schema: public; Owner: staycation
--

ALTER TABLE ONLY public.deals
    ADD CONSTRAINT "PK_8c66f03b250f613ff8615940b4b" PRIMARY KEY (id);


--
-- Name: migrations PK_8c82d7f526340ab734260ea46be; Type: CONSTRAINT; Schema: public; Owner: staycation
--

ALTER TABLE ONLY public.migrations
    ADD CONSTRAINT "PK_8c82d7f526340ab734260ea46be" PRIMARY KEY (id);


--
-- Name: users PK_a3ffb1c0c8416b9fc6f907b7433; Type: CONSTRAINT; Schema: public; Owner: staycation
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "PK_a3ffb1c0c8416b9fc6f907b7433" PRIMARY KEY (id);


--
-- Name: providers PK_af13fc2ebf382fe0dad2e4793aa; Type: CONSTRAINT; Schema: public; Owner: staycation
--

ALTER TABLE ONLY public.providers
    ADD CONSTRAINT "PK_af13fc2ebf382fe0dad2e4793aa" PRIMARY KEY (id);


--
-- Name: fetch_runs PK_cb88a8bcf4c7a009242613a07d5; Type: CONSTRAINT; Schema: public; Owner: staycation
--

ALTER TABLE ONLY public.fetch_runs
    ADD CONSTRAINT "PK_cb88a8bcf4c7a009242613a07d5" PRIMARY KEY (id);


--
-- Name: provider_parks PK_d4cf3ff1ca30e2b0f78d0b4ad66; Type: CONSTRAINT; Schema: public; Owner: staycation
--

ALTER TABLE ONLY public.provider_parks
    ADD CONSTRAINT "PK_d4cf3ff1ca30e2b0f78d0b4ad66" PRIMARY KEY (id);


--
-- Name: price_observations PK_e6c673b1a567075d17a300a7f71; Type: CONSTRAINT; Schema: public; Owner: staycation
--

ALTER TABLE ONLY public.price_observations
    ADD CONSTRAINT "PK_e6c673b1a567075d17a300a7f71" PRIMARY KEY (id);


--
-- Name: insights UQ_842d6055f9dd51ebad2e73f36ae; Type: CONSTRAINT; Schema: public; Owner: staycation
--

ALTER TABLE ONLY public.insights
    ADD CONSTRAINT "UQ_842d6055f9dd51ebad2e73f36ae" UNIQUE ("dedupeKey");


--
-- Name: users UQ_97672ac88f789774dd47f7c8be3; Type: CONSTRAINT; Schema: public; Owner: staycation
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "UQ_97672ac88f789774dd47f7c8be3" UNIQUE (email);


--
-- Name: providers UQ_cdc1db37b0ed3c1c6bc8c1f0458; Type: CONSTRAINT; Schema: public; Owner: staycation
--

ALTER TABLE ONLY public.providers
    ADD CONSTRAINT "UQ_cdc1db37b0ed3c1c6bc8c1f0458" UNIQUE (code);


--
-- Name: alerts UQ_d462ef6348dab8d4a1ad69a144a; Type: CONSTRAINT; Schema: public; Owner: staycation
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT "UQ_d462ef6348dab8d4a1ad69a144a" UNIQUE ("dedupeKey");


--
-- Name: search_fingerprints UQ_e292dbe9a397869976bd2c3719c; Type: CONSTRAINT; Schema: public; Owner: staycation
--

ALTER TABLE ONLY public.search_fingerprints
    ADD CONSTRAINT "UQ_e292dbe9a397869976bd2c3719c" UNIQUE ("canonicalHash");


--
-- Name: IDX_25284b251d23437cf1dfd32b88; Type: INDEX; Schema: public; Owner: staycation
--

CREATE INDEX "IDX_25284b251d23437cf1dfd32b88" ON public.fetch_runs USING btree (provider_id, "startedAt");


--
-- Name: IDX_842d6055f9dd51ebad2e73f36a; Type: INDEX; Schema: public; Owner: staycation
--

CREATE UNIQUE INDEX "IDX_842d6055f9dd51ebad2e73f36a" ON public.insights USING btree ("dedupeKey");


--
-- Name: IDX_85e5d40ecd7d907f8161a14ecd; Type: INDEX; Schema: public; Owner: staycation
--

CREATE INDEX "IDX_85e5d40ecd7d907f8161a14ecd" ON public.price_observations USING btree (fingerprint_id, "stayStartDate", "stayNights", "observedAt");


--
-- Name: IDX_97672ac88f789774dd47f7c8be; Type: INDEX; Schema: public; Owner: staycation
--

CREATE UNIQUE INDEX "IDX_97672ac88f789774dd47f7c8be" ON public.users USING btree (email);


--
-- Name: IDX_ac47a069c7039b4cc2668eff86; Type: INDEX; Schema: public; Owner: staycation
--

CREATE UNIQUE INDEX "IDX_ac47a069c7039b4cc2668eff86" ON public.provider_accom_types USING btree (provider_id, "providerAccomCode");


--
-- Name: IDX_c22bd7ff5f62d6358495ac177a; Type: INDEX; Schema: public; Owner: staycation
--

CREATE UNIQUE INDEX "IDX_c22bd7ff5f62d6358495ac177a" ON public.provider_parks USING btree (provider_id, "providerParkCode");


--
-- Name: IDX_ceaad712533817944c64b42e07; Type: INDEX; Schema: public; Owner: staycation
--

CREATE UNIQUE INDEX "IDX_ceaad712533817944c64b42e07" ON public.deals USING btree (source, "sourceRef");


--
-- Name: IDX_d462ef6348dab8d4a1ad69a144; Type: INDEX; Schema: public; Owner: staycation
--

CREATE UNIQUE INDEX "IDX_d462ef6348dab8d4a1ad69a144" ON public.alerts USING btree ("dedupeKey");


--
-- Name: IDX_dee782e49b1873a1aa7b430f11; Type: INDEX; Schema: public; Owner: staycation
--

CREATE INDEX "IDX_dee782e49b1873a1aa7b430f11" ON public.price_observations USING btree (fingerprint_id, "seriesKey", "observedAt");


--
-- Name: IDX_e292dbe9a397869976bd2c3719; Type: INDEX; Schema: public; Owner: staycation
--

CREATE UNIQUE INDEX "IDX_e292dbe9a397869976bd2c3719" ON public.search_fingerprints USING btree ("canonicalHash");


--
-- Name: search_fingerprints FK_168362d2addf80b24fc5c89c5c2; Type: FK CONSTRAINT; Schema: public; Owner: staycation
--

ALTER TABLE ONLY public.search_fingerprints
    ADD CONSTRAINT "FK_168362d2addf80b24fc5c89c5c2" FOREIGN KEY (profile_id) REFERENCES public.holiday_profiles(id) ON DELETE CASCADE;


--
-- Name: fetch_runs FK_1819dd7a4b8dc42adcb03deb957; Type: FK CONSTRAINT; Schema: public; Owner: staycation
--

ALTER TABLE ONLY public.fetch_runs
    ADD CONSTRAINT "FK_1819dd7a4b8dc42adcb03deb957" FOREIGN KEY (fingerprint_id) REFERENCES public.search_fingerprints(id);


--
-- Name: alerts FK_1f5e832a67ebfc89b03f916ac77; Type: FK CONSTRAINT; Schema: public; Owner: staycation
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT "FK_1f5e832a67ebfc89b03f916ac77" FOREIGN KEY (insight_id) REFERENCES public.insights(id) ON DELETE CASCADE;


--
-- Name: holiday_profiles FK_3a8fb0df42ed6d549ee0bcc8178; Type: FK CONSTRAINT; Schema: public; Owner: staycation
--

ALTER TABLE ONLY public.holiday_profiles
    ADD CONSTRAINT "FK_3a8fb0df42ed6d549ee0bcc8178" FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: deals FK_3bf289204e35822329f5a27d8a5; Type: FK CONSTRAINT; Schema: public; Owner: staycation
--

ALTER TABLE ONLY public.deals
    ADD CONSTRAINT "FK_3bf289204e35822329f5a27d8a5" FOREIGN KEY (provider_id) REFERENCES public.providers(id);


--
-- Name: search_fingerprints FK_3db7a57f0966346090de895fc16; Type: FK CONSTRAINT; Schema: public; Owner: staycation
--

ALTER TABLE ONLY public.search_fingerprints
    ADD CONSTRAINT "FK_3db7a57f0966346090de895fc16" FOREIGN KEY (accom_type_id) REFERENCES public.provider_accom_types(id);


--
-- Name: search_fingerprints FK_49d347458d3d92fcf7fbbd99d0f; Type: FK CONSTRAINT; Schema: public; Owner: staycation
--

ALTER TABLE ONLY public.search_fingerprints
    ADD CONSTRAINT "FK_49d347458d3d92fcf7fbbd99d0f" FOREIGN KEY (provider_id) REFERENCES public.providers(id);


--
-- Name: price_observations FK_5d12500d310bb289b1e2ee96131; Type: FK CONSTRAINT; Schema: public; Owner: staycation
--

ALTER TABLE ONLY public.price_observations
    ADD CONSTRAINT "FK_5d12500d310bb289b1e2ee96131" FOREIGN KEY (fingerprint_id) REFERENCES public.search_fingerprints(id) ON DELETE CASCADE;


--
-- Name: provider_parks FK_713f639aa12fe0c470a8a75cbde; Type: FK CONSTRAINT; Schema: public; Owner: staycation
--

ALTER TABLE ONLY public.provider_parks
    ADD CONSTRAINT "FK_713f639aa12fe0c470a8a75cbde" FOREIGN KEY (provider_id) REFERENCES public.providers(id) ON DELETE CASCADE;


--
-- Name: price_observations FK_a30f3c476eba19743a7e7f46505; Type: FK CONSTRAINT; Schema: public; Owner: staycation
--

ALTER TABLE ONLY public.price_observations
    ADD CONSTRAINT "FK_a30f3c476eba19743a7e7f46505" FOREIGN KEY (fetch_run_id) REFERENCES public.fetch_runs(id);


--
-- Name: price_observations FK_ab5451edcb71c5f0252fc3b06e8; Type: FK CONSTRAINT; Schema: public; Owner: staycation
--

ALTER TABLE ONLY public.price_observations
    ADD CONSTRAINT "FK_ab5451edcb71c5f0252fc3b06e8" FOREIGN KEY (provider_id) REFERENCES public.providers(id);


--
-- Name: provider_accom_types FK_bae7db1e31a2e3aca6caeb83ff0; Type: FK CONSTRAINT; Schema: public; Owner: staycation
--

ALTER TABLE ONLY public.provider_accom_types
    ADD CONSTRAINT "FK_bae7db1e31a2e3aca6caeb83ff0" FOREIGN KEY (provider_id) REFERENCES public.providers(id) ON DELETE CASCADE;


--
-- Name: fetch_runs FK_bc514ce00862dc3027c4a1c9358; Type: FK CONSTRAINT; Schema: public; Owner: staycation
--

ALTER TABLE ONLY public.fetch_runs
    ADD CONSTRAINT "FK_bc514ce00862dc3027c4a1c9358" FOREIGN KEY (provider_id) REFERENCES public.providers(id);


--
-- Name: price_observations FK_cabc222ae5680f2cd316faba9ce; Type: FK CONSTRAINT; Schema: public; Owner: staycation
--

ALTER TABLE ONLY public.price_observations
    ADD CONSTRAINT "FK_cabc222ae5680f2cd316faba9ce" FOREIGN KEY (accom_type_id) REFERENCES public.provider_accom_types(id);


--
-- Name: search_fingerprints FK_db3e45c06e60b7d3dab91bdaebd; Type: FK CONSTRAINT; Schema: public; Owner: staycation
--

ALTER TABLE ONLY public.search_fingerprints
    ADD CONSTRAINT "FK_db3e45c06e60b7d3dab91bdaebd" FOREIGN KEY (park_id) REFERENCES public.provider_parks(id);


--
-- Name: insights FK_ee49db9d3d24aa022461322eb00; Type: FK CONSTRAINT; Schema: public; Owner: staycation
--

ALTER TABLE ONLY public.insights
    ADD CONSTRAINT "FK_ee49db9d3d24aa022461322eb00" FOREIGN KEY (fingerprint_id) REFERENCES public.search_fingerprints(id) ON DELETE CASCADE;


--
-- Name: alerts FK_f1eba840c1761991f142affee66; Type: FK CONSTRAINT; Schema: public; Owner: staycation
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT "FK_f1eba840c1761991f142affee66" FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict RvzwTccstJLNV8im4391K7Fcxtcuu6Xg1dJyZOY8gbtobbGiTOkWkaCzhC5qefh

